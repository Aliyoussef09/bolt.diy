function bc(e, t) {
    for (var n = 0; n < t.length; n++) {
        const r = t[n];
        if (typeof r != "string" && !Array.isArray(r)) {
            for (const l in r)
                if (l !== "default" && !(l in e)) {
                    const o = Object.getOwnPropertyDescriptor(r, l);
                    o && Object.defineProperty(e, l, o.get ? o : {
                        enumerable: !0,
                        get: () => r[l]
                    })
                }
        }
    }
    return Object.freeze(Object.defineProperty(e, Symbol.toStringTag, {
        value: "Module"
    }))
}(function() {
    const t = document.createElement("link").relList;
    if (t && t.supports && t.supports("modulepreload")) return;
    for (const l of document.querySelectorAll('link[rel="modulepreload"]')) r(l);
    new MutationObserver(l => {
        for (const o of l)
            if (o.type === "childList")
                for (const i of o.addedNodes) i.tagName === "LINK" && i.rel === "modulepreload" && r(i)
    }).observe(document, {
        childList: !0,
        subtree: !0
    });

    function n(l) {
        const o = {};
        return l.integrity && (o.integrity = l.integrity), l.referrerPolicy && (o.referrerPolicy = l.referrerPolicy), l.crossOrigin === "use-credentials" ? o.credentials = "include" : l.crossOrigin === "anonymous" ? o.credentials = "omit" : o.credentials = "same-origin", o
    }

    function r(l) {
        if (l.ep) return;
        l.ep = !0;
        const o = n(l);
        fetch(l.href, o)
    }
})();

function ed(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
}
var ys = {
        exports: {}
    },
    fl = {},
    xs = {
        exports: {}
    },
    O = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var rr = Symbol.for("react.element"),
    td = Symbol.for("react.portal"),
    nd = Symbol.for("react.fragment"),
    rd = Symbol.for("react.strict_mode"),
    ld = Symbol.for("react.profiler"),
    od = Symbol.for("react.provider"),
    id = Symbol.for("react.context"),
    ud = Symbol.for("react.forward_ref"),
    sd = Symbol.for("react.suspense"),
    ad = Symbol.for("react.memo"),
    cd = Symbol.for("react.lazy"),
    tu = Symbol.iterator;

function dd(e) {
    return e === null || typeof e != "object" ? null : (e = tu && e[tu] || e["@@iterator"], typeof e == "function" ? e : null)
}
var ws = {
        isMounted: function() {
            return !1
        },
        enqueueForceUpdate: function() {},
        enqueueReplaceState: function() {},
        enqueueSetState: function() {}
    },
    Ss = Object.assign,
    ks = {};

function cn(e, t, n) {
    this.props = e, this.context = t, this.refs = ks, this.updater = n || ws
}
cn.prototype.isReactComponent = {};
cn.prototype.setState = function(e, t) {
    if (typeof e != "object" && typeof e != "function" && e != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, e, t, "setState")
};
cn.prototype.forceUpdate = function(e) {
    this.updater.enqueueForceUpdate(this, e, "forceUpdate")
};

function Es() {}
Es.prototype = cn.prototype;

function ri(e, t, n) {
    this.props = e, this.context = t, this.refs = ks, this.updater = n || ws
}
var li = ri.prototype = new Es;
li.constructor = ri;
Ss(li, cn.prototype);
li.isPureReactComponent = !0;
var nu = Array.isArray,
    Ns = Object.prototype.hasOwnProperty,
    oi = {
        current: null
    },
    Cs = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
    };

function js(e, t, n) {
    var r, l = {},
        o = null,
        i = null;
    if (t != null)
        for (r in t.ref !== void 0 && (i = t.ref), t.key !== void 0 && (o = "" + t.key), t) Ns.call(t, r) && !Cs.hasOwnProperty(r) && (l[r] = t[r]);
    var u = arguments.length - 2;
    if (u === 1) l.children = n;
    else if (1 < u) {
        for (var s = Array(u), a = 0; a < u; a++) s[a] = arguments[a + 2];
        l.children = s
    }
    if (e && e.defaultProps)
        for (r in u = e.defaultProps, u) l[r] === void 0 && (l[r] = u[r]);
    return {
        $$typeof: rr,
        type: e,
        key: o,
        ref: i,
        props: l,
        _owner: oi.current
    }
}

function fd(e, t) {
    return {
        $$typeof: rr,
        type: e.type,
        key: t,
        ref: e.ref,
        props: e.props,
        _owner: e._owner
    }
}

function ii(e) {
    return typeof e == "object" && e !== null && e.$$typeof === rr
}

function pd(e) {
    var t = {
        "=": "=0",
        ":": "=2"
    };
    return "$" + e.replace(/[=:]/g, function(n) {
        return t[n]
    })
}
var ru = /\/+/g;

function Il(e, t) {
    return typeof e == "object" && e !== null && e.key != null ? pd("" + e.key) : t.toString(36)
}

function Pr(e, t, n, r, l) {
    var o = typeof e;
    (o === "undefined" || o === "boolean") && (e = null);
    var i = !1;
    if (e === null) i = !0;
    else switch (o) {
        case "string":
        case "number":
            i = !0;
            break;
        case "object":
            switch (e.$$typeof) {
                case rr:
                case td:
                    i = !0
            }
    }
    if (i) return i = e, l = l(i), e = r === "" ? "." + Il(i, 0) : r, nu(l) ? (n = "", e != null && (n = e.replace(ru, "$&/") + "/"), Pr(l, t, n, "", function(a) {
        return a
    })) : l != null && (ii(l) && (l = fd(l, n + (!l.key || i && i.key === l.key ? "" : ("" + l.key).replace(ru, "$&/") + "/") + e)), t.push(l)), 1;
    if (i = 0, r = r === "" ? "." : r + ":", nu(e))
        for (var u = 0; u < e.length; u++) {
            o = e[u];
            var s = r + Il(o, u);
            i += Pr(o, t, n, s, l)
        } else if (s = dd(e), typeof s == "function")
            for (e = s.call(e), u = 0; !(o = e.next()).done;) o = o.value, s = r + Il(o, u++), i += Pr(o, t, n, s, l);
        else if (o === "object") throw t = String(e), Error("Objects are not valid as a React child (found: " + (t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
    return i
}

function dr(e, t, n) {
    if (e == null) return e;
    var r = [],
        l = 0;
    return Pr(e, r, "", "", function(o) {
        return t.call(n, o, l++)
    }), r
}

function hd(e) {
    if (e._status === -1) {
        var t = e._result;
        t = t(), t.then(function(n) {
            (e._status === 0 || e._status === -1) && (e._status = 1, e._result = n)
        }, function(n) {
            (e._status === 0 || e._status === -1) && (e._status = 2, e._result = n)
        }), e._status === -1 && (e._status = 0, e._result = t)
    }
    if (e._status === 1) return e._result.default;
    throw e._result
}
var ce = {
        current: null
    },
    Tr = {
        transition: null
    },
    md = {
        ReactCurrentDispatcher: ce,
        ReactCurrentBatchConfig: Tr,
        ReactCurrentOwner: oi
    };

function _s() {
    throw Error("act(...) is not supported in production builds of React.")
}
O.Children = {
    map: dr,
    forEach: function(e, t, n) {
        dr(e, function() {
            t.apply(this, arguments)
        }, n)
    },
    count: function(e) {
        var t = 0;
        return dr(e, function() {
            t++
        }), t
    },
    toArray: function(e) {
        return dr(e, function(t) {
            return t
        }) || []
    },
    only: function(e) {
        if (!ii(e)) throw Error("React.Children.only expected to receive a single React element child.");
        return e
    }
};
O.Component = cn;
O.Fragment = nd;
O.Profiler = ld;
O.PureComponent = ri;
O.StrictMode = rd;
O.Suspense = sd;
O.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = md;
O.act = _s;
O.cloneElement = function(e, t, n) {
    if (e == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
    var r = Ss({}, e.props),
        l = e.key,
        o = e.ref,
        i = e._owner;
    if (t != null) {
        if (t.ref !== void 0 && (o = t.ref, i = oi.current), t.key !== void 0 && (l = "" + t.key), e.type && e.type.defaultProps) var u = e.type.defaultProps;
        for (s in t) Ns.call(t, s) && !Cs.hasOwnProperty(s) && (r[s] = t[s] === void 0 && u !== void 0 ? u[s] : t[s])
    }
    var s = arguments.length - 2;
    if (s === 1) r.children = n;
    else if (1 < s) {
        u = Array(s);
        for (var a = 0; a < s; a++) u[a] = arguments[a + 2];
        r.children = u
    }
    return {
        $$typeof: rr,
        type: e.type,
        key: l,
        ref: o,
        props: r,
        _owner: i
    }
};
O.createContext = function(e) {
    return e = {
        $$typeof: id,
        _currentValue: e,
        _currentValue2: e,
        _threadCount: 0,
        Provider: null,
        Consumer: null,
        _defaultValue: null,
        _globalName: null
    }, e.Provider = {
        $$typeof: od,
        _context: e
    }, e.Consumer = e
};
O.createElement = js;
O.createFactory = function(e) {
    var t = js.bind(null, e);
    return t.type = e, t
};
O.createRef = function() {
    return {
        current: null
    }
};
O.forwardRef = function(e) {
    return {
        $$typeof: ud,
        render: e
    }
};
O.isValidElement = ii;
O.lazy = function(e) {
    return {
        $$typeof: cd,
        _payload: {
            _status: -1,
            _result: e
        },
        _init: hd
    }
};
O.memo = function(e, t) {
    return {
        $$typeof: ad,
        type: e,
        compare: t === void 0 ? null : t
    }
};
O.startTransition = function(e) {
    var t = Tr.transition;
    Tr.transition = {};
    try {
        e()
    } finally {
        Tr.transition = t
    }
};
O.unstable_act = _s;
O.useCallback = function(e, t) {
    return ce.current.useCallback(e, t)
};
O.useContext = function(e) {
    return ce.current.useContext(e)
};
O.useDebugValue = function() {};
O.useDeferredValue = function(e) {
    return ce.current.useDeferredValue(e)
};
O.useEffect = function(e, t) {
    return ce.current.useEffect(e, t)
};
O.useId = function() {
    return ce.current.useId()
};
O.useImperativeHandle = function(e, t, n) {
    return ce.current.useImperativeHandle(e, t, n)
};
O.useInsertionEffect = function(e, t) {
    return ce.current.useInsertionEffect(e, t)
};
O.useLayoutEffect = function(e, t) {
    return ce.current.useLayoutEffect(e, t)
};
O.useMemo = function(e, t) {
    return ce.current.useMemo(e, t)
};
O.useReducer = function(e, t, n) {
    return ce.current.useReducer(e, t, n)
};
O.useRef = function(e) {
    return ce.current.useRef(e)
};
O.useState = function(e) {
    return ce.current.useState(e)
};
O.useSyncExternalStore = function(e, t, n) {
    return ce.current.useSyncExternalStore(e, t, n)
};
O.useTransition = function() {
    return ce.current.useTransition()
};
O.version = "18.3.1";
xs.exports = O;
var N = xs.exports;
const vd = ed(N),
    gd = bc({
        __proto__: null,
        default: vd
    }, [N]);
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var yd = N,
    xd = Symbol.for("react.element"),
    wd = Symbol.for("react.fragment"),
    Sd = Object.prototype.hasOwnProperty,
    kd = yd.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
    Ed = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
    };

function Ps(e, t, n) {
    var r, l = {},
        o = null,
        i = null;
    n !== void 0 && (o = "" + n), t.key !== void 0 && (o = "" + t.key), t.ref !== void 0 && (i = t.ref);
    for (r in t) Sd.call(t, r) && !Ed.hasOwnProperty(r) && (l[r] = t[r]);
    if (e && e.defaultProps)
        for (r in t = e.defaultProps, t) l[r] === void 0 && (l[r] = t[r]);
    return {
        $$typeof: xd,
        type: e,
        key: o,
        ref: i,
        props: l,
        _owner: kd.current
    }
}
fl.Fragment = wd;
fl.jsx = Ps;
fl.jsxs = Ps;
ys.exports = fl;
var f = ys.exports,
    Ts = {
        exports: {}
    },
    Se = {},
    Rs = {
        exports: {}
    },
    Ls = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(e) {
    function t(C, R) {
        var L = C.length;
        C.push(R);
        e: for (; 0 < L;) {
            var Q = L - 1 >>> 1,
                q = C[Q];
            if (0 < l(q, R)) C[Q] = R, C[L] = q, L = Q;
            else break e
        }
    }

    function n(C) {
        return C.length === 0 ? null : C[0]
    }

    function r(C) {
        if (C.length === 0) return null;
        var R = C[0],
            L = C.pop();
        if (L !== R) {
            C[0] = L;
            e: for (var Q = 0, q = C.length, ar = q >>> 1; Q < ar;) {
                var wt = 2 * (Q + 1) - 1,
                    Ml = C[wt],
                    St = wt + 1,
                    cr = C[St];
                if (0 > l(Ml, L)) St < q && 0 > l(cr, Ml) ? (C[Q] = cr, C[St] = L, Q = St) : (C[Q] = Ml, C[wt] = L, Q = wt);
                else if (St < q && 0 > l(cr, L)) C[Q] = cr, C[St] = L, Q = St;
                else break e
            }
        }
        return R
    }

    function l(C, R) {
        var L = C.sortIndex - R.sortIndex;
        return L !== 0 ? L : C.id - R.id
    }
    if (typeof performance == "object" && typeof performance.now == "function") {
        var o = performance;
        e.unstable_now = function() {
            return o.now()
        }
    } else {
        var i = Date,
            u = i.now();
        e.unstable_now = function() {
            return i.now() - u
        }
    }
    var s = [],
        a = [],
        v = 1,
        p = null,
        m = 3,
        y = !1,
        g = !1,
        w = !1,
        P = typeof setTimeout == "function" ? setTimeout : null,
        d = typeof clearTimeout == "function" ? clearTimeout : null,
        c = typeof setImmediate < "u" ? setImmediate : null;
    typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);

    function h(C) {
        for (var R = n(a); R !== null;) {
            if (R.callback === null) r(a);
            else if (R.startTime <= C) r(a), R.sortIndex = R.expirationTime, t(s, R);
            else break;
            R = n(a)
        }
    }

    function x(C) {
        if (w = !1, h(C), !g)
            if (n(s) !== null) g = !0, Ol(k);
            else {
                var R = n(a);
                R !== null && zl(x, R.startTime - C)
            }
    }

    function k(C, R) {
        g = !1, w && (w = !1, d(T), T = -1), y = !0;
        var L = m;
        try {
            for (h(R), p = n(s); p !== null && (!(p.expirationTime > R) || C && !Te());) {
                var Q = p.callback;
                if (typeof Q == "function") {
                    p.callback = null, m = p.priorityLevel;
                    var q = Q(p.expirationTime <= R);
                    R = e.unstable_now(), typeof q == "function" ? p.callback = q : p === n(s) && r(s), h(R)
                } else r(s);
                p = n(s)
            }
            if (p !== null) var ar = !0;
            else {
                var wt = n(a);
                wt !== null && zl(x, wt.startTime - R), ar = !1
            }
            return ar
        } finally {
            p = null, m = L, y = !1
        }
    }
    var j = !1,
        _ = null,
        T = -1,
        W = 5,
        z = -1;

    function Te() {
        return !(e.unstable_now() - z < W)
    }

    function mn() {
        if (_ !== null) {
            var C = e.unstable_now();
            z = C;
            var R = !0;
            try {
                R = _(!0, C)
            } finally {
                R ? vn() : (j = !1, _ = null)
            }
        } else j = !1
    }
    var vn;
    if (typeof c == "function") vn = function() {
        c(mn)
    };
    else if (typeof MessageChannel < "u") {
        var eu = new MessageChannel,
            Jc = eu.port2;
        eu.port1.onmessage = mn, vn = function() {
            Jc.postMessage(null)
        }
    } else vn = function() {
        P(mn, 0)
    };

    function Ol(C) {
        _ = C, j || (j = !0, vn())
    }

    function zl(C, R) {
        T = P(function() {
            C(e.unstable_now())
        }, R)
    }
    e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(C) {
        C.callback = null
    }, e.unstable_continueExecution = function() {
        g || y || (g = !0, Ol(k))
    }, e.unstable_forceFrameRate = function(C) {
        0 > C || 125 < C ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : W = 0 < C ? Math.floor(1e3 / C) : 5
    }, e.unstable_getCurrentPriorityLevel = function() {
        return m
    }, e.unstable_getFirstCallbackNode = function() {
        return n(s)
    }, e.unstable_next = function(C) {
        switch (m) {
            case 1:
            case 2:
            case 3:
                var R = 3;
                break;
            default:
                R = m
        }
        var L = m;
        m = R;
        try {
            return C()
        } finally {
            m = L
        }
    }, e.unstable_pauseExecution = function() {}, e.unstable_requestPaint = function() {}, e.unstable_runWithPriority = function(C, R) {
        switch (C) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                break;
            default:
                C = 3
        }
        var L = m;
        m = C;
        try {
            return R()
        } finally {
            m = L
        }
    }, e.unstable_scheduleCallback = function(C, R, L) {
        var Q = e.unstable_now();
        switch (typeof L == "object" && L !== null ? (L = L.delay, L = typeof L == "number" && 0 < L ? Q + L : Q) : L = Q, C) {
            case 1:
                var q = -1;
                break;
            case 2:
                q = 250;
                break;
            case 5:
                q = 1073741823;
                break;
            case 4:
                q = 1e4;
                break;
            default:
                q = 5e3
        }
        return q = L + q, C = {
            id: v++,
            callback: R,
            priorityLevel: C,
            startTime: L,
            expirationTime: q,
            sortIndex: -1
        }, L > Q ? (C.sortIndex = L, t(a, C), n(s) === null && C === n(a) && (w ? (d(T), T = -1) : w = !0, zl(x, L - Q))) : (C.sortIndex = q, t(s, C), g || y || (g = !0, Ol(k))), C
    }, e.unstable_shouldYield = Te, e.unstable_wrapCallback = function(C) {
        var R = m;
        return function() {
            var L = m;
            m = R;
            try {
                return C.apply(this, arguments)
            } finally {
                m = L
            }
        }
    }
})(Ls);
Rs.exports = Ls;
var Nd = Rs.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Cd = N,
    we = Nd;

function S(e) {
    for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
    return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
}
var Os = new Set,
    Un = {};

function It(e, t) {
    nn(e, t), nn(e + "Capture", t)
}

function nn(e, t) {
    for (Un[e] = t, e = 0; e < t.length; e++) Os.add(t[e])
}
var Ye = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"),
    so = Object.prototype.hasOwnProperty,
    jd = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
    lu = {},
    ou = {};

function _d(e) {
    return so.call(ou, e) ? !0 : so.call(lu, e) ? !1 : jd.test(e) ? ou[e] = !0 : (lu[e] = !0, !1)
}

function Pd(e, t, n, r) {
    if (n !== null && n.type === 0) return !1;
    switch (typeof t) {
        case "function":
        case "symbol":
            return !0;
        case "boolean":
            return r ? !1 : n !== null ? !n.acceptsBooleans : (e = e.toLowerCase().slice(0, 5), e !== "data-" && e !== "aria-");
        default:
            return !1
    }
}

function Td(e, t, n, r) {
    if (t === null || typeof t > "u" || Pd(e, t, n, r)) return !0;
    if (r) return !1;
    if (n !== null) switch (n.type) {
        case 3:
            return !t;
        case 4:
            return t === !1;
        case 5:
            return isNaN(t);
        case 6:
            return isNaN(t) || 1 > t
    }
    return !1
}

function de(e, t, n, r, l, o, i) {
    this.acceptsBooleans = t === 2 || t === 3 || t === 4, this.attributeName = r, this.attributeNamespace = l, this.mustUseProperty = n, this.propertyName = e, this.type = t, this.sanitizeURL = o, this.removeEmptyString = i
}
var re = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e) {
    re[e] = new de(e, 0, !1, e, null, !1, !1)
});
[
    ["acceptCharset", "accept-charset"],
    ["className", "class"],
    ["htmlFor", "for"],
    ["httpEquiv", "http-equiv"]
].forEach(function(e) {
    var t = e[0];
    re[t] = new de(t, 1, !1, e[1], null, !1, !1)
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) {
    re[e] = new de(e, 2, !1, e.toLowerCase(), null, !1, !1)
});
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) {
    re[e] = new de(e, 2, !1, e, null, !1, !1)
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e) {
    re[e] = new de(e, 3, !1, e.toLowerCase(), null, !1, !1)
});
["checked", "multiple", "muted", "selected"].forEach(function(e) {
    re[e] = new de(e, 3, !0, e, null, !1, !1)
});
["capture", "download"].forEach(function(e) {
    re[e] = new de(e, 4, !1, e, null, !1, !1)
});
["cols", "rows", "size", "span"].forEach(function(e) {
    re[e] = new de(e, 6, !1, e, null, !1, !1)
});
["rowSpan", "start"].forEach(function(e) {
    re[e] = new de(e, 5, !1, e.toLowerCase(), null, !1, !1)
});
var ui = /[\-:]([a-z])/g;

function si(e) {
    return e[1].toUpperCase()
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e) {
    var t = e.replace(ui, si);
    re[t] = new de(t, 1, !1, e, null, !1, !1)
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e) {
    var t = e.replace(ui, si);
    re[t] = new de(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1)
});
["xml:base", "xml:lang", "xml:space"].forEach(function(e) {
    var t = e.replace(ui, si);
    re[t] = new de(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1)
});
["tabIndex", "crossOrigin"].forEach(function(e) {
    re[e] = new de(e, 1, !1, e.toLowerCase(), null, !1, !1)
});
re.xlinkHref = new de("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1);
["src", "href", "action", "formAction"].forEach(function(e) {
    re[e] = new de(e, 1, !1, e.toLowerCase(), null, !0, !0)
});

function ai(e, t, n, r) {
    var l = re.hasOwnProperty(t) ? re[t] : null;
    (l !== null ? l.type !== 0 : r || !(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N") && (Td(t, n, l, r) && (n = null), r || l === null ? _d(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n)) : l.mustUseProperty ? e[l.propertyName] = n === null ? l.type === 3 ? !1 : "" : n : (t = l.attributeName, r = l.attributeNamespace, n === null ? e.removeAttribute(t) : (l = l.type, n = l === 3 || l === 4 && n === !0 ? "" : "" + n, r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))))
}
var qe = Cd.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
    fr = Symbol.for("react.element"),
    Ut = Symbol.for("react.portal"),
    At = Symbol.for("react.fragment"),
    ci = Symbol.for("react.strict_mode"),
    ao = Symbol.for("react.profiler"),
    zs = Symbol.for("react.provider"),
    Ms = Symbol.for("react.context"),
    di = Symbol.for("react.forward_ref"),
    co = Symbol.for("react.suspense"),
    fo = Symbol.for("react.suspense_list"),
    fi = Symbol.for("react.memo"),
    et = Symbol.for("react.lazy"),
    Is = Symbol.for("react.offscreen"),
    iu = Symbol.iterator;

function gn(e) {
    return e === null || typeof e != "object" ? null : (e = iu && e[iu] || e["@@iterator"], typeof e == "function" ? e : null)
}
var V = Object.assign,
    Fl;

function Cn(e) {
    if (Fl === void 0) try {
        throw Error()
    } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        Fl = t && t[1] || ""
    }
    return `
` + Fl + e
}
var Dl = !1;

function Ul(e, t) {
    if (!e || Dl) return "";
    Dl = !0;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
        if (t)
            if (t = function() {
                    throw Error()
                }, Object.defineProperty(t.prototype, "props", {
                    set: function() {
                        throw Error()
                    }
                }), typeof Reflect == "object" && Reflect.construct) {
                try {
                    Reflect.construct(t, [])
                } catch (a) {
                    var r = a
                }
                Reflect.construct(e, [], t)
            } else {
                try {
                    t.call()
                } catch (a) {
                    r = a
                }
                e.call(t.prototype)
            }
        else {
            try {
                throw Error()
            } catch (a) {
                r = a
            }
            e()
        }
    } catch (a) {
        if (a && r && typeof a.stack == "string") {
            for (var l = a.stack.split(`
`), o = r.stack.split(`
`), i = l.length - 1, u = o.length - 1; 1 <= i && 0 <= u && l[i] !== o[u];) u--;
            for (; 1 <= i && 0 <= u; i--, u--)
                if (l[i] !== o[u]) {
                    if (i !== 1 || u !== 1)
                        do
                            if (i--, u--, 0 > u || l[i] !== o[u]) {
                                var s = `
` + l[i].replace(" at new ", " at ");
                                return e.displayName && s.includes("<anonymous>") && (s = s.replace("<anonymous>", e.displayName)), s
                            }
                    while (1 <= i && 0 <= u);
                    break
                }
        }
    } finally {
        Dl = !1, Error.prepareStackTrace = n
    }
    return (e = e ? e.displayName || e.name : "") ? Cn(e) : ""
}

function Rd(e) {
    switch (e.tag) {
        case 5:
            return Cn(e.type);
        case 16:
            return Cn("Lazy");
        case 13:
            return Cn("Suspense");
        case 19:
            return Cn("SuspenseList");
        case 0:
        case 2:
        case 15:
            return e = Ul(e.type, !1), e;
        case 11:
            return e = Ul(e.type.render, !1), e;
        case 1:
            return e = Ul(e.type, !0), e;
        default:
            return ""
    }
}

function po(e) {
    if (e == null) return null;
    if (typeof e == "function") return e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
        case At:
            return "Fragment";
        case Ut:
            return "Portal";
        case ao:
            return "Profiler";
        case ci:
            return "StrictMode";
        case co:
            return "Suspense";
        case fo:
            return "SuspenseList"
    }
    if (typeof e == "object") switch (e.$$typeof) {
        case Ms:
            return (e.displayName || "Context") + ".Consumer";
        case zs:
            return (e._context.displayName || "Context") + ".Provider";
        case di:
            var t = e.render;
            return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
        case fi:
            return t = e.displayName || null, t !== null ? t : po(e.type) || "Memo";
        case et:
            t = e._payload, e = e._init;
            try {
                return po(e(t))
            } catch {}
    }
    return null
}

function Ld(e) {
    var t = e.type;
    switch (e.tag) {
        case 24:
            return "Cache";
        case 9:
            return (t.displayName || "Context") + ".Consumer";
        case 10:
            return (t._context.displayName || "Context") + ".Provider";
        case 18:
            return "DehydratedFragment";
        case 11:
            return e = t.render, e = e.displayName || e.name || "", t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef");
        case 7:
            return "Fragment";
        case 5:
            return t;
        case 4:
            return "Portal";
        case 3:
            return "Root";
        case 6:
            return "Text";
        case 16:
            return po(t);
        case 8:
            return t === ci ? "StrictMode" : "Mode";
        case 22:
            return "Offscreen";
        case 12:
            return "Profiler";
        case 21:
            return "Scope";
        case 13:
            return "Suspense";
        case 19:
            return "SuspenseList";
        case 25:
            return "TracingMarker";
        case 1:
        case 0:
        case 17:
        case 2:
        case 14:
        case 15:
            if (typeof t == "function") return t.displayName || t.name || null;
            if (typeof t == "string") return t
    }
    return null
}

function mt(e) {
    switch (typeof e) {
        case "boolean":
        case "number":
        case "string":
        case "undefined":
            return e;
        case "object":
            return e;
        default:
            return ""
    }
}

function Fs(e) {
    var t = e.type;
    return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio")
}

function Od(e) {
    var t = Fs(e) ? "checked" : "value",
        n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
        r = "" + e[t];
    if (!e.hasOwnProperty(t) && typeof n < "u" && typeof n.get == "function" && typeof n.set == "function") {
        var l = n.get,
            o = n.set;
        return Object.defineProperty(e, t, {
            configurable: !0,
            get: function() {
                return l.call(this)
            },
            set: function(i) {
                r = "" + i, o.call(this, i)
            }
        }), Object.defineProperty(e, t, {
            enumerable: n.enumerable
        }), {
            getValue: function() {
                return r
            },
            setValue: function(i) {
                r = "" + i
            },
            stopTracking: function() {
                e._valueTracker = null, delete e[t]
            }
        }
    }
}

function pr(e) {
    e._valueTracker || (e._valueTracker = Od(e))
}

function Ds(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var n = t.getValue(),
        r = "";
    return e && (r = Fs(e) ? e.checked ? "true" : "false" : e.value), e = r, e !== n ? (t.setValue(e), !0) : !1
}

function Br(e) {
    if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null;
    try {
        return e.activeElement || e.body
    } catch {
        return e.body
    }
}

function ho(e, t) {
    var n = t.checked;
    return V({}, t, {
        defaultChecked: void 0,
        defaultValue: void 0,
        value: void 0,
        checked: n ? ? e._wrapperState.initialChecked
    })
}

function uu(e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue,
        r = t.checked != null ? t.checked : t.defaultChecked;
    n = mt(t.value != null ? t.value : n), e._wrapperState = {
        initialChecked: r,
        initialValue: n,
        controlled: t.type === "checkbox" || t.type === "radio" ? t.checked != null : t.value != null
    }
}

function Us(e, t) {
    t = t.checked, t != null && ai(e, "checked", t, !1)
}

function mo(e, t) {
    Us(e, t);
    var n = mt(t.value),
        r = t.type;
    if (n != null) r === "number" ? (n === 0 && e.value === "" || e.value != n) && (e.value = "" + n) : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
        e.removeAttribute("value");
        return
    }
    t.hasOwnProperty("value") ? vo(e, t.type, n) : t.hasOwnProperty("defaultValue") && vo(e, t.type, mt(t.defaultValue)), t.checked == null && t.defaultChecked != null && (e.defaultChecked = !!t.defaultChecked)
}

function su(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
        var r = t.type;
        if (!(r !== "submit" && r !== "reset" || t.value !== void 0 && t.value !== null)) return;
        t = "" + e._wrapperState.initialValue, n || t === e.value || (e.value = t), e.defaultValue = t
    }
    n = e.name, n !== "" && (e.name = ""), e.defaultChecked = !!e._wrapperState.initialChecked, n !== "" && (e.name = n)
}

function vo(e, t, n) {
    (t !== "number" || Br(e.ownerDocument) !== e) && (n == null ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + n && (e.defaultValue = "" + n))
}
var jn = Array.isArray;

function Zt(e, t, n, r) {
    if (e = e.options, t) {
        t = {};
        for (var l = 0; l < n.length; l++) t["$" + n[l]] = !0;
        for (n = 0; n < e.length; n++) l = t.hasOwnProperty("$" + e[n].value), e[n].selected !== l && (e[n].selected = l), l && r && (e[n].defaultSelected = !0)
    } else {
        for (n = "" + mt(n), t = null, l = 0; l < e.length; l++) {
            if (e[l].value === n) {
                e[l].selected = !0, r && (e[l].defaultSelected = !0);
                return
            }
            t !== null || e[l].disabled || (t = e[l])
        }
        t !== null && (t.selected = !0)
    }
}

function go(e, t) {
    if (t.dangerouslySetInnerHTML != null) throw Error(S(91));
    return V({}, t, {
        value: void 0,
        defaultValue: void 0,
        children: "" + e._wrapperState.initialValue
    })
}

function au(e, t) {
    var n = t.value;
    if (n == null) {
        if (n = t.children, t = t.defaultValue, n != null) {
            if (t != null) throw Error(S(92));
            if (jn(n)) {
                if (1 < n.length) throw Error(S(93));
                n = n[0]
            }
            t = n
        }
        t == null && (t = ""), n = t
    }
    e._wrapperState = {
        initialValue: mt(n)
    }
}

function As(e, t) {
    var n = mt(t.value),
        r = mt(t.defaultValue);
    n != null && (n = "" + n, n !== e.value && (e.value = n), t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)), r != null && (e.defaultValue = "" + r)
}

function cu(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t)
}

function $s(e) {
    switch (e) {
        case "svg":
            return "http://www.w3.org/2000/svg";
        case "math":
            return "http://www.w3.org/1998/Math/MathML";
        default:
            return "http://www.w3.org/1999/xhtml"
    }
}

function yo(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml" ? $s(t) : e === "http://www.w3.org/2000/svg" && t === "foreignObject" ? "http://www.w3.org/1999/xhtml" : e
}
var hr, Bs = function(e) {
    return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(t, n, r, l) {
        MSApp.execUnsafeLocalFunction(function() {
            return e(t, n, r, l)
        })
    } : e
}(function(e, t) {
    if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e) e.innerHTML = t;
    else {
        for (hr = hr || document.createElement("div"), hr.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>", t = hr.firstChild; e.firstChild;) e.removeChild(e.firstChild);
        for (; t.firstChild;) e.appendChild(t.firstChild)
    }
});

function An(e, t) {
    if (t) {
        var n = e.firstChild;
        if (n && n === e.lastChild && n.nodeType === 3) {
            n.nodeValue = t;
            return
        }
    }
    e.textContent = t
}
var Tn = {
        animationIterationCount: !0,
        aspectRatio: !0,
        borderImageOutset: !0,
        borderImageSlice: !0,
        borderImageWidth: !0,
        boxFlex: !0,
        boxFlexGroup: !0,
        boxOrdinalGroup: !0,
        columnCount: !0,
        columns: !0,
        flex: !0,
        flexGrow: !0,
        flexPositive: !0,
        flexShrink: !0,
        flexNegative: !0,
        flexOrder: !0,
        gridArea: !0,
        gridRow: !0,
        gridRowEnd: !0,
        gridRowSpan: !0,
        gridRowStart: !0,
        gridColumn: !0,
        gridColumnEnd: !0,
        gridColumnSpan: !0,
        gridColumnStart: !0,
        fontWeight: !0,
        lineClamp: !0,
        lineHeight: !0,
        opacity: !0,
        order: !0,
        orphans: !0,
        tabSize: !0,
        widows: !0,
        zIndex: !0,
        zoom: !0,
        fillOpacity: !0,
        floodOpacity: !0,
        stopOpacity: !0,
        strokeDasharray: !0,
        strokeDashoffset: !0,
        strokeMiterlimit: !0,
        strokeOpacity: !0,
        strokeWidth: !0
    },
    zd = ["Webkit", "ms", "Moz", "O"];
Object.keys(Tn).forEach(function(e) {
    zd.forEach(function(t) {
        t = t + e.charAt(0).toUpperCase() + e.substring(1), Tn[t] = Tn[e]
    })
});

function Vs(e, t, n) {
    return t == null || typeof t == "boolean" || t === "" ? "" : n || typeof t != "number" || t === 0 || Tn.hasOwnProperty(e) && Tn[e] ? ("" + t).trim() : t + "px"
}

function Hs(e, t) {
    e = e.style;
    for (var n in t)
        if (t.hasOwnProperty(n)) {
            var r = n.indexOf("--") === 0,
                l = Vs(n, t[n], r);
            n === "float" && (n = "cssFloat"), r ? e.setProperty(n, l) : e[n] = l
        }
}
var Md = V({
    menuitem: !0
}, {
    area: !0,
    base: !0,
    br: !0,
    col: !0,
    embed: !0,
    hr: !0,
    img: !0,
    input: !0,
    keygen: !0,
    link: !0,
    meta: !0,
    param: !0,
    source: !0,
    track: !0,
    wbr: !0
});

function xo(e, t) {
    if (t) {
        if (Md[e] && (t.children != null || t.dangerouslySetInnerHTML != null)) throw Error(S(137, e));
        if (t.dangerouslySetInnerHTML != null) {
            if (t.children != null) throw Error(S(60));
            if (typeof t.dangerouslySetInnerHTML != "object" || !("__html" in t.dangerouslySetInnerHTML)) throw Error(S(61))
        }
        if (t.style != null && typeof t.style != "object") throw Error(S(62))
    }
}

function wo(e, t) {
    if (e.indexOf("-") === -1) return typeof t.is == "string";
    switch (e) {
        case "annotation-xml":
        case "color-profile":
        case "font-face":
        case "font-face-src":
        case "font-face-uri":
        case "font-face-format":
        case "font-face-name":
        case "missing-glyph":
            return !1;
        default:
            return !0
    }
}
var So = null;

function pi(e) {
    return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e
}
var ko = null,
    qt = null,
    Jt = null;

function du(e) {
    if (e = ir(e)) {
        if (typeof ko != "function") throw Error(S(280));
        var t = e.stateNode;
        t && (t = gl(t), ko(e.stateNode, e.type, t))
    }
}

function Ws(e) {
    qt ? Jt ? Jt.push(e) : Jt = [e] : qt = e
}

function Qs() {
    if (qt) {
        var e = qt,
            t = Jt;
        if (Jt = qt = null, du(e), t)
            for (e = 0; e < t.length; e++) du(t[e])
    }
}

function Ks(e, t) {
    return e(t)
}

function Ys() {}
var Al = !1;

function Gs(e, t, n) {
    if (Al) return e(t, n);
    Al = !0;
    try {
        return Ks(e, t, n)
    } finally {
        Al = !1, (qt !== null || Jt !== null) && (Ys(), Qs())
    }
}

function $n(e, t) {
    var n = e.stateNode;
    if (n === null) return null;
    var r = gl(n);
    if (r === null) return null;
    n = r[t];
    e: switch (t) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
            (r = !r.disabled) || (e = e.type, r = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !r;
            break e;
        default:
            e = !1
    }
    if (e) return null;
    if (n && typeof n != "function") throw Error(S(231, t, typeof n));
    return n
}
var Eo = !1;
if (Ye) try {
    var yn = {};
    Object.defineProperty(yn, "passive", {
        get: function() {
            Eo = !0
        }
    }), window.addEventListener("test", yn, yn), window.removeEventListener("test", yn, yn)
} catch {
    Eo = !1
}

function Id(e, t, n, r, l, o, i, u, s) {
    var a = Array.prototype.slice.call(arguments, 3);
    try {
        t.apply(n, a)
    } catch (v) {
        this.onError(v)
    }
}
var Rn = !1,
    Vr = null,
    Hr = !1,
    No = null,
    Fd = {
        onError: function(e) {
            Rn = !0, Vr = e
        }
    };

function Dd(e, t, n, r, l, o, i, u, s) {
    Rn = !1, Vr = null, Id.apply(Fd, arguments)
}

function Ud(e, t, n, r, l, o, i, u, s) {
    if (Dd.apply(this, arguments), Rn) {
        if (Rn) {
            var a = Vr;
            Rn = !1, Vr = null
        } else throw Error(S(198));
        Hr || (Hr = !0, No = a)
    }
}

function Ft(e) {
    var t = e,
        n = e;
    if (e.alternate)
        for (; t.return;) t = t.return;
    else {
        e = t;
        do t = e, t.flags & 4098 && (n = t.return), e = t.return; while (e)
    }
    return t.tag === 3 ? n : null
}

function Xs(e) {
    if (e.tag === 13) {
        var t = e.memoizedState;
        if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
    }
    return null
}

function fu(e) {
    if (Ft(e) !== e) throw Error(S(188))
}

function Ad(e) {
    var t = e.alternate;
    if (!t) {
        if (t = Ft(e), t === null) throw Error(S(188));
        return t !== e ? null : e
    }
    for (var n = e, r = t;;) {
        var l = n.return;
        if (l === null) break;
        var o = l.alternate;
        if (o === null) {
            if (r = l.return, r !== null) {
                n = r;
                continue
            }
            break
        }
        if (l.child === o.child) {
            for (o = l.child; o;) {
                if (o === n) return fu(l), e;
                if (o === r) return fu(l), t;
                o = o.sibling
            }
            throw Error(S(188))
        }
        if (n.return !== r.return) n = l, r = o;
        else {
            for (var i = !1, u = l.child; u;) {
                if (u === n) {
                    i = !0, n = l, r = o;
                    break
                }
                if (u === r) {
                    i = !0, r = l, n = o;
                    break
                }
                u = u.sibling
            }
            if (!i) {
                for (u = o.child; u;) {
                    if (u === n) {
                        i = !0, n = o, r = l;
                        break
                    }
                    if (u === r) {
                        i = !0, r = o, n = l;
                        break
                    }
                    u = u.sibling
                }
                if (!i) throw Error(S(189))
            }
        }
        if (n.alternate !== r) throw Error(S(190))
    }
    if (n.tag !== 3) throw Error(S(188));
    return n.stateNode.current === n ? e : t
}

function Zs(e) {
    return e = Ad(e), e !== null ? qs(e) : null
}

function qs(e) {
    if (e.tag === 5 || e.tag === 6) return e;
    for (e = e.child; e !== null;) {
        var t = qs(e);
        if (t !== null) return t;
        e = e.sibling
    }
    return null
}
var Js = we.unstable_scheduleCallback,
    pu = we.unstable_cancelCallback,
    $d = we.unstable_shouldYield,
    Bd = we.unstable_requestPaint,
    K = we.unstable_now,
    Vd = we.unstable_getCurrentPriorityLevel,
    hi = we.unstable_ImmediatePriority,
    bs = we.unstable_UserBlockingPriority,
    Wr = we.unstable_NormalPriority,
    Hd = we.unstable_LowPriority,
    ea = we.unstable_IdlePriority,
    pl = null,
    $e = null;

function Wd(e) {
    if ($e && typeof $e.onCommitFiberRoot == "function") try {
        $e.onCommitFiberRoot(pl, e, void 0, (e.current.flags & 128) === 128)
    } catch {}
}
var Me = Math.clz32 ? Math.clz32 : Yd,
    Qd = Math.log,
    Kd = Math.LN2;

function Yd(e) {
    return e >>>= 0, e === 0 ? 32 : 31 - (Qd(e) / Kd | 0) | 0
}
var mr = 64,
    vr = 4194304;

function _n(e) {
    switch (e & -e) {
        case 1:
            return 1;
        case 2:
            return 2;
        case 4:
            return 4;
        case 8:
            return 8;
        case 16:
            return 16;
        case 32:
            return 32;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
            return e & 4194240;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
            return e & 130023424;
        case 134217728:
            return 134217728;
        case 268435456:
            return 268435456;
        case 536870912:
            return 536870912;
        case 1073741824:
            return 1073741824;
        default:
            return e
    }
}

function Qr(e, t) {
    var n = e.pendingLanes;
    if (n === 0) return 0;
    var r = 0,
        l = e.suspendedLanes,
        o = e.pingedLanes,
        i = n & 268435455;
    if (i !== 0) {
        var u = i & ~l;
        u !== 0 ? r = _n(u) : (o &= i, o !== 0 && (r = _n(o)))
    } else i = n & ~l, i !== 0 ? r = _n(i) : o !== 0 && (r = _n(o));
    if (r === 0) return 0;
    if (t !== 0 && t !== r && !(t & l) && (l = r & -r, o = t & -t, l >= o || l === 16 && (o & 4194240) !== 0)) return t;
    if (r & 4 && (r |= n & 16), t = e.entangledLanes, t !== 0)
        for (e = e.entanglements, t &= r; 0 < t;) n = 31 - Me(t), l = 1 << n, r |= e[n], t &= ~l;
    return r
}

function Gd(e, t) {
    switch (e) {
        case 1:
        case 2:
        case 4:
            return t + 250;
        case 8:
        case 16:
        case 32:
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
            return t + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
            return -1;
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
            return -1;
        default:
            return -1
    }
}

function Xd(e, t) {
    for (var n = e.suspendedLanes, r = e.pingedLanes, l = e.expirationTimes, o = e.pendingLanes; 0 < o;) {
        var i = 31 - Me(o),
            u = 1 << i,
            s = l[i];
        s === -1 ? (!(u & n) || u & r) && (l[i] = Gd(u, t)) : s <= t && (e.expiredLanes |= u), o &= ~u
    }
}

function Co(e) {
    return e = e.pendingLanes & -1073741825, e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
}

function ta() {
    var e = mr;
    return mr <<= 1, !(mr & 4194240) && (mr = 64), e
}

function $l(e) {
    for (var t = [], n = 0; 31 > n; n++) t.push(e);
    return t
}

function lr(e, t, n) {
    e.pendingLanes |= t, t !== 536870912 && (e.suspendedLanes = 0, e.pingedLanes = 0), e = e.eventTimes, t = 31 - Me(t), e[t] = n
}

function Zd(e, t) {
    var n = e.pendingLanes & ~t;
    e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
    var r = e.eventTimes;
    for (e = e.expirationTimes; 0 < n;) {
        var l = 31 - Me(n),
            o = 1 << l;
        t[l] = 0, r[l] = -1, e[l] = -1, n &= ~o
    }
}

function mi(e, t) {
    var n = e.entangledLanes |= t;
    for (e = e.entanglements; n;) {
        var r = 31 - Me(n),
            l = 1 << r;
        l & t | e[r] & t && (e[r] |= t), n &= ~l
    }
}
var I = 0;

function na(e) {
    return e &= -e, 1 < e ? 4 < e ? e & 268435455 ? 16 : 536870912 : 4 : 1
}
var ra, vi, la, oa, ia, jo = !1,
    gr = [],
    ut = null,
    st = null,
    at = null,
    Bn = new Map,
    Vn = new Map,
    nt = [],
    qd = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");

function hu(e, t) {
    switch (e) {
        case "focusin":
        case "focusout":
            ut = null;
            break;
        case "dragenter":
        case "dragleave":
            st = null;
            break;
        case "mouseover":
        case "mouseout":
            at = null;
            break;
        case "pointerover":
        case "pointerout":
            Bn.delete(t.pointerId);
            break;
        case "gotpointercapture":
        case "lostpointercapture":
            Vn.delete(t.pointerId)
    }
}

function xn(e, t, n, r, l, o) {
    return e === null || e.nativeEvent !== o ? (e = {
        blockedOn: t,
        domEventName: n,
        eventSystemFlags: r,
        nativeEvent: o,
        targetContainers: [l]
    }, t !== null && (t = ir(t), t !== null && vi(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, l !== null && t.indexOf(l) === -1 && t.push(l), e)
}

function Jd(e, t, n, r, l) {
    switch (t) {
        case "focusin":
            return ut = xn(ut, e, t, n, r, l), !0;
        case "dragenter":
            return st = xn(st, e, t, n, r, l), !0;
        case "mouseover":
            return at = xn(at, e, t, n, r, l), !0;
        case "pointerover":
            var o = l.pointerId;
            return Bn.set(o, xn(Bn.get(o) || null, e, t, n, r, l)), !0;
        case "gotpointercapture":
            return o = l.pointerId, Vn.set(o, xn(Vn.get(o) || null, e, t, n, r, l)), !0
    }
    return !1
}

function ua(e) {
    var t = Nt(e.target);
    if (t !== null) {
        var n = Ft(t);
        if (n !== null) {
            if (t = n.tag, t === 13) {
                if (t = Xs(n), t !== null) {
                    e.blockedOn = t, ia(e.priority, function() {
                        la(n)
                    });
                    return
                }
            } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
                e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
                return
            }
        }
    }
    e.blockedOn = null
}

function Rr(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length;) {
        var n = _o(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
        if (n === null) {
            n = e.nativeEvent;
            var r = new n.constructor(n.type, n);
            So = r, n.target.dispatchEvent(r), So = null
        } else return t = ir(n), t !== null && vi(t), e.blockedOn = n, !1;
        t.shift()
    }
    return !0
}

function mu(e, t, n) {
    Rr(e) && n.delete(t)
}

function bd() {
    jo = !1, ut !== null && Rr(ut) && (ut = null), st !== null && Rr(st) && (st = null), at !== null && Rr(at) && (at = null), Bn.forEach(mu), Vn.forEach(mu)
}

function wn(e, t) {
    e.blockedOn === t && (e.blockedOn = null, jo || (jo = !0, we.unstable_scheduleCallback(we.unstable_NormalPriority, bd)))
}

function Hn(e) {
    function t(l) {
        return wn(l, e)
    }
    if (0 < gr.length) {
        wn(gr[0], e);
        for (var n = 1; n < gr.length; n++) {
            var r = gr[n];
            r.blockedOn === e && (r.blockedOn = null)
        }
    }
    for (ut !== null && wn(ut, e), st !== null && wn(st, e), at !== null && wn(at, e), Bn.forEach(t), Vn.forEach(t), n = 0; n < nt.length; n++) r = nt[n], r.blockedOn === e && (r.blockedOn = null);
    for (; 0 < nt.length && (n = nt[0], n.blockedOn === null);) ua(n), n.blockedOn === null && nt.shift()
}
var bt = qe.ReactCurrentBatchConfig,
    Kr = !0;

function ef(e, t, n, r) {
    var l = I,
        o = bt.transition;
    bt.transition = null;
    try {
        I = 1, gi(e, t, n, r)
    } finally {
        I = l, bt.transition = o
    }
}

function tf(e, t, n, r) {
    var l = I,
        o = bt.transition;
    bt.transition = null;
    try {
        I = 4, gi(e, t, n, r)
    } finally {
        I = l, bt.transition = o
    }
}

function gi(e, t, n, r) {
    if (Kr) {
        var l = _o(e, t, n, r);
        if (l === null) Zl(e, t, r, Yr, n), hu(e, r);
        else if (Jd(l, e, t, n, r)) r.stopPropagation();
        else if (hu(e, r), t & 4 && -1 < qd.indexOf(e)) {
            for (; l !== null;) {
                var o = ir(l);
                if (o !== null && ra(o), o = _o(e, t, n, r), o === null && Zl(e, t, r, Yr, n), o === l) break;
                l = o
            }
            l !== null && r.stopPropagation()
        } else Zl(e, t, r, null, n)
    }
}
var Yr = null;

function _o(e, t, n, r) {
    if (Yr = null, e = pi(r), e = Nt(e), e !== null)
        if (t = Ft(e), t === null) e = null;
        else if (n = t.tag, n === 13) {
        if (e = Xs(t), e !== null) return e;
        e = null
    } else if (n === 3) {
        if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
        e = null
    } else t !== e && (e = null);
    return Yr = e, null
}

function sa(e) {
    switch (e) {
        case "cancel":
        case "click":
        case "close":
        case "contextmenu":
        case "copy":
        case "cut":
        case "auxclick":
        case "dblclick":
        case "dragend":
        case "dragstart":
        case "drop":
        case "focusin":
        case "focusout":
        case "input":
        case "invalid":
        case "keydown":
        case "keypress":
        case "keyup":
        case "mousedown":
        case "mouseup":
        case "paste":
        case "pause":
        case "play":
        case "pointercancel":
        case "pointerdown":
        case "pointerup":
        case "ratechange":
        case "reset":
        case "resize":
        case "seeked":
        case "submit":
        case "touchcancel":
        case "touchend":
        case "touchstart":
        case "volumechange":
        case "change":
        case "selectionchange":
        case "textInput":
        case "compositionstart":
        case "compositionend":
        case "compositionupdate":
        case "beforeblur":
        case "afterblur":
        case "beforeinput":
        case "blur":
        case "fullscreenchange":
        case "focus":
        case "hashchange":
        case "popstate":
        case "select":
        case "selectstart":
            return 1;
        case "drag":
        case "dragenter":
        case "dragexit":
        case "dragleave":
        case "dragover":
        case "mousemove":
        case "mouseout":
        case "mouseover":
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "scroll":
        case "toggle":
        case "touchmove":
        case "wheel":
        case "mouseenter":
        case "mouseleave":
        case "pointerenter":
        case "pointerleave":
            return 4;
        case "message":
            switch (Vd()) {
                case hi:
                    return 1;
                case bs:
                    return 4;
                case Wr:
                case Hd:
                    return 16;
                case ea:
                    return 536870912;
                default:
                    return 16
            }
        default:
            return 16
    }
}
var lt = null,
    yi = null,
    Lr = null;

function aa() {
    if (Lr) return Lr;
    var e, t = yi,
        n = t.length,
        r, l = "value" in lt ? lt.value : lt.textContent,
        o = l.length;
    for (e = 0; e < n && t[e] === l[e]; e++);
    var i = n - e;
    for (r = 1; r <= i && t[n - r] === l[o - r]; r++);
    return Lr = l.slice(e, 1 < r ? 1 - r : void 0)
}

function Or(e) {
    var t = e.keyCode;
    return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0
}

function yr() {
    return !0
}

function vu() {
    return !1
}

function ke(e) {
    function t(n, r, l, o, i) {
        this._reactName = n, this._targetInst = l, this.type = r, this.nativeEvent = o, this.target = i, this.currentTarget = null;
        for (var u in e) e.hasOwnProperty(u) && (n = e[u], this[u] = n ? n(o) : o[u]);
        return this.isDefaultPrevented = (o.defaultPrevented != null ? o.defaultPrevented : o.returnValue === !1) ? yr : vu, this.isPropagationStopped = vu, this
    }
    return V(t.prototype, {
        preventDefault: function() {
            this.defaultPrevented = !0;
            var n = this.nativeEvent;
            n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = yr)
        },
        stopPropagation: function() {
            var n = this.nativeEvent;
            n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = yr)
        },
        persist: function() {},
        isPersistent: yr
    }), t
}
var dn = {
        eventPhase: 0,
        bubbles: 0,
        cancelable: 0,
        timeStamp: function(e) {
            return e.timeStamp || Date.now()
        },
        defaultPrevented: 0,
        isTrusted: 0
    },
    xi = ke(dn),
    or = V({}, dn, {
        view: 0,
        detail: 0
    }),
    nf = ke(or),
    Bl, Vl, Sn, hl = V({}, or, {
        screenX: 0,
        screenY: 0,
        clientX: 0,
        clientY: 0,
        pageX: 0,
        pageY: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        getModifierState: wi,
        button: 0,
        buttons: 0,
        relatedTarget: function(e) {
            return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
        },
        movementX: function(e) {
            return "movementX" in e ? e.movementX : (e !== Sn && (Sn && e.type === "mousemove" ? (Bl = e.screenX - Sn.screenX, Vl = e.screenY - Sn.screenY) : Vl = Bl = 0, Sn = e), Bl)
        },
        movementY: function(e) {
            return "movementY" in e ? e.movementY : Vl
        }
    }),
    gu = ke(hl),
    rf = V({}, hl, {
        dataTransfer: 0
    }),
    lf = ke(rf),
    of = V({}, or, {
        relatedTarget: 0
    }),
    Hl = ke( of ),
    uf = V({}, dn, {
        animationName: 0,
        elapsedTime: 0,
        pseudoElement: 0
    }),
    sf = ke(uf),
    af = V({}, dn, {
        clipboardData: function(e) {
            return "clipboardData" in e ? e.clipboardData : window.clipboardData
        }
    }),
    cf = ke(af),
    df = V({}, dn, {
        data: 0
    }),
    yu = ke(df),
    ff = {
        Esc: "Escape",
        Spacebar: " ",
        Left: "ArrowLeft",
        Up: "ArrowUp",
        Right: "ArrowRight",
        Down: "ArrowDown",
        Del: "Delete",
        Win: "OS",
        Menu: "ContextMenu",
        Apps: "ContextMenu",
        Scroll: "ScrollLock",
        MozPrintableKey: "Unidentified"
    },
    pf = {
        8: "Backspace",
        9: "Tab",
        12: "Clear",
        13: "Enter",
        16: "Shift",
        17: "Control",
        18: "Alt",
        19: "Pause",
        20: "CapsLock",
        27: "Escape",
        32: " ",
        33: "PageUp",
        34: "PageDown",
        35: "End",
        36: "Home",
        37: "ArrowLeft",
        38: "ArrowUp",
        39: "ArrowRight",
        40: "ArrowDown",
        45: "Insert",
        46: "Delete",
        112: "F1",
        113: "F2",
        114: "F3",
        115: "F4",
        116: "F5",
        117: "F6",
        118: "F7",
        119: "F8",
        120: "F9",
        121: "F10",
        122: "F11",
        123: "F12",
        144: "NumLock",
        145: "ScrollLock",
        224: "Meta"
    },
    hf = {
        Alt: "altKey",
        Control: "ctrlKey",
        Meta: "metaKey",
        Shift: "shiftKey"
    };

function mf(e) {
    var t = this.nativeEvent;
    return t.getModifierState ? t.getModifierState(e) : (e = hf[e]) ? !!t[e] : !1
}

function wi() {
    return mf
}
var vf = V({}, or, {
        key: function(e) {
            if (e.key) {
                var t = ff[e.key] || e.key;
                if (t !== "Unidentified") return t
            }
            return e.type === "keypress" ? (e = Or(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? pf[e.keyCode] || "Unidentified" : ""
        },
        code: 0,
        location: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        repeat: 0,
        locale: 0,
        getModifierState: wi,
        charCode: function(e) {
            return e.type === "keypress" ? Or(e) : 0
        },
        keyCode: function(e) {
            return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
        },
        which: function(e) {
            return e.type === "keypress" ? Or(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
        }
    }),
    gf = ke(vf),
    yf = V({}, hl, {
        pointerId: 0,
        width: 0,
        height: 0,
        pressure: 0,
        tangentialPressure: 0,
        tiltX: 0,
        tiltY: 0,
        twist: 0,
        pointerType: 0,
        isPrimary: 0
    }),
    xu = ke(yf),
    xf = V({}, or, {
        touches: 0,
        targetTouches: 0,
        changedTouches: 0,
        altKey: 0,
        metaKey: 0,
        ctrlKey: 0,
        shiftKey: 0,
        getModifierState: wi
    }),
    wf = ke(xf),
    Sf = V({}, dn, {
        propertyName: 0,
        elapsedTime: 0,
        pseudoElement: 0
    }),
    kf = ke(Sf),
    Ef = V({}, hl, {
        deltaX: function(e) {
            return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0
        },
        deltaY: function(e) {
            return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0
        },
        deltaZ: 0,
        deltaMode: 0
    }),
    Nf = ke(Ef),
    Cf = [9, 13, 27, 32],
    Si = Ye && "CompositionEvent" in window,
    Ln = null;
Ye && "documentMode" in document && (Ln = document.documentMode);
var jf = Ye && "TextEvent" in window && !Ln,
    ca = Ye && (!Si || Ln && 8 < Ln && 11 >= Ln),
    wu = " ",
    Su = !1;

function da(e, t) {
    switch (e) {
        case "keyup":
            return Cf.indexOf(t.keyCode) !== -1;
        case "keydown":
            return t.keyCode !== 229;
        case "keypress":
        case "mousedown":
        case "focusout":
            return !0;
        default:
            return !1
    }
}

function fa(e) {
    return e = e.detail, typeof e == "object" && "data" in e ? e.data : null
}
var $t = !1;

function _f(e, t) {
    switch (e) {
        case "compositionend":
            return fa(t);
        case "keypress":
            return t.which !== 32 ? null : (Su = !0, wu);
        case "textInput":
            return e = t.data, e === wu && Su ? null : e;
        default:
            return null
    }
}

function Pf(e, t) {
    if ($t) return e === "compositionend" || !Si && da(e, t) ? (e = aa(), Lr = yi = lt = null, $t = !1, e) : null;
    switch (e) {
        case "paste":
            return null;
        case "keypress":
            if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
                if (t.char && 1 < t.char.length) return t.char;
                if (t.which) return String.fromCharCode(t.which)
            }
            return null;
        case "compositionend":
            return ca && t.locale !== "ko" ? null : t.data;
        default:
            return null
    }
}
var Tf = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
};

function ku(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!Tf[e.type] : t === "textarea"
}

function pa(e, t, n, r) {
    Ws(r), t = Gr(t, "onChange"), 0 < t.length && (n = new xi("onChange", "change", null, n, r), e.push({
        event: n,
        listeners: t
    }))
}
var On = null,
    Wn = null;

function Rf(e) {
    Na(e, 0)
}

function ml(e) {
    var t = Ht(e);
    if (Ds(t)) return e
}

function Lf(e, t) {
    if (e === "change") return t
}
var ha = !1;
if (Ye) {
    var Wl;
    if (Ye) {
        var Ql = "oninput" in document;
        if (!Ql) {
            var Eu = document.createElement("div");
            Eu.setAttribute("oninput", "return;"), Ql = typeof Eu.oninput == "function"
        }
        Wl = Ql
    } else Wl = !1;
    ha = Wl && (!document.documentMode || 9 < document.documentMode)
}

function Nu() {
    On && (On.detachEvent("onpropertychange", ma), Wn = On = null)
}

function ma(e) {
    if (e.propertyName === "value" && ml(Wn)) {
        var t = [];
        pa(t, Wn, e, pi(e)), Gs(Rf, t)
    }
}

function Of(e, t, n) {
    e === "focusin" ? (Nu(), On = t, Wn = n, On.attachEvent("onpropertychange", ma)) : e === "focusout" && Nu()
}

function zf(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown") return ml(Wn)
}

function Mf(e, t) {
    if (e === "click") return ml(t)
}

function If(e, t) {
    if (e === "input" || e === "change") return ml(t)
}

function Ff(e, t) {
    return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t
}
var Fe = typeof Object.is == "function" ? Object.is : Ff;

function Qn(e, t) {
    if (Fe(e, t)) return !0;
    if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
    var n = Object.keys(e),
        r = Object.keys(t);
    if (n.length !== r.length) return !1;
    for (r = 0; r < n.length; r++) {
        var l = n[r];
        if (!so.call(t, l) || !Fe(e[l], t[l])) return !1
    }
    return !0
}

function Cu(e) {
    for (; e && e.firstChild;) e = e.firstChild;
    return e
}

function ju(e, t) {
    var n = Cu(e);
    e = 0;
    for (var r; n;) {
        if (n.nodeType === 3) {
            if (r = e + n.textContent.length, e <= t && r >= t) return {
                node: n,
                offset: t - e
            };
            e = r
        }
        e: {
            for (; n;) {
                if (n.nextSibling) {
                    n = n.nextSibling;
                    break e
                }
                n = n.parentNode
            }
            n = void 0
        }
        n = Cu(n)
    }
}

function va(e, t) {
    return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? va(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1
}

function ga() {
    for (var e = window, t = Br(); t instanceof e.HTMLIFrameElement;) {
        try {
            var n = typeof t.contentWindow.location.href == "string"
        } catch {
            n = !1
        }
        if (n) e = t.contentWindow;
        else break;
        t = Br(e.document)
    }
    return t
}

function ki(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true")
}

function Df(e) {
    var t = ga(),
        n = e.focusedElem,
        r = e.selectionRange;
    if (t !== n && n && n.ownerDocument && va(n.ownerDocument.documentElement, n)) {
        if (r !== null && ki(n)) {
            if (t = r.start, e = r.end, e === void 0 && (e = t), "selectionStart" in n) n.selectionStart = t, n.selectionEnd = Math.min(e, n.value.length);
            else if (e = (t = n.ownerDocument || document) && t.defaultView || window, e.getSelection) {
                e = e.getSelection();
                var l = n.textContent.length,
                    o = Math.min(r.start, l);
                r = r.end === void 0 ? o : Math.min(r.end, l), !e.extend && o > r && (l = r, r = o, o = l), l = ju(n, o);
                var i = ju(n, r);
                l && i && (e.rangeCount !== 1 || e.anchorNode !== l.node || e.anchorOffset !== l.offset || e.focusNode !== i.node || e.focusOffset !== i.offset) && (t = t.createRange(), t.setStart(l.node, l.offset), e.removeAllRanges(), o > r ? (e.addRange(t), e.extend(i.node, i.offset)) : (t.setEnd(i.node, i.offset), e.addRange(t)))
            }
        }
        for (t = [], e = n; e = e.parentNode;) e.nodeType === 1 && t.push({
            element: e,
            left: e.scrollLeft,
            top: e.scrollTop
        });
        for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++) e = t[n], e.element.scrollLeft = e.left, e.element.scrollTop = e.top
    }
}
var Uf = Ye && "documentMode" in document && 11 >= document.documentMode,
    Bt = null,
    Po = null,
    zn = null,
    To = !1;

function _u(e, t, n) {
    var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    To || Bt == null || Bt !== Br(r) || (r = Bt, "selectionStart" in r && ki(r) ? r = {
        start: r.selectionStart,
        end: r.selectionEnd
    } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = {
        anchorNode: r.anchorNode,
        anchorOffset: r.anchorOffset,
        focusNode: r.focusNode,
        focusOffset: r.focusOffset
    }), zn && Qn(zn, r) || (zn = r, r = Gr(Po, "onSelect"), 0 < r.length && (t = new xi("onSelect", "select", null, t, n), e.push({
        event: t,
        listeners: r
    }), t.target = Bt)))
}

function xr(e, t) {
    var n = {};
    return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n
}
var Vt = {
        animationend: xr("Animation", "AnimationEnd"),
        animationiteration: xr("Animation", "AnimationIteration"),
        animationstart: xr("Animation", "AnimationStart"),
        transitionend: xr("Transition", "TransitionEnd")
    },
    Kl = {},
    ya = {};
Ye && (ya = document.createElement("div").style, "AnimationEvent" in window || (delete Vt.animationend.animation, delete Vt.animationiteration.animation, delete Vt.animationstart.animation), "TransitionEvent" in window || delete Vt.transitionend.transition);

function vl(e) {
    if (Kl[e]) return Kl[e];
    if (!Vt[e]) return e;
    var t = Vt[e],
        n;
    for (n in t)
        if (t.hasOwnProperty(n) && n in ya) return Kl[e] = t[n];
    return e
}
var xa = vl("animationend"),
    wa = vl("animationiteration"),
    Sa = vl("animationstart"),
    ka = vl("transitionend"),
    Ea = new Map,
    Pu = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");

function gt(e, t) {
    Ea.set(e, t), It(t, [e])
}
for (var Yl = 0; Yl < Pu.length; Yl++) {
    var Gl = Pu[Yl],
        Af = Gl.toLowerCase(),
        $f = Gl[0].toUpperCase() + Gl.slice(1);
    gt(Af, "on" + $f)
}
gt(xa, "onAnimationEnd");
gt(wa, "onAnimationIteration");
gt(Sa, "onAnimationStart");
gt("dblclick", "onDoubleClick");
gt("focusin", "onFocus");
gt("focusout", "onBlur");
gt(ka, "onTransitionEnd");
nn("onMouseEnter", ["mouseout", "mouseover"]);
nn("onMouseLeave", ["mouseout", "mouseover"]);
nn("onPointerEnter", ["pointerout", "pointerover"]);
nn("onPointerLeave", ["pointerout", "pointerover"]);
It("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
It("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
It("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
It("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
It("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
It("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var Pn = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
    Bf = new Set("cancel close invalid load scroll toggle".split(" ").concat(Pn));

function Tu(e, t, n) {
    var r = e.type || "unknown-event";
    e.currentTarget = n, Ud(r, t, void 0, e), e.currentTarget = null
}

function Na(e, t) {
    t = (t & 4) !== 0;
    for (var n = 0; n < e.length; n++) {
        var r = e[n],
            l = r.event;
        r = r.listeners;
        e: {
            var o = void 0;
            if (t)
                for (var i = r.length - 1; 0 <= i; i--) {
                    var u = r[i],
                        s = u.instance,
                        a = u.currentTarget;
                    if (u = u.listener, s !== o && l.isPropagationStopped()) break e;
                    Tu(l, u, a), o = s
                } else
                    for (i = 0; i < r.length; i++) {
                        if (u = r[i], s = u.instance, a = u.currentTarget, u = u.listener, s !== o && l.isPropagationStopped()) break e;
                        Tu(l, u, a), o = s
                    }
        }
    }
    if (Hr) throw e = No, Hr = !1, No = null, e
}

function D(e, t) {
    var n = t[Mo];
    n === void 0 && (n = t[Mo] = new Set);
    var r = e + "__bubble";
    n.has(r) || (Ca(t, e, 2, !1), n.add(r))
}

function Xl(e, t, n) {
    var r = 0;
    t && (r |= 4), Ca(n, e, r, t)
}
var wr = "_reactListening" + Math.random().toString(36).slice(2);

function Kn(e) {
    if (!e[wr]) {
        e[wr] = !0, Os.forEach(function(n) {
            n !== "selectionchange" && (Bf.has(n) || Xl(n, !1, e), Xl(n, !0, e))
        });
        var t = e.nodeType === 9 ? e : e.ownerDocument;
        t === null || t[wr] || (t[wr] = !0, Xl("selectionchange", !1, t))
    }
}

function Ca(e, t, n, r) {
    switch (sa(t)) {
        case 1:
            var l = ef;
            break;
        case 4:
            l = tf;
            break;
        default:
            l = gi
    }
    n = l.bind(null, t, n, e), l = void 0, !Eo || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (l = !0), r ? l !== void 0 ? e.addEventListener(t, n, {
        capture: !0,
        passive: l
    }) : e.addEventListener(t, n, !0) : l !== void 0 ? e.addEventListener(t, n, {
        passive: l
    }) : e.addEventListener(t, n, !1)
}

function Zl(e, t, n, r, l) {
    var o = r;
    if (!(t & 1) && !(t & 2) && r !== null) e: for (;;) {
        if (r === null) return;
        var i = r.tag;
        if (i === 3 || i === 4) {
            var u = r.stateNode.containerInfo;
            if (u === l || u.nodeType === 8 && u.parentNode === l) break;
            if (i === 4)
                for (i = r.return; i !== null;) {
                    var s = i.tag;
                    if ((s === 3 || s === 4) && (s = i.stateNode.containerInfo, s === l || s.nodeType === 8 && s.parentNode === l)) return;
                    i = i.return
                }
            for (; u !== null;) {
                if (i = Nt(u), i === null) return;
                if (s = i.tag, s === 5 || s === 6) {
                    r = o = i;
                    continue e
                }
                u = u.parentNode
            }
        }
        r = r.return
    }
    Gs(function() {
        var a = o,
            v = pi(n),
            p = [];
        e: {
            var m = Ea.get(e);
            if (m !== void 0) {
                var y = xi,
                    g = e;
                switch (e) {
                    case "keypress":
                        if (Or(n) === 0) break e;
                    case "keydown":
                    case "keyup":
                        y = gf;
                        break;
                    case "focusin":
                        g = "focus", y = Hl;
                        break;
                    case "focusout":
                        g = "blur", y = Hl;
                        break;
                    case "beforeblur":
                    case "afterblur":
                        y = Hl;
                        break;
                    case "click":
                        if (n.button === 2) break e;
                    case "auxclick":
                    case "dblclick":
                    case "mousedown":
                    case "mousemove":
                    case "mouseup":
                    case "mouseout":
                    case "mouseover":
                    case "contextmenu":
                        y = gu;
                        break;
                    case "drag":
                    case "dragend":
                    case "dragenter":
                    case "dragexit":
                    case "dragleave":
                    case "dragover":
                    case "dragstart":
                    case "drop":
                        y = lf;
                        break;
                    case "touchcancel":
                    case "touchend":
                    case "touchmove":
                    case "touchstart":
                        y = wf;
                        break;
                    case xa:
                    case wa:
                    case Sa:
                        y = sf;
                        break;
                    case ka:
                        y = kf;
                        break;
                    case "scroll":
                        y = nf;
                        break;
                    case "wheel":
                        y = Nf;
                        break;
                    case "copy":
                    case "cut":
                    case "paste":
                        y = cf;
                        break;
                    case "gotpointercapture":
                    case "lostpointercapture":
                    case "pointercancel":
                    case "pointerdown":
                    case "pointermove":
                    case "pointerout":
                    case "pointerover":
                    case "pointerup":
                        y = xu
                }
                var w = (t & 4) !== 0,
                    P = !w && e === "scroll",
                    d = w ? m !== null ? m + "Capture" : null : m;
                w = [];
                for (var c = a, h; c !== null;) {
                    h = c;
                    var x = h.stateNode;
                    if (h.tag === 5 && x !== null && (h = x, d !== null && (x = $n(c, d), x != null && w.push(Yn(c, x, h)))), P) break;
                    c = c.return
                }
                0 < w.length && (m = new y(m, g, null, n, v), p.push({
                    event: m,
                    listeners: w
                }))
            }
        }
        if (!(t & 7)) {
            e: {
                if (m = e === "mouseover" || e === "pointerover", y = e === "mouseout" || e === "pointerout", m && n !== So && (g = n.relatedTarget || n.fromElement) && (Nt(g) || g[Ge])) break e;
                if ((y || m) && (m = v.window === v ? v : (m = v.ownerDocument) ? m.defaultView || m.parentWindow : window, y ? (g = n.relatedTarget || n.toElement, y = a, g = g ? Nt(g) : null, g !== null && (P = Ft(g), g !== P || g.tag !== 5 && g.tag !== 6) && (g = null)) : (y = null, g = a), y !== g)) {
                    if (w = gu, x = "onMouseLeave", d = "onMouseEnter", c = "mouse", (e === "pointerout" || e === "pointerover") && (w = xu, x = "onPointerLeave", d = "onPointerEnter", c = "pointer"), P = y == null ? m : Ht(y), h = g == null ? m : Ht(g), m = new w(x, c + "leave", y, n, v), m.target = P, m.relatedTarget = h, x = null, Nt(v) === a && (w = new w(d, c + "enter", g, n, v), w.target = h, w.relatedTarget = P, x = w), P = x, y && g) t: {
                        for (w = y, d = g, c = 0, h = w; h; h = Dt(h)) c++;
                        for (h = 0, x = d; x; x = Dt(x)) h++;
                        for (; 0 < c - h;) w = Dt(w),
                        c--;
                        for (; 0 < h - c;) d = Dt(d),
                        h--;
                        for (; c--;) {
                            if (w === d || d !== null && w === d.alternate) break t;
                            w = Dt(w), d = Dt(d)
                        }
                        w = null
                    }
                    else w = null;
                    y !== null && Ru(p, m, y, w, !1), g !== null && P !== null && Ru(p, P, g, w, !0)
                }
            }
            e: {
                if (m = a ? Ht(a) : window, y = m.nodeName && m.nodeName.toLowerCase(), y === "select" || y === "input" && m.type === "file") var k = Lf;
                else if (ku(m))
                    if (ha) k = If;
                    else {
                        k = zf;
                        var j = Of
                    }
                else(y = m.nodeName) && y.toLowerCase() === "input" && (m.type === "checkbox" || m.type === "radio") && (k = Mf);
                if (k && (k = k(e, a))) {
                    pa(p, k, n, v);
                    break e
                }
                j && j(e, m, a),
                e === "focusout" && (j = m._wrapperState) && j.controlled && m.type === "number" && vo(m, "number", m.value)
            }
            switch (j = a ? Ht(a) : window, e) {
                case "focusin":
                    (ku(j) || j.contentEditable === "true") && (Bt = j, Po = a, zn = null);
                    break;
                case "focusout":
                    zn = Po = Bt = null;
                    break;
                case "mousedown":
                    To = !0;
                    break;
                case "contextmenu":
                case "mouseup":
                case "dragend":
                    To = !1, _u(p, n, v);
                    break;
                case "selectionchange":
                    if (Uf) break;
                case "keydown":
                case "keyup":
                    _u(p, n, v)
            }
            var _;
            if (Si) e: {
                switch (e) {
                    case "compositionstart":
                        var T = "onCompositionStart";
                        break e;
                    case "compositionend":
                        T = "onCompositionEnd";
                        break e;
                    case "compositionupdate":
                        T = "onCompositionUpdate";
                        break e
                }
                T = void 0
            }
            else $t ? da(e, n) && (T = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (T = "onCompositionStart");T && (ca && n.locale !== "ko" && ($t || T !== "onCompositionStart" ? T === "onCompositionEnd" && $t && (_ = aa()) : (lt = v, yi = "value" in lt ? lt.value : lt.textContent, $t = !0)), j = Gr(a, T), 0 < j.length && (T = new yu(T, e, null, n, v), p.push({
                event: T,
                listeners: j
            }), _ ? T.data = _ : (_ = fa(n), _ !== null && (T.data = _)))),
            (_ = jf ? _f(e, n) : Pf(e, n)) && (a = Gr(a, "onBeforeInput"), 0 < a.length && (v = new yu("onBeforeInput", "beforeinput", null, n, v), p.push({
                event: v,
                listeners: a
            }), v.data = _))
        }
        Na(p, t)
    })
}

function Yn(e, t, n) {
    return {
        instance: e,
        listener: t,
        currentTarget: n
    }
}

function Gr(e, t) {
    for (var n = t + "Capture", r = []; e !== null;) {
        var l = e,
            o = l.stateNode;
        l.tag === 5 && o !== null && (l = o, o = $n(e, n), o != null && r.unshift(Yn(e, o, l)), o = $n(e, t), o != null && r.push(Yn(e, o, l))), e = e.return
    }
    return r
}

function Dt(e) {
    if (e === null) return null;
    do e = e.return; while (e && e.tag !== 5);
    return e || null
}

function Ru(e, t, n, r, l) {
    for (var o = t._reactName, i = []; n !== null && n !== r;) {
        var u = n,
            s = u.alternate,
            a = u.stateNode;
        if (s !== null && s === r) break;
        u.tag === 5 && a !== null && (u = a, l ? (s = $n(n, o), s != null && i.unshift(Yn(n, s, u))) : l || (s = $n(n, o), s != null && i.push(Yn(n, s, u)))), n = n.return
    }
    i.length !== 0 && e.push({
        event: t,
        listeners: i
    })
}
var Vf = /\r\n?/g,
    Hf = /\u0000|\uFFFD/g;

function Lu(e) {
    return (typeof e == "string" ? e : "" + e).replace(Vf, `
`).replace(Hf, "")
}

function Sr(e, t, n) {
    if (t = Lu(t), Lu(e) !== t && n) throw Error(S(425))
}

function Xr() {}
var Ro = null,
    Lo = null;

function Oo(e, t) {
    return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null
}
var zo = typeof setTimeout == "function" ? setTimeout : void 0,
    Wf = typeof clearTimeout == "function" ? clearTimeout : void 0,
    Ou = typeof Promise == "function" ? Promise : void 0,
    Qf = typeof queueMicrotask == "function" ? queueMicrotask : typeof Ou < "u" ? function(e) {
        return Ou.resolve(null).then(e).catch(Kf)
    } : zo;

function Kf(e) {
    setTimeout(function() {
        throw e
    })
}

function ql(e, t) {
    var n = t,
        r = 0;
    do {
        var l = n.nextSibling;
        if (e.removeChild(n), l && l.nodeType === 8)
            if (n = l.data, n === "/$") {
                if (r === 0) {
                    e.removeChild(l), Hn(t);
                    return
                }
                r--
            } else n !== "$" && n !== "$?" && n !== "$!" || r++;
        n = l
    } while (n);
    Hn(t)
}

function ct(e) {
    for (; e != null; e = e.nextSibling) {
        var t = e.nodeType;
        if (t === 1 || t === 3) break;
        if (t === 8) {
            if (t = e.data, t === "$" || t === "$!" || t === "$?") break;
            if (t === "/$") return null
        }
    }
    return e
}

function zu(e) {
    e = e.previousSibling;
    for (var t = 0; e;) {
        if (e.nodeType === 8) {
            var n = e.data;
            if (n === "$" || n === "$!" || n === "$?") {
                if (t === 0) return e;
                t--
            } else n === "/$" && t++
        }
        e = e.previousSibling
    }
    return null
}
var fn = Math.random().toString(36).slice(2),
    Ae = "__reactFiber$" + fn,
    Gn = "__reactProps$" + fn,
    Ge = "__reactContainer$" + fn,
    Mo = "__reactEvents$" + fn,
    Yf = "__reactListeners$" + fn,
    Gf = "__reactHandles$" + fn;

function Nt(e) {
    var t = e[Ae];
    if (t) return t;
    for (var n = e.parentNode; n;) {
        if (t = n[Ge] || n[Ae]) {
            if (n = t.alternate, t.child !== null || n !== null && n.child !== null)
                for (e = zu(e); e !== null;) {
                    if (n = e[Ae]) return n;
                    e = zu(e)
                }
            return t
        }
        e = n, n = e.parentNode
    }
    return null
}

function ir(e) {
    return e = e[Ae] || e[Ge], !e || e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3 ? null : e
}

function Ht(e) {
    if (e.tag === 5 || e.tag === 6) return e.stateNode;
    throw Error(S(33))
}

function gl(e) {
    return e[Gn] || null
}
var Io = [],
    Wt = -1;

function yt(e) {
    return {
        current: e
    }
}

function U(e) {
    0 > Wt || (e.current = Io[Wt], Io[Wt] = null, Wt--)
}

function F(e, t) {
    Wt++, Io[Wt] = e.current, e.current = t
}
var vt = {},
    ue = yt(vt),
    he = yt(!1),
    Rt = vt;

function rn(e, t) {
    var n = e.type.contextTypes;
    if (!n) return vt;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t) return r.__reactInternalMemoizedMaskedChildContext;
    var l = {},
        o;
    for (o in n) l[o] = t[o];
    return r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = l), l
}

function me(e) {
    return e = e.childContextTypes, e != null
}

function Zr() {
    U(he), U(ue)
}

function Mu(e, t, n) {
    if (ue.current !== vt) throw Error(S(168));
    F(ue, t), F(he, n)
}

function ja(e, t, n) {
    var r = e.stateNode;
    if (t = t.childContextTypes, typeof r.getChildContext != "function") return n;
    r = r.getChildContext();
    for (var l in r)
        if (!(l in t)) throw Error(S(108, Ld(e) || "Unknown", l));
    return V({}, n, r)
}

function qr(e) {
    return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || vt, Rt = ue.current, F(ue, e), F(he, he.current), !0
}

function Iu(e, t, n) {
    var r = e.stateNode;
    if (!r) throw Error(S(169));
    n ? (e = ja(e, t, Rt), r.__reactInternalMemoizedMergedChildContext = e, U(he), U(ue), F(ue, e)) : U(he), F(he, n)
}
var He = null,
    yl = !1,
    Jl = !1;

function _a(e) {
    He === null ? He = [e] : He.push(e)
}

function Xf(e) {
    yl = !0, _a(e)
}

function xt() {
    if (!Jl && He !== null) {
        Jl = !0;
        var e = 0,
            t = I;
        try {
            var n = He;
            for (I = 1; e < n.length; e++) {
                var r = n[e];
                do r = r(!0); while (r !== null)
            }
            He = null, yl = !1
        } catch (l) {
            throw He !== null && (He = He.slice(e + 1)), Js(hi, xt), l
        } finally {
            I = t, Jl = !1
        }
    }
    return null
}
var Qt = [],
    Kt = 0,
    Jr = null,
    br = 0,
    Ee = [],
    Ne = 0,
    Lt = null,
    We = 1,
    Qe = "";

function kt(e, t) {
    Qt[Kt++] = br, Qt[Kt++] = Jr, Jr = e, br = t
}

function Pa(e, t, n) {
    Ee[Ne++] = We, Ee[Ne++] = Qe, Ee[Ne++] = Lt, Lt = e;
    var r = We;
    e = Qe;
    var l = 32 - Me(r) - 1;
    r &= ~(1 << l), n += 1;
    var o = 32 - Me(t) + l;
    if (30 < o) {
        var i = l - l % 5;
        o = (r & (1 << i) - 1).toString(32), r >>= i, l -= i, We = 1 << 32 - Me(t) + l | n << l | r, Qe = o + e
    } else We = 1 << o | n << l | r, Qe = e
}

function Ei(e) {
    e.return !== null && (kt(e, 1), Pa(e, 1, 0))
}

function Ni(e) {
    for (; e === Jr;) Jr = Qt[--Kt], Qt[Kt] = null, br = Qt[--Kt], Qt[Kt] = null;
    for (; e === Lt;) Lt = Ee[--Ne], Ee[Ne] = null, Qe = Ee[--Ne], Ee[Ne] = null, We = Ee[--Ne], Ee[Ne] = null
}
var xe = null,
    ye = null,
    A = !1,
    ze = null;

function Ta(e, t) {
    var n = Ce(5, null, null, 0);
    n.elementType = "DELETED", n.stateNode = t, n.return = e, t = e.deletions, t === null ? (e.deletions = [n], e.flags |= 16) : t.push(n)
}

function Fu(e, t) {
    switch (e.tag) {
        case 5:
            var n = e.type;
            return t = t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase() ? null : t, t !== null ? (e.stateNode = t, xe = e, ye = ct(t.firstChild), !0) : !1;
        case 6:
            return t = e.pendingProps === "" || t.nodeType !== 3 ? null : t, t !== null ? (e.stateNode = t, xe = e, ye = null, !0) : !1;
        case 13:
            return t = t.nodeType !== 8 ? null : t, t !== null ? (n = Lt !== null ? {
                id: We,
                overflow: Qe
            } : null, e.memoizedState = {
                dehydrated: t,
                treeContext: n,
                retryLane: 1073741824
            }, n = Ce(18, null, null, 0), n.stateNode = t, n.return = e, e.child = n, xe = e, ye = null, !0) : !1;
        default:
            return !1
    }
}

function Fo(e) {
    return (e.mode & 1) !== 0 && (e.flags & 128) === 0
}

function Do(e) {
    if (A) {
        var t = ye;
        if (t) {
            var n = t;
            if (!Fu(e, t)) {
                if (Fo(e)) throw Error(S(418));
                t = ct(n.nextSibling);
                var r = xe;
                t && Fu(e, t) ? Ta(r, n) : (e.flags = e.flags & -4097 | 2, A = !1, xe = e)
            }
        } else {
            if (Fo(e)) throw Error(S(418));
            e.flags = e.flags & -4097 | 2, A = !1, xe = e
        }
    }
}

function Du(e) {
    for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;) e = e.return;
    xe = e
}

function kr(e) {
    if (e !== xe) return !1;
    if (!A) return Du(e), A = !0, !1;
    var t;
    if ((t = e.tag !== 3) && !(t = e.tag !== 5) && (t = e.type, t = t !== "head" && t !== "body" && !Oo(e.type, e.memoizedProps)), t && (t = ye)) {
        if (Fo(e)) throw Ra(), Error(S(418));
        for (; t;) Ta(e, t), t = ct(t.nextSibling)
    }
    if (Du(e), e.tag === 13) {
        if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(S(317));
        e: {
            for (e = e.nextSibling, t = 0; e;) {
                if (e.nodeType === 8) {
                    var n = e.data;
                    if (n === "/$") {
                        if (t === 0) {
                            ye = ct(e.nextSibling);
                            break e
                        }
                        t--
                    } else n !== "$" && n !== "$!" && n !== "$?" || t++
                }
                e = e.nextSibling
            }
            ye = null
        }
    } else ye = xe ? ct(e.stateNode.nextSibling) : null;
    return !0
}

function Ra() {
    for (var e = ye; e;) e = ct(e.nextSibling)
}

function ln() {
    ye = xe = null, A = !1
}

function Ci(e) {
    ze === null ? ze = [e] : ze.push(e)
}
var Zf = qe.ReactCurrentBatchConfig;

function kn(e, t, n) {
    if (e = n.ref, e !== null && typeof e != "function" && typeof e != "object") {
        if (n._owner) {
            if (n = n._owner, n) {
                if (n.tag !== 1) throw Error(S(309));
                var r = n.stateNode
            }
            if (!r) throw Error(S(147, e));
            var l = r,
                o = "" + e;
            return t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === o ? t.ref : (t = function(i) {
                var u = l.refs;
                i === null ? delete u[o] : u[o] = i
            }, t._stringRef = o, t)
        }
        if (typeof e != "string") throw Error(S(284));
        if (!n._owner) throw Error(S(290, e))
    }
    return e
}

function Er(e, t) {
    throw e = Object.prototype.toString.call(t), Error(S(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e))
}

function Uu(e) {
    var t = e._init;
    return t(e._payload)
}

function La(e) {
    function t(d, c) {
        if (e) {
            var h = d.deletions;
            h === null ? (d.deletions = [c], d.flags |= 16) : h.push(c)
        }
    }

    function n(d, c) {
        if (!e) return null;
        for (; c !== null;) t(d, c), c = c.sibling;
        return null
    }

    function r(d, c) {
        for (d = new Map; c !== null;) c.key !== null ? d.set(c.key, c) : d.set(c.index, c), c = c.sibling;
        return d
    }

    function l(d, c) {
        return d = ht(d, c), d.index = 0, d.sibling = null, d
    }

    function o(d, c, h) {
        return d.index = h, e ? (h = d.alternate, h !== null ? (h = h.index, h < c ? (d.flags |= 2, c) : h) : (d.flags |= 2, c)) : (d.flags |= 1048576, c)
    }

    function i(d) {
        return e && d.alternate === null && (d.flags |= 2), d
    }

    function u(d, c, h, x) {
        return c === null || c.tag !== 6 ? (c = oo(h, d.mode, x), c.return = d, c) : (c = l(c, h), c.return = d, c)
    }

    function s(d, c, h, x) {
        var k = h.type;
        return k === At ? v(d, c, h.props.children, x, h.key) : c !== null && (c.elementType === k || typeof k == "object" && k !== null && k.$$typeof === et && Uu(k) === c.type) ? (x = l(c, h.props), x.ref = kn(d, c, h), x.return = d, x) : (x = Ar(h.type, h.key, h.props, null, d.mode, x), x.ref = kn(d, c, h), x.return = d, x)
    }

    function a(d, c, h, x) {
        return c === null || c.tag !== 4 || c.stateNode.containerInfo !== h.containerInfo || c.stateNode.implementation !== h.implementation ? (c = io(h, d.mode, x), c.return = d, c) : (c = l(c, h.children || []), c.return = d, c)
    }

    function v(d, c, h, x, k) {
        return c === null || c.tag !== 7 ? (c = Pt(h, d.mode, x, k), c.return = d, c) : (c = l(c, h), c.return = d, c)
    }

    function p(d, c, h) {
        if (typeof c == "string" && c !== "" || typeof c == "number") return c = oo("" + c, d.mode, h), c.return = d, c;
        if (typeof c == "object" && c !== null) {
            switch (c.$$typeof) {
                case fr:
                    return h = Ar(c.type, c.key, c.props, null, d.mode, h), h.ref = kn(d, null, c), h.return = d, h;
                case Ut:
                    return c = io(c, d.mode, h), c.return = d, c;
                case et:
                    var x = c._init;
                    return p(d, x(c._payload), h)
            }
            if (jn(c) || gn(c)) return c = Pt(c, d.mode, h, null), c.return = d, c;
            Er(d, c)
        }
        return null
    }

    function m(d, c, h, x) {
        var k = c !== null ? c.key : null;
        if (typeof h == "string" && h !== "" || typeof h == "number") return k !== null ? null : u(d, c, "" + h, x);
        if (typeof h == "object" && h !== null) {
            switch (h.$$typeof) {
                case fr:
                    return h.key === k ? s(d, c, h, x) : null;
                case Ut:
                    return h.key === k ? a(d, c, h, x) : null;
                case et:
                    return k = h._init, m(d, c, k(h._payload), x)
            }
            if (jn(h) || gn(h)) return k !== null ? null : v(d, c, h, x, null);
            Er(d, h)
        }
        return null
    }

    function y(d, c, h, x, k) {
        if (typeof x == "string" && x !== "" || typeof x == "number") return d = d.get(h) || null, u(c, d, "" + x, k);
        if (typeof x == "object" && x !== null) {
            switch (x.$$typeof) {
                case fr:
                    return d = d.get(x.key === null ? h : x.key) || null, s(c, d, x, k);
                case Ut:
                    return d = d.get(x.key === null ? h : x.key) || null, a(c, d, x, k);
                case et:
                    var j = x._init;
                    return y(d, c, h, j(x._payload), k)
            }
            if (jn(x) || gn(x)) return d = d.get(h) || null, v(c, d, x, k, null);
            Er(c, x)
        }
        return null
    }

    function g(d, c, h, x) {
        for (var k = null, j = null, _ = c, T = c = 0, W = null; _ !== null && T < h.length; T++) {
            _.index > T ? (W = _, _ = null) : W = _.sibling;
            var z = m(d, _, h[T], x);
            if (z === null) {
                _ === null && (_ = W);
                break
            }
            e && _ && z.alternate === null && t(d, _), c = o(z, c, T), j === null ? k = z : j.sibling = z, j = z, _ = W
        }
        if (T === h.length) return n(d, _), A && kt(d, T), k;
        if (_ === null) {
            for (; T < h.length; T++) _ = p(d, h[T], x), _ !== null && (c = o(_, c, T), j === null ? k = _ : j.sibling = _, j = _);
            return A && kt(d, T), k
        }
        for (_ = r(d, _); T < h.length; T++) W = y(_, d, T, h[T], x), W !== null && (e && W.alternate !== null && _.delete(W.key === null ? T : W.key), c = o(W, c, T), j === null ? k = W : j.sibling = W, j = W);
        return e && _.forEach(function(Te) {
            return t(d, Te)
        }), A && kt(d, T), k
    }

    function w(d, c, h, x) {
        var k = gn(h);
        if (typeof k != "function") throw Error(S(150));
        if (h = k.call(h), h == null) throw Error(S(151));
        for (var j = k = null, _ = c, T = c = 0, W = null, z = h.next(); _ !== null && !z.done; T++, z = h.next()) {
            _.index > T ? (W = _, _ = null) : W = _.sibling;
            var Te = m(d, _, z.value, x);
            if (Te === null) {
                _ === null && (_ = W);
                break
            }
            e && _ && Te.alternate === null && t(d, _), c = o(Te, c, T), j === null ? k = Te : j.sibling = Te, j = Te, _ = W
        }
        if (z.done) return n(d, _), A && kt(d, T), k;
        if (_ === null) {
            for (; !z.done; T++, z = h.next()) z = p(d, z.value, x), z !== null && (c = o(z, c, T), j === null ? k = z : j.sibling = z, j = z);
            return A && kt(d, T), k
        }
        for (_ = r(d, _); !z.done; T++, z = h.next()) z = y(_, d, T, z.value, x), z !== null && (e && z.alternate !== null && _.delete(z.key === null ? T : z.key), c = o(z, c, T), j === null ? k = z : j.sibling = z, j = z);
        return e && _.forEach(function(mn) {
            return t(d, mn)
        }), A && kt(d, T), k
    }

    function P(d, c, h, x) {
        if (typeof h == "object" && h !== null && h.type === At && h.key === null && (h = h.props.children), typeof h == "object" && h !== null) {
            switch (h.$$typeof) {
                case fr:
                    e: {
                        for (var k = h.key, j = c; j !== null;) {
                            if (j.key === k) {
                                if (k = h.type, k === At) {
                                    if (j.tag === 7) {
                                        n(d, j.sibling), c = l(j, h.props.children), c.return = d, d = c;
                                        break e
                                    }
                                } else if (j.elementType === k || typeof k == "object" && k !== null && k.$$typeof === et && Uu(k) === j.type) {
                                    n(d, j.sibling), c = l(j, h.props), c.ref = kn(d, j, h), c.return = d, d = c;
                                    break e
                                }
                                n(d, j);
                                break
                            } else t(d, j);
                            j = j.sibling
                        }
                        h.type === At ? (c = Pt(h.props.children, d.mode, x, h.key), c.return = d, d = c) : (x = Ar(h.type, h.key, h.props, null, d.mode, x), x.ref = kn(d, c, h), x.return = d, d = x)
                    }
                    return i(d);
                case Ut:
                    e: {
                        for (j = h.key; c !== null;) {
                            if (c.key === j)
                                if (c.tag === 4 && c.stateNode.containerInfo === h.containerInfo && c.stateNode.implementation === h.implementation) {
                                    n(d, c.sibling), c = l(c, h.children || []), c.return = d, d = c;
                                    break e
                                } else {
                                    n(d, c);
                                    break
                                }
                            else t(d, c);
                            c = c.sibling
                        }
                        c = io(h, d.mode, x),
                        c.return = d,
                        d = c
                    }
                    return i(d);
                case et:
                    return j = h._init, P(d, c, j(h._payload), x)
            }
            if (jn(h)) return g(d, c, h, x);
            if (gn(h)) return w(d, c, h, x);
            Er(d, h)
        }
        return typeof h == "string" && h !== "" || typeof h == "number" ? (h = "" + h, c !== null && c.tag === 6 ? (n(d, c.sibling), c = l(c, h), c.return = d, d = c) : (n(d, c), c = oo(h, d.mode, x), c.return = d, d = c), i(d)) : n(d, c)
    }
    return P
}
var on = La(!0),
    Oa = La(!1),
    el = yt(null),
    tl = null,
    Yt = null,
    ji = null;

function _i() {
    ji = Yt = tl = null
}

function Pi(e) {
    var t = el.current;
    U(el), e._currentValue = t
}

function Uo(e, t, n) {
    for (; e !== null;) {
        var r = e.alternate;
        if ((e.childLanes & t) !== t ? (e.childLanes |= t, r !== null && (r.childLanes |= t)) : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t), e === n) break;
        e = e.return
    }
}

function en(e, t) {
    tl = e, ji = Yt = null, e = e.dependencies, e !== null && e.firstContext !== null && (e.lanes & t && (pe = !0), e.firstContext = null)
}

function _e(e) {
    var t = e._currentValue;
    if (ji !== e)
        if (e = {
                context: e,
                memoizedValue: t,
                next: null
            }, Yt === null) {
            if (tl === null) throw Error(S(308));
            Yt = e, tl.dependencies = {
                lanes: 0,
                firstContext: e
            }
        } else Yt = Yt.next = e;
    return t
}
var Ct = null;

function Ti(e) {
    Ct === null ? Ct = [e] : Ct.push(e)
}

function za(e, t, n, r) {
    var l = t.interleaved;
    return l === null ? (n.next = n, Ti(t)) : (n.next = l.next, l.next = n), t.interleaved = n, Xe(e, r)
}

function Xe(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;) e.childLanes |= t, n = e.alternate, n !== null && (n.childLanes |= t), n = e, e = e.return;
    return n.tag === 3 ? n.stateNode : null
}
var tt = !1;

function Ri(e) {
    e.updateQueue = {
        baseState: e.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: {
            pending: null,
            interleaved: null,
            lanes: 0
        },
        effects: null
    }
}

function Ma(e, t) {
    e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
        baseState: e.baseState,
        firstBaseUpdate: e.firstBaseUpdate,
        lastBaseUpdate: e.lastBaseUpdate,
        shared: e.shared,
        effects: e.effects
    })
}

function Ke(e, t) {
    return {
        eventTime: e,
        lane: t,
        tag: 0,
        payload: null,
        callback: null,
        next: null
    }
}

function dt(e, t, n) {
    var r = e.updateQueue;
    if (r === null) return null;
    if (r = r.shared, M & 2) {
        var l = r.pending;
        return l === null ? t.next = t : (t.next = l.next, l.next = t), r.pending = t, Xe(e, n)
    }
    return l = r.interleaved, l === null ? (t.next = t, Ti(r)) : (t.next = l.next, l.next = t), r.interleaved = t, Xe(e, n)
}

function zr(e, t, n) {
    if (t = t.updateQueue, t !== null && (t = t.shared, (n & 4194240) !== 0)) {
        var r = t.lanes;
        r &= e.pendingLanes, n |= r, t.lanes = n, mi(e, n)
    }
}

function Au(e, t) {
    var n = e.updateQueue,
        r = e.alternate;
    if (r !== null && (r = r.updateQueue, n === r)) {
        var l = null,
            o = null;
        if (n = n.firstBaseUpdate, n !== null) {
            do {
                var i = {
                    eventTime: n.eventTime,
                    lane: n.lane,
                    tag: n.tag,
                    payload: n.payload,
                    callback: n.callback,
                    next: null
                };
                o === null ? l = o = i : o = o.next = i, n = n.next
            } while (n !== null);
            o === null ? l = o = t : o = o.next = t
        } else l = o = t;
        n = {
            baseState: r.baseState,
            firstBaseUpdate: l,
            lastBaseUpdate: o,
            shared: r.shared,
            effects: r.effects
        }, e.updateQueue = n;
        return
    }
    e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
}

function nl(e, t, n, r) {
    var l = e.updateQueue;
    tt = !1;
    var o = l.firstBaseUpdate,
        i = l.lastBaseUpdate,
        u = l.shared.pending;
    if (u !== null) {
        l.shared.pending = null;
        var s = u,
            a = s.next;
        s.next = null, i === null ? o = a : i.next = a, i = s;
        var v = e.alternate;
        v !== null && (v = v.updateQueue, u = v.lastBaseUpdate, u !== i && (u === null ? v.firstBaseUpdate = a : u.next = a, v.lastBaseUpdate = s))
    }
    if (o !== null) {
        var p = l.baseState;
        i = 0, v = a = s = null, u = o;
        do {
            var m = u.lane,
                y = u.eventTime;
            if ((r & m) === m) {
                v !== null && (v = v.next = {
                    eventTime: y,
                    lane: 0,
                    tag: u.tag,
                    payload: u.payload,
                    callback: u.callback,
                    next: null
                });
                e: {
                    var g = e,
                        w = u;
                    switch (m = t, y = n, w.tag) {
                        case 1:
                            if (g = w.payload, typeof g == "function") {
                                p = g.call(y, p, m);
                                break e
                            }
                            p = g;
                            break e;
                        case 3:
                            g.flags = g.flags & -65537 | 128;
                        case 0:
                            if (g = w.payload, m = typeof g == "function" ? g.call(y, p, m) : g, m == null) break e;
                            p = V({}, p, m);
                            break e;
                        case 2:
                            tt = !0
                    }
                }
                u.callback !== null && u.lane !== 0 && (e.flags |= 64, m = l.effects, m === null ? l.effects = [u] : m.push(u))
            } else y = {
                eventTime: y,
                lane: m,
                tag: u.tag,
                payload: u.payload,
                callback: u.callback,
                next: null
            }, v === null ? (a = v = y, s = p) : v = v.next = y, i |= m;
            if (u = u.next, u === null) {
                if (u = l.shared.pending, u === null) break;
                m = u, u = m.next, m.next = null, l.lastBaseUpdate = m, l.shared.pending = null
            }
        } while (!0);
        if (v === null && (s = p), l.baseState = s, l.firstBaseUpdate = a, l.lastBaseUpdate = v, t = l.shared.interleaved, t !== null) {
            l = t;
            do i |= l.lane, l = l.next; while (l !== t)
        } else o === null && (l.shared.lanes = 0);
        zt |= i, e.lanes = i, e.memoizedState = p
    }
}

function $u(e, t, n) {
    if (e = t.effects, t.effects = null, e !== null)
        for (t = 0; t < e.length; t++) {
            var r = e[t],
                l = r.callback;
            if (l !== null) {
                if (r.callback = null, r = n, typeof l != "function") throw Error(S(191, l));
                l.call(r)
            }
        }
}
var ur = {},
    Be = yt(ur),
    Xn = yt(ur),
    Zn = yt(ur);

function jt(e) {
    if (e === ur) throw Error(S(174));
    return e
}

function Li(e, t) {
    switch (F(Zn, t), F(Xn, e), F(Be, ur), e = t.nodeType, e) {
        case 9:
        case 11:
            t = (t = t.documentElement) ? t.namespaceURI : yo(null, "");
            break;
        default:
            e = e === 8 ? t.parentNode : t, t = e.namespaceURI || null, e = e.tagName, t = yo(t, e)
    }
    U(Be), F(Be, t)
}

function un() {
    U(Be), U(Xn), U(Zn)
}

function Ia(e) {
    jt(Zn.current);
    var t = jt(Be.current),
        n = yo(t, e.type);
    t !== n && (F(Xn, e), F(Be, n))
}

function Oi(e) {
    Xn.current === e && (U(Be), U(Xn))
}
var $ = yt(0);

function rl(e) {
    for (var t = e; t !== null;) {
        if (t.tag === 13) {
            var n = t.memoizedState;
            if (n !== null && (n = n.dehydrated, n === null || n.data === "$?" || n.data === "$!")) return t
        } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
            if (t.flags & 128) return t
        } else if (t.child !== null) {
            t.child.return = t, t = t.child;
            continue
        }
        if (t === e) break;
        for (; t.sibling === null;) {
            if (t.return === null || t.return === e) return null;
            t = t.return
        }
        t.sibling.return = t.return, t = t.sibling
    }
    return null
}
var bl = [];

function zi() {
    for (var e = 0; e < bl.length; e++) bl[e]._workInProgressVersionPrimary = null;
    bl.length = 0
}
var Mr = qe.ReactCurrentDispatcher,
    eo = qe.ReactCurrentBatchConfig,
    Ot = 0,
    B = null,
    G = null,
    J = null,
    ll = !1,
    Mn = !1,
    qn = 0,
    qf = 0;

function le() {
    throw Error(S(321))
}

function Mi(e, t) {
    if (t === null) return !1;
    for (var n = 0; n < t.length && n < e.length; n++)
        if (!Fe(e[n], t[n])) return !1;
    return !0
}

function Ii(e, t, n, r, l, o) {
    if (Ot = o, B = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, Mr.current = e === null || e.memoizedState === null ? tp : np, e = n(r, l), Mn) {
        o = 0;
        do {
            if (Mn = !1, qn = 0, 25 <= o) throw Error(S(301));
            o += 1, J = G = null, t.updateQueue = null, Mr.current = rp, e = n(r, l)
        } while (Mn)
    }
    if (Mr.current = ol, t = G !== null && G.next !== null, Ot = 0, J = G = B = null, ll = !1, t) throw Error(S(300));
    return e
}

function Fi() {
    var e = qn !== 0;
    return qn = 0, e
}

function Ue() {
    var e = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null
    };
    return J === null ? B.memoizedState = J = e : J = J.next = e, J
}

function Pe() {
    if (G === null) {
        var e = B.alternate;
        e = e !== null ? e.memoizedState : null
    } else e = G.next;
    var t = J === null ? B.memoizedState : J.next;
    if (t !== null) J = t, G = e;
    else {
        if (e === null) throw Error(S(310));
        G = e, e = {
            memoizedState: G.memoizedState,
            baseState: G.baseState,
            baseQueue: G.baseQueue,
            queue: G.queue,
            next: null
        }, J === null ? B.memoizedState = J = e : J = J.next = e
    }
    return J
}

function Jn(e, t) {
    return typeof t == "function" ? t(e) : t
}

function to(e) {
    var t = Pe(),
        n = t.queue;
    if (n === null) throw Error(S(311));
    n.lastRenderedReducer = e;
    var r = G,
        l = r.baseQueue,
        o = n.pending;
    if (o !== null) {
        if (l !== null) {
            var i = l.next;
            l.next = o.next, o.next = i
        }
        r.baseQueue = l = o, n.pending = null
    }
    if (l !== null) {
        o = l.next, r = r.baseState;
        var u = i = null,
            s = null,
            a = o;
        do {
            var v = a.lane;
            if ((Ot & v) === v) s !== null && (s = s.next = {
                lane: 0,
                action: a.action,
                hasEagerState: a.hasEagerState,
                eagerState: a.eagerState,
                next: null
            }), r = a.hasEagerState ? a.eagerState : e(r, a.action);
            else {
                var p = {
                    lane: v,
                    action: a.action,
                    hasEagerState: a.hasEagerState,
                    eagerState: a.eagerState,
                    next: null
                };
                s === null ? (u = s = p, i = r) : s = s.next = p, B.lanes |= v, zt |= v
            }
            a = a.next
        } while (a !== null && a !== o);
        s === null ? i = r : s.next = u, Fe(r, t.memoizedState) || (pe = !0), t.memoizedState = r, t.baseState = i, t.baseQueue = s, n.lastRenderedState = r
    }
    if (e = n.interleaved, e !== null) {
        l = e;
        do o = l.lane, B.lanes |= o, zt |= o, l = l.next; while (l !== e)
    } else l === null && (n.lanes = 0);
    return [t.memoizedState, n.dispatch]
}

function no(e) {
    var t = Pe(),
        n = t.queue;
    if (n === null) throw Error(S(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch,
        l = n.pending,
        o = t.memoizedState;
    if (l !== null) {
        n.pending = null;
        var i = l = l.next;
        do o = e(o, i.action), i = i.next; while (i !== l);
        Fe(o, t.memoizedState) || (pe = !0), t.memoizedState = o, t.baseQueue === null && (t.baseState = o), n.lastRenderedState = o
    }
    return [o, r]
}

function Fa() {}

function Da(e, t) {
    var n = B,
        r = Pe(),
        l = t(),
        o = !Fe(r.memoizedState, l);
    if (o && (r.memoizedState = l, pe = !0), r = r.queue, Di($a.bind(null, n, r, e), [e]), r.getSnapshot !== t || o || J !== null && J.memoizedState.tag & 1) {
        if (n.flags |= 2048, bn(9, Aa.bind(null, n, r, l, t), void 0, null), b === null) throw Error(S(349));
        Ot & 30 || Ua(n, t, l)
    }
    return l
}

function Ua(e, t, n) {
    e.flags |= 16384, e = {
        getSnapshot: t,
        value: n
    }, t = B.updateQueue, t === null ? (t = {
        lastEffect: null,
        stores: null
    }, B.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e))
}

function Aa(e, t, n, r) {
    t.value = n, t.getSnapshot = r, Ba(t) && Va(e)
}

function $a(e, t, n) {
    return n(function() {
        Ba(t) && Va(e)
    })
}

function Ba(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
        var n = t();
        return !Fe(e, n)
    } catch {
        return !0
    }
}

function Va(e) {
    var t = Xe(e, 1);
    t !== null && Ie(t, e, 1, -1)
}

function Bu(e) {
    var t = Ue();
    return typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e, e = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Jn,
        lastRenderedState: e
    }, t.queue = e, e = e.dispatch = ep.bind(null, B, e), [t.memoizedState, e]
}

function bn(e, t, n, r) {
    return e = {
        tag: e,
        create: t,
        destroy: n,
        deps: r,
        next: null
    }, t = B.updateQueue, t === null ? (t = {
        lastEffect: null,
        stores: null
    }, B.updateQueue = t, t.lastEffect = e.next = e) : (n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e)), e
}

function Ha() {
    return Pe().memoizedState
}

function Ir(e, t, n, r) {
    var l = Ue();
    B.flags |= e, l.memoizedState = bn(1 | t, n, void 0, r === void 0 ? null : r)
}

function xl(e, t, n, r) {
    var l = Pe();
    r = r === void 0 ? null : r;
    var o = void 0;
    if (G !== null) {
        var i = G.memoizedState;
        if (o = i.destroy, r !== null && Mi(r, i.deps)) {
            l.memoizedState = bn(t, n, o, r);
            return
        }
    }
    B.flags |= e, l.memoizedState = bn(1 | t, n, o, r)
}

function Vu(e, t) {
    return Ir(8390656, 8, e, t)
}

function Di(e, t) {
    return xl(2048, 8, e, t)
}

function Wa(e, t) {
    return xl(4, 2, e, t)
}

function Qa(e, t) {
    return xl(4, 4, e, t)
}

function Ka(e, t) {
    if (typeof t == "function") return e = e(), t(e),
        function() {
            t(null)
        };
    if (t != null) return e = e(), t.current = e,
        function() {
            t.current = null
        }
}

function Ya(e, t, n) {
    return n = n != null ? n.concat([e]) : null, xl(4, 4, Ka.bind(null, t, e), n)
}

function Ui() {}

function Ga(e, t) {
    var n = Pe();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && Mi(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e)
}

function Xa(e, t) {
    var n = Pe();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && Mi(t, r[1]) ? r[0] : (e = e(), n.memoizedState = [e, t], e)
}

function Za(e, t, n) {
    return Ot & 21 ? (Fe(n, t) || (n = ta(), B.lanes |= n, zt |= n, e.baseState = !0), t) : (e.baseState && (e.baseState = !1, pe = !0), e.memoizedState = n)
}

function Jf(e, t) {
    var n = I;
    I = n !== 0 && 4 > n ? n : 4, e(!0);
    var r = eo.transition;
    eo.transition = {};
    try {
        e(!1), t()
    } finally {
        I = n, eo.transition = r
    }
}

function qa() {
    return Pe().memoizedState
}

function bf(e, t, n) {
    var r = pt(e);
    if (n = {
            lane: r,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        }, Ja(e)) ba(t, n);
    else if (n = za(e, t, n, r), n !== null) {
        var l = ae();
        Ie(n, e, r, l), ec(n, t, r)
    }
}

function ep(e, t, n) {
    var r = pt(e),
        l = {
            lane: r,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        };
    if (Ja(e)) ba(t, l);
    else {
        var o = e.alternate;
        if (e.lanes === 0 && (o === null || o.lanes === 0) && (o = t.lastRenderedReducer, o !== null)) try {
            var i = t.lastRenderedState,
                u = o(i, n);
            if (l.hasEagerState = !0, l.eagerState = u, Fe(u, i)) {
                var s = t.interleaved;
                s === null ? (l.next = l, Ti(t)) : (l.next = s.next, s.next = l), t.interleaved = l;
                return
            }
        } catch {} finally {}
        n = za(e, t, l, r), n !== null && (l = ae(), Ie(n, e, r, l), ec(n, t, r))
    }
}

function Ja(e) {
    var t = e.alternate;
    return e === B || t !== null && t === B
}

function ba(e, t) {
    Mn = ll = !0;
    var n = e.pending;
    n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
}

function ec(e, t, n) {
    if (n & 4194240) {
        var r = t.lanes;
        r &= e.pendingLanes, n |= r, t.lanes = n, mi(e, n)
    }
}
var ol = {
        readContext: _e,
        useCallback: le,
        useContext: le,
        useEffect: le,
        useImperativeHandle: le,
        useInsertionEffect: le,
        useLayoutEffect: le,
        useMemo: le,
        useReducer: le,
        useRef: le,
        useState: le,
        useDebugValue: le,
        useDeferredValue: le,
        useTransition: le,
        useMutableSource: le,
        useSyncExternalStore: le,
        useId: le,
        unstable_isNewReconciler: !1
    },
    tp = {
        readContext: _e,
        useCallback: function(e, t) {
            return Ue().memoizedState = [e, t === void 0 ? null : t], e
        },
        useContext: _e,
        useEffect: Vu,
        useImperativeHandle: function(e, t, n) {
            return n = n != null ? n.concat([e]) : null, Ir(4194308, 4, Ka.bind(null, t, e), n)
        },
        useLayoutEffect: function(e, t) {
            return Ir(4194308, 4, e, t)
        },
        useInsertionEffect: function(e, t) {
            return Ir(4, 2, e, t)
        },
        useMemo: function(e, t) {
            var n = Ue();
            return t = t === void 0 ? null : t, e = e(), n.memoizedState = [e, t], e
        },
        useReducer: function(e, t, n) {
            var r = Ue();
            return t = n !== void 0 ? n(t) : t, r.memoizedState = r.baseState = t, e = {
                pending: null,
                interleaved: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: e,
                lastRenderedState: t
            }, r.queue = e, e = e.dispatch = bf.bind(null, B, e), [r.memoizedState, e]
        },
        useRef: function(e) {
            var t = Ue();
            return e = {
                current: e
            }, t.memoizedState = e
        },
        useState: Bu,
        useDebugValue: Ui,
        useDeferredValue: function(e) {
            return Ue().memoizedState = e
        },
        useTransition: function() {
            var e = Bu(!1),
                t = e[0];
            return e = Jf.bind(null, e[1]), Ue().memoizedState = e, [t, e]
        },
        useMutableSource: function() {},
        useSyncExternalStore: function(e, t, n) {
            var r = B,
                l = Ue();
            if (A) {
                if (n === void 0) throw Error(S(407));
                n = n()
            } else {
                if (n = t(), b === null) throw Error(S(349));
                Ot & 30 || Ua(r, t, n)
            }
            l.memoizedState = n;
            var o = {
                value: n,
                getSnapshot: t
            };
            return l.queue = o, Vu($a.bind(null, r, o, e), [e]), r.flags |= 2048, bn(9, Aa.bind(null, r, o, n, t), void 0, null), n
        },
        useId: function() {
            var e = Ue(),
                t = b.identifierPrefix;
            if (A) {
                var n = Qe,
                    r = We;
                n = (r & ~(1 << 32 - Me(r) - 1)).toString(32) + n, t = ":" + t + "R" + n, n = qn++, 0 < n && (t += "H" + n.toString(32)), t += ":"
            } else n = qf++, t = ":" + t + "r" + n.toString(32) + ":";
            return e.memoizedState = t
        },
        unstable_isNewReconciler: !1
    },
    np = {
        readContext: _e,
        useCallback: Ga,
        useContext: _e,
        useEffect: Di,
        useImperativeHandle: Ya,
        useInsertionEffect: Wa,
        useLayoutEffect: Qa,
        useMemo: Xa,
        useReducer: to,
        useRef: Ha,
        useState: function() {
            return to(Jn)
        },
        useDebugValue: Ui,
        useDeferredValue: function(e) {
            var t = Pe();
            return Za(t, G.memoizedState, e)
        },
        useTransition: function() {
            var e = to(Jn)[0],
                t = Pe().memoizedState;
            return [e, t]
        },
        useMutableSource: Fa,
        useSyncExternalStore: Da,
        useId: qa,
        unstable_isNewReconciler: !1
    },
    rp = {
        readContext: _e,
        useCallback: Ga,
        useContext: _e,
        useEffect: Di,
        useImperativeHandle: Ya,
        useInsertionEffect: Wa,
        useLayoutEffect: Qa,
        useMemo: Xa,
        useReducer: no,
        useRef: Ha,
        useState: function() {
            return no(Jn)
        },
        useDebugValue: Ui,
        useDeferredValue: function(e) {
            var t = Pe();
            return G === null ? t.memoizedState = e : Za(t, G.memoizedState, e)
        },
        useTransition: function() {
            var e = no(Jn)[0],
                t = Pe().memoizedState;
            return [e, t]
        },
        useMutableSource: Fa,
        useSyncExternalStore: Da,
        useId: qa,
        unstable_isNewReconciler: !1
    };

function Le(e, t) {
    if (e && e.defaultProps) {
        t = V({}, t), e = e.defaultProps;
        for (var n in e) t[n] === void 0 && (t[n] = e[n]);
        return t
    }
    return t
}

function Ao(e, t, n, r) {
    t = e.memoizedState, n = n(r, t), n = n == null ? t : V({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n)
}
var wl = {
    isMounted: function(e) {
        return (e = e._reactInternals) ? Ft(e) === e : !1
    },
    enqueueSetState: function(e, t, n) {
        e = e._reactInternals;
        var r = ae(),
            l = pt(e),
            o = Ke(r, l);
        o.payload = t, n != null && (o.callback = n), t = dt(e, o, l), t !== null && (Ie(t, e, l, r), zr(t, e, l))
    },
    enqueueReplaceState: function(e, t, n) {
        e = e._reactInternals;
        var r = ae(),
            l = pt(e),
            o = Ke(r, l);
        o.tag = 1, o.payload = t, n != null && (o.callback = n), t = dt(e, o, l), t !== null && (Ie(t, e, l, r), zr(t, e, l))
    },
    enqueueForceUpdate: function(e, t) {
        e = e._reactInternals;
        var n = ae(),
            r = pt(e),
            l = Ke(n, r);
        l.tag = 2, t != null && (l.callback = t), t = dt(e, l, r), t !== null && (Ie(t, e, r, n), zr(t, e, r))
    }
};

function Hu(e, t, n, r, l, o, i) {
    return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(r, o, i) : t.prototype && t.prototype.isPureReactComponent ? !Qn(n, r) || !Qn(l, o) : !0
}

function tc(e, t, n) {
    var r = !1,
        l = vt,
        o = t.contextType;
    return typeof o == "object" && o !== null ? o = _e(o) : (l = me(t) ? Rt : ue.current, r = t.contextTypes, o = (r = r != null) ? rn(e, l) : vt), t = new t(n, o), e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null, t.updater = wl, e.stateNode = t, t._reactInternals = e, r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = l, e.__reactInternalMemoizedMaskedChildContext = o), t
}

function Wu(e, t, n, r) {
    e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && wl.enqueueReplaceState(t, t.state, null)
}

function $o(e, t, n, r) {
    var l = e.stateNode;
    l.props = n, l.state = e.memoizedState, l.refs = {}, Ri(e);
    var o = t.contextType;
    typeof o == "object" && o !== null ? l.context = _e(o) : (o = me(t) ? Rt : ue.current, l.context = rn(e, o)), l.state = e.memoizedState, o = t.getDerivedStateFromProps, typeof o == "function" && (Ao(e, t, o, n), l.state = e.memoizedState), typeof t.getDerivedStateFromProps == "function" || typeof l.getSnapshotBeforeUpdate == "function" || typeof l.UNSAFE_componentWillMount != "function" && typeof l.componentWillMount != "function" || (t = l.state, typeof l.componentWillMount == "function" && l.componentWillMount(), typeof l.UNSAFE_componentWillMount == "function" && l.UNSAFE_componentWillMount(), t !== l.state && wl.enqueueReplaceState(l, l.state, null), nl(e, n, l, r), l.state = e.memoizedState), typeof l.componentDidMount == "function" && (e.flags |= 4194308)
}

function sn(e, t) {
    try {
        var n = "",
            r = t;
        do n += Rd(r), r = r.return; while (r);
        var l = n
    } catch (o) {
        l = `
Error generating stack: ` + o.message + `
` + o.stack
    }
    return {
        value: e,
        source: t,
        stack: l,
        digest: null
    }
}

function ro(e, t, n) {
    return {
        value: e,
        source: null,
        stack: n ? ? null,
        digest: t ? ? null
    }
}

function Bo(e, t) {
    try {
        console.error(t.value)
    } catch (n) {
        setTimeout(function() {
            throw n
        })
    }
}
var lp = typeof WeakMap == "function" ? WeakMap : Map;

function nc(e, t, n) {
    n = Ke(-1, n), n.tag = 3, n.payload = {
        element: null
    };
    var r = t.value;
    return n.callback = function() {
        ul || (ul = !0, qo = r), Bo(e, t)
    }, n
}

function rc(e, t, n) {
    n = Ke(-1, n), n.tag = 3;
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
        var l = t.value;
        n.payload = function() {
            return r(l)
        }, n.callback = function() {
            Bo(e, t)
        }
    }
    var o = e.stateNode;
    return o !== null && typeof o.componentDidCatch == "function" && (n.callback = function() {
        Bo(e, t), typeof r != "function" && (ft === null ? ft = new Set([this]) : ft.add(this));
        var i = t.stack;
        this.componentDidCatch(t.value, {
            componentStack: i !== null ? i : ""
        })
    }), n
}

function Qu(e, t, n) {
    var r = e.pingCache;
    if (r === null) {
        r = e.pingCache = new lp;
        var l = new Set;
        r.set(t, l)
    } else l = r.get(t), l === void 0 && (l = new Set, r.set(t, l));
    l.has(n) || (l.add(n), e = yp.bind(null, e, t, n), t.then(e, e))
}

function Ku(e) {
    do {
        var t;
        if ((t = e.tag === 13) && (t = e.memoizedState, t = t !== null ? t.dehydrated !== null : !0), t) return e;
        e = e.return
    } while (e !== null);
    return null
}

function Yu(e, t, n, r, l) {
    return e.mode & 1 ? (e.flags |= 65536, e.lanes = l, e) : (e === t ? e.flags |= 65536 : (e.flags |= 128, n.flags |= 131072, n.flags &= -52805, n.tag === 1 && (n.alternate === null ? n.tag = 17 : (t = Ke(-1, 1), t.tag = 2, dt(n, t, 1))), n.lanes |= 1), e)
}
var op = qe.ReactCurrentOwner,
    pe = !1;

function se(e, t, n, r) {
    t.child = e === null ? Oa(t, null, n, r) : on(t, e.child, n, r)
}

function Gu(e, t, n, r, l) {
    n = n.render;
    var o = t.ref;
    return en(t, l), r = Ii(e, t, n, r, o, l), n = Fi(), e !== null && !pe ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~l, Ze(e, t, l)) : (A && n && Ei(t), t.flags |= 1, se(e, t, r, l), t.child)
}

function Xu(e, t, n, r, l) {
    if (e === null) {
        var o = n.type;
        return typeof o == "function" && !Ki(o) && o.defaultProps === void 0 && n.compare === null && n.defaultProps === void 0 ? (t.tag = 15, t.type = o, lc(e, t, o, r, l)) : (e = Ar(n.type, null, r, t, t.mode, l), e.ref = t.ref, e.return = t, t.child = e)
    }
    if (o = e.child, !(e.lanes & l)) {
        var i = o.memoizedProps;
        if (n = n.compare, n = n !== null ? n : Qn, n(i, r) && e.ref === t.ref) return Ze(e, t, l)
    }
    return t.flags |= 1, e = ht(o, r), e.ref = t.ref, e.return = t, t.child = e
}

function lc(e, t, n, r, l) {
    if (e !== null) {
        var o = e.memoizedProps;
        if (Qn(o, r) && e.ref === t.ref)
            if (pe = !1, t.pendingProps = r = o, (e.lanes & l) !== 0) e.flags & 131072 && (pe = !0);
            else return t.lanes = e.lanes, Ze(e, t, l)
    }
    return Vo(e, t, n, r, l)
}

function oc(e, t, n) {
    var r = t.pendingProps,
        l = r.children,
        o = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden")
        if (!(t.mode & 1)) t.memoizedState = {
            baseLanes: 0,
            cachePool: null,
            transitions: null
        }, F(Xt, ge), ge |= n;
        else {
            if (!(n & 1073741824)) return e = o !== null ? o.baseLanes | n : n, t.lanes = t.childLanes = 1073741824, t.memoizedState = {
                baseLanes: e,
                cachePool: null,
                transitions: null
            }, t.updateQueue = null, F(Xt, ge), ge |= e, null;
            t.memoizedState = {
                baseLanes: 0,
                cachePool: null,
                transitions: null
            }, r = o !== null ? o.baseLanes : n, F(Xt, ge), ge |= r
        }
    else o !== null ? (r = o.baseLanes | n, t.memoizedState = null) : r = n, F(Xt, ge), ge |= r;
    return se(e, t, l, n), t.child
}

function ic(e, t) {
    var n = t.ref;
    (e === null && n !== null || e !== null && e.ref !== n) && (t.flags |= 512, t.flags |= 2097152)
}

function Vo(e, t, n, r, l) {
    var o = me(n) ? Rt : ue.current;
    return o = rn(t, o), en(t, l), n = Ii(e, t, n, r, o, l), r = Fi(), e !== null && !pe ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~l, Ze(e, t, l)) : (A && r && Ei(t), t.flags |= 1, se(e, t, n, l), t.child)
}

function Zu(e, t, n, r, l) {
    if (me(n)) {
        var o = !0;
        qr(t)
    } else o = !1;
    if (en(t, l), t.stateNode === null) Fr(e, t), tc(t, n, r), $o(t, n, r, l), r = !0;
    else if (e === null) {
        var i = t.stateNode,
            u = t.memoizedProps;
        i.props = u;
        var s = i.context,
            a = n.contextType;
        typeof a == "object" && a !== null ? a = _e(a) : (a = me(n) ? Rt : ue.current, a = rn(t, a));
        var v = n.getDerivedStateFromProps,
            p = typeof v == "function" || typeof i.getSnapshotBeforeUpdate == "function";
        p || typeof i.UNSAFE_componentWillReceiveProps != "function" && typeof i.componentWillReceiveProps != "function" || (u !== r || s !== a) && Wu(t, i, r, a), tt = !1;
        var m = t.memoizedState;
        i.state = m, nl(t, r, i, l), s = t.memoizedState, u !== r || m !== s || he.current || tt ? (typeof v == "function" && (Ao(t, n, v, r), s = t.memoizedState), (u = tt || Hu(t, n, u, r, m, s, a)) ? (p || typeof i.UNSAFE_componentWillMount != "function" && typeof i.componentWillMount != "function" || (typeof i.componentWillMount == "function" && i.componentWillMount(), typeof i.UNSAFE_componentWillMount == "function" && i.UNSAFE_componentWillMount()), typeof i.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof i.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = s), i.props = r, i.state = s, i.context = a, r = u) : (typeof i.componentDidMount == "function" && (t.flags |= 4194308), r = !1)
    } else {
        i = t.stateNode, Ma(e, t), u = t.memoizedProps, a = t.type === t.elementType ? u : Le(t.type, u), i.props = a, p = t.pendingProps, m = i.context, s = n.contextType, typeof s == "object" && s !== null ? s = _e(s) : (s = me(n) ? Rt : ue.current, s = rn(t, s));
        var y = n.getDerivedStateFromProps;
        (v = typeof y == "function" || typeof i.getSnapshotBeforeUpdate == "function") || typeof i.UNSAFE_componentWillReceiveProps != "function" && typeof i.componentWillReceiveProps != "function" || (u !== p || m !== s) && Wu(t, i, r, s), tt = !1, m = t.memoizedState, i.state = m, nl(t, r, i, l);
        var g = t.memoizedState;
        u !== p || m !== g || he.current || tt ? (typeof y == "function" && (Ao(t, n, y, r), g = t.memoizedState), (a = tt || Hu(t, n, a, r, m, g, s) || !1) ? (v || typeof i.UNSAFE_componentWillUpdate != "function" && typeof i.componentWillUpdate != "function" || (typeof i.componentWillUpdate == "function" && i.componentWillUpdate(r, g, s), typeof i.UNSAFE_componentWillUpdate == "function" && i.UNSAFE_componentWillUpdate(r, g, s)), typeof i.componentDidUpdate == "function" && (t.flags |= 4), typeof i.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof i.componentDidUpdate != "function" || u === e.memoizedProps && m === e.memoizedState || (t.flags |= 4), typeof i.getSnapshotBeforeUpdate != "function" || u === e.memoizedProps && m === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = g), i.props = r, i.state = g, i.context = s, r = a) : (typeof i.componentDidUpdate != "function" || u === e.memoizedProps && m === e.memoizedState || (t.flags |= 4), typeof i.getSnapshotBeforeUpdate != "function" || u === e.memoizedProps && m === e.memoizedState || (t.flags |= 1024), r = !1)
    }
    return Ho(e, t, n, r, o, l)
}

function Ho(e, t, n, r, l, o) {
    ic(e, t);
    var i = (t.flags & 128) !== 0;
    if (!r && !i) return l && Iu(t, n, !1), Ze(e, t, o);
    r = t.stateNode, op.current = t;
    var u = i && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return t.flags |= 1, e !== null && i ? (t.child = on(t, e.child, null, o), t.child = on(t, null, u, o)) : se(e, t, u, o), t.memoizedState = r.state, l && Iu(t, n, !0), t.child
}

function uc(e) {
    var t = e.stateNode;
    t.pendingContext ? Mu(e, t.pendingContext, t.pendingContext !== t.context) : t.context && Mu(e, t.context, !1), Li(e, t.containerInfo)
}

function qu(e, t, n, r, l) {
    return ln(), Ci(l), t.flags |= 256, se(e, t, n, r), t.child
}
var Wo = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0
};

function Qo(e) {
    return {
        baseLanes: e,
        cachePool: null,
        transitions: null
    }
}

function sc(e, t, n) {
    var r = t.pendingProps,
        l = $.current,
        o = !1,
        i = (t.flags & 128) !== 0,
        u;
    if ((u = i) || (u = e !== null && e.memoizedState === null ? !1 : (l & 2) !== 0), u ? (o = !0, t.flags &= -129) : (e === null || e.memoizedState !== null) && (l |= 1), F($, l & 1), e === null) return Do(t), e = t.memoizedState, e !== null && (e = e.dehydrated, e !== null) ? (t.mode & 1 ? e.data === "$!" ? t.lanes = 8 : t.lanes = 1073741824 : t.lanes = 1, null) : (i = r.children, e = r.fallback, o ? (r = t.mode, o = t.child, i = {
        mode: "hidden",
        children: i
    }, !(r & 1) && o !== null ? (o.childLanes = 0, o.pendingProps = i) : o = El(i, r, 0, null), e = Pt(e, r, n, null), o.return = t, e.return = t, o.sibling = e, t.child = o, t.child.memoizedState = Qo(n), t.memoizedState = Wo, e) : Ai(t, i));
    if (l = e.memoizedState, l !== null && (u = l.dehydrated, u !== null)) return ip(e, t, i, r, u, l, n);
    if (o) {
        o = r.fallback, i = t.mode, l = e.child, u = l.sibling;
        var s = {
            mode: "hidden",
            children: r.children
        };
        return !(i & 1) && t.child !== l ? (r = t.child, r.childLanes = 0, r.pendingProps = s, t.deletions = null) : (r = ht(l, s), r.subtreeFlags = l.subtreeFlags & 14680064), u !== null ? o = ht(u, o) : (o = Pt(o, i, n, null), o.flags |= 2), o.return = t, r.return = t, r.sibling = o, t.child = r, r = o, o = t.child, i = e.child.memoizedState, i = i === null ? Qo(n) : {
            baseLanes: i.baseLanes | n,
            cachePool: null,
            transitions: i.transitions
        }, o.memoizedState = i, o.childLanes = e.childLanes & ~n, t.memoizedState = Wo, r
    }
    return o = e.child, e = o.sibling, r = ht(o, {
        mode: "visible",
        children: r.children
    }), !(t.mode & 1) && (r.lanes = n), r.return = t, r.sibling = null, e !== null && (n = t.deletions, n === null ? (t.deletions = [e], t.flags |= 16) : n.push(e)), t.child = r, t.memoizedState = null, r
}

function Ai(e, t) {
    return t = El({
        mode: "visible",
        children: t
    }, e.mode, 0, null), t.return = e, e.child = t
}

function Nr(e, t, n, r) {
    return r !== null && Ci(r), on(t, e.child, null, n), e = Ai(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e
}

function ip(e, t, n, r, l, o, i) {
    if (n) return t.flags & 256 ? (t.flags &= -257, r = ro(Error(S(422))), Nr(e, t, i, r)) : t.memoizedState !== null ? (t.child = e.child, t.flags |= 128, null) : (o = r.fallback, l = t.mode, r = El({
        mode: "visible",
        children: r.children
    }, l, 0, null), o = Pt(o, l, i, null), o.flags |= 2, r.return = t, o.return = t, r.sibling = o, t.child = r, t.mode & 1 && on(t, e.child, null, i), t.child.memoizedState = Qo(i), t.memoizedState = Wo, o);
    if (!(t.mode & 1)) return Nr(e, t, i, null);
    if (l.data === "$!") {
        if (r = l.nextSibling && l.nextSibling.dataset, r) var u = r.dgst;
        return r = u, o = Error(S(419)), r = ro(o, r, void 0), Nr(e, t, i, r)
    }
    if (u = (i & e.childLanes) !== 0, pe || u) {
        if (r = b, r !== null) {
            switch (i & -i) {
                case 4:
                    l = 2;
                    break;
                case 16:
                    l = 8;
                    break;
                case 64:
                case 128:
                case 256:
                case 512:
                case 1024:
                case 2048:
                case 4096:
                case 8192:
                case 16384:
                case 32768:
                case 65536:
                case 131072:
                case 262144:
                case 524288:
                case 1048576:
                case 2097152:
                case 4194304:
                case 8388608:
                case 16777216:
                case 33554432:
                case 67108864:
                    l = 32;
                    break;
                case 536870912:
                    l = 268435456;
                    break;
                default:
                    l = 0
            }
            l = l & (r.suspendedLanes | i) ? 0 : l, l !== 0 && l !== o.retryLane && (o.retryLane = l, Xe(e, l), Ie(r, e, l, -1))
        }
        return Qi(), r = ro(Error(S(421))), Nr(e, t, i, r)
    }
    return l.data === "$?" ? (t.flags |= 128, t.child = e.child, t = xp.bind(null, e), l._reactRetry = t, null) : (e = o.treeContext, ye = ct(l.nextSibling), xe = t, A = !0, ze = null, e !== null && (Ee[Ne++] = We, Ee[Ne++] = Qe, Ee[Ne++] = Lt, We = e.id, Qe = e.overflow, Lt = t), t = Ai(t, r.children), t.flags |= 4096, t)
}

function Ju(e, t, n) {
    e.lanes |= t;
    var r = e.alternate;
    r !== null && (r.lanes |= t), Uo(e.return, t, n)
}

function lo(e, t, n, r, l) {
    var o = e.memoizedState;
    o === null ? e.memoizedState = {
        isBackwards: t,
        rendering: null,
        renderingStartTime: 0,
        last: r,
        tail: n,
        tailMode: l
    } : (o.isBackwards = t, o.rendering = null, o.renderingStartTime = 0, o.last = r, o.tail = n, o.tailMode = l)
}

function ac(e, t, n) {
    var r = t.pendingProps,
        l = r.revealOrder,
        o = r.tail;
    if (se(e, t, r.children, n), r = $.current, r & 2) r = r & 1 | 2, t.flags |= 128;
    else {
        if (e !== null && e.flags & 128) e: for (e = t.child; e !== null;) {
            if (e.tag === 13) e.memoizedState !== null && Ju(e, n, t);
            else if (e.tag === 19) Ju(e, n, t);
            else if (e.child !== null) {
                e.child.return = e, e = e.child;
                continue
            }
            if (e === t) break e;
            for (; e.sibling === null;) {
                if (e.return === null || e.return === t) break e;
                e = e.return
            }
            e.sibling.return = e.return, e = e.sibling
        }
        r &= 1
    }
    if (F($, r), !(t.mode & 1)) t.memoizedState = null;
    else switch (l) {
        case "forwards":
            for (n = t.child, l = null; n !== null;) e = n.alternate, e !== null && rl(e) === null && (l = n), n = n.sibling;
            n = l, n === null ? (l = t.child, t.child = null) : (l = n.sibling, n.sibling = null), lo(t, !1, l, n, o);
            break;
        case "backwards":
            for (n = null, l = t.child, t.child = null; l !== null;) {
                if (e = l.alternate, e !== null && rl(e) === null) {
                    t.child = l;
                    break
                }
                e = l.sibling, l.sibling = n, n = l, l = e
            }
            lo(t, !0, n, null, o);
            break;
        case "together":
            lo(t, !1, null, null, void 0);
            break;
        default:
            t.memoizedState = null
    }
    return t.child
}

function Fr(e, t) {
    !(t.mode & 1) && e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2)
}

function Ze(e, t, n) {
    if (e !== null && (t.dependencies = e.dependencies), zt |= t.lanes, !(n & t.childLanes)) return null;
    if (e !== null && t.child !== e.child) throw Error(S(153));
    if (t.child !== null) {
        for (e = t.child, n = ht(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null;) e = e.sibling, n = n.sibling = ht(e, e.pendingProps), n.return = t;
        n.sibling = null
    }
    return t.child
}

function up(e, t, n) {
    switch (t.tag) {
        case 3:
            uc(t), ln();
            break;
        case 5:
            Ia(t);
            break;
        case 1:
            me(t.type) && qr(t);
            break;
        case 4:
            Li(t, t.stateNode.containerInfo);
            break;
        case 10:
            var r = t.type._context,
                l = t.memoizedProps.value;
            F(el, r._currentValue), r._currentValue = l;
            break;
        case 13:
            if (r = t.memoizedState, r !== null) return r.dehydrated !== null ? (F($, $.current & 1), t.flags |= 128, null) : n & t.child.childLanes ? sc(e, t, n) : (F($, $.current & 1), e = Ze(e, t, n), e !== null ? e.sibling : null);
            F($, $.current & 1);
            break;
        case 19:
            if (r = (n & t.childLanes) !== 0, e.flags & 128) {
                if (r) return ac(e, t, n);
                t.flags |= 128
            }
            if (l = t.memoizedState, l !== null && (l.rendering = null, l.tail = null, l.lastEffect = null), F($, $.current), r) break;
            return null;
        case 22:
        case 23:
            return t.lanes = 0, oc(e, t, n)
    }
    return Ze(e, t, n)
}
var cc, Ko, dc, fc;
cc = function(e, t) {
    for (var n = t.child; n !== null;) {
        if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
        else if (n.tag !== 4 && n.child !== null) {
            n.child.return = n, n = n.child;
            continue
        }
        if (n === t) break;
        for (; n.sibling === null;) {
            if (n.return === null || n.return === t) return;
            n = n.return
        }
        n.sibling.return = n.return, n = n.sibling
    }
};
Ko = function() {};
dc = function(e, t, n, r) {
    var l = e.memoizedProps;
    if (l !== r) {
        e = t.stateNode, jt(Be.current);
        var o = null;
        switch (n) {
            case "input":
                l = ho(e, l), r = ho(e, r), o = [];
                break;
            case "select":
                l = V({}, l, {
                    value: void 0
                }), r = V({}, r, {
                    value: void 0
                }), o = [];
                break;
            case "textarea":
                l = go(e, l), r = go(e, r), o = [];
                break;
            default:
                typeof l.onClick != "function" && typeof r.onClick == "function" && (e.onclick = Xr)
        }
        xo(n, r);
        var i;
        n = null;
        for (a in l)
            if (!r.hasOwnProperty(a) && l.hasOwnProperty(a) && l[a] != null)
                if (a === "style") {
                    var u = l[a];
                    for (i in u) u.hasOwnProperty(i) && (n || (n = {}), n[i] = "")
                } else a !== "dangerouslySetInnerHTML" && a !== "children" && a !== "suppressContentEditableWarning" && a !== "suppressHydrationWarning" && a !== "autoFocus" && (Un.hasOwnProperty(a) ? o || (o = []) : (o = o || []).push(a, null));
        for (a in r) {
            var s = r[a];
            if (u = l != null ? l[a] : void 0, r.hasOwnProperty(a) && s !== u && (s != null || u != null))
                if (a === "style")
                    if (u) {
                        for (i in u) !u.hasOwnProperty(i) || s && s.hasOwnProperty(i) || (n || (n = {}), n[i] = "");
                        for (i in s) s.hasOwnProperty(i) && u[i] !== s[i] && (n || (n = {}), n[i] = s[i])
                    } else n || (o || (o = []), o.push(a, n)), n = s;
            else a === "dangerouslySetInnerHTML" ? (s = s ? s.__html : void 0, u = u ? u.__html : void 0, s != null && u !== s && (o = o || []).push(a, s)) : a === "children" ? typeof s != "string" && typeof s != "number" || (o = o || []).push(a, "" + s) : a !== "suppressContentEditableWarning" && a !== "suppressHydrationWarning" && (Un.hasOwnProperty(a) ? (s != null && a === "onScroll" && D("scroll", e), o || u === s || (o = [])) : (o = o || []).push(a, s))
        }
        n && (o = o || []).push("style", n);
        var a = o;
        (t.updateQueue = a) && (t.flags |= 4)
    }
};
fc = function(e, t, n, r) {
    n !== r && (t.flags |= 4)
};

function En(e, t) {
    if (!A) switch (e.tailMode) {
        case "hidden":
            t = e.tail;
            for (var n = null; t !== null;) t.alternate !== null && (n = t), t = t.sibling;
            n === null ? e.tail = null : n.sibling = null;
            break;
        case "collapsed":
            n = e.tail;
            for (var r = null; n !== null;) n.alternate !== null && (r = n), n = n.sibling;
            r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null
    }
}

function oe(e) {
    var t = e.alternate !== null && e.alternate.child === e.child,
        n = 0,
        r = 0;
    if (t)
        for (var l = e.child; l !== null;) n |= l.lanes | l.childLanes, r |= l.subtreeFlags & 14680064, r |= l.flags & 14680064, l.return = e, l = l.sibling;
    else
        for (l = e.child; l !== null;) n |= l.lanes | l.childLanes, r |= l.subtreeFlags, r |= l.flags, l.return = e, l = l.sibling;
    return e.subtreeFlags |= r, e.childLanes = n, t
}

function sp(e, t, n) {
    var r = t.pendingProps;
    switch (Ni(t), t.tag) {
        case 2:
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
            return oe(t), null;
        case 1:
            return me(t.type) && Zr(), oe(t), null;
        case 3:
            return r = t.stateNode, un(), U(he), U(ue), zi(), r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), (e === null || e.child === null) && (kr(t) ? t.flags |= 4 : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, ze !== null && (ei(ze), ze = null))), Ko(e, t), oe(t), null;
        case 5:
            Oi(t);
            var l = jt(Zn.current);
            if (n = t.type, e !== null && t.stateNode != null) dc(e, t, n, r, l), e.ref !== t.ref && (t.flags |= 512, t.flags |= 2097152);
            else {
                if (!r) {
                    if (t.stateNode === null) throw Error(S(166));
                    return oe(t), null
                }
                if (e = jt(Be.current), kr(t)) {
                    r = t.stateNode, n = t.type;
                    var o = t.memoizedProps;
                    switch (r[Ae] = t, r[Gn] = o, e = (t.mode & 1) !== 0, n) {
                        case "dialog":
                            D("cancel", r), D("close", r);
                            break;
                        case "iframe":
                        case "object":
                        case "embed":
                            D("load", r);
                            break;
                        case "video":
                        case "audio":
                            for (l = 0; l < Pn.length; l++) D(Pn[l], r);
                            break;
                        case "source":
                            D("error", r);
                            break;
                        case "img":
                        case "image":
                        case "link":
                            D("error", r), D("load", r);
                            break;
                        case "details":
                            D("toggle", r);
                            break;
                        case "input":
                            uu(r, o), D("invalid", r);
                            break;
                        case "select":
                            r._wrapperState = {
                                wasMultiple: !!o.multiple
                            }, D("invalid", r);
                            break;
                        case "textarea":
                            au(r, o), D("invalid", r)
                    }
                    xo(n, o), l = null;
                    for (var i in o)
                        if (o.hasOwnProperty(i)) {
                            var u = o[i];
                            i === "children" ? typeof u == "string" ? r.textContent !== u && (o.suppressHydrationWarning !== !0 && Sr(r.textContent, u, e), l = ["children", u]) : typeof u == "number" && r.textContent !== "" + u && (o.suppressHydrationWarning !== !0 && Sr(r.textContent, u, e), l = ["children", "" + u]) : Un.hasOwnProperty(i) && u != null && i === "onScroll" && D("scroll", r)
                        }
                    switch (n) {
                        case "input":
                            pr(r), su(r, o, !0);
                            break;
                        case "textarea":
                            pr(r), cu(r);
                            break;
                        case "select":
                        case "option":
                            break;
                        default:
                            typeof o.onClick == "function" && (r.onclick = Xr)
                    }
                    r = l, t.updateQueue = r, r !== null && (t.flags |= 4)
                } else {
                    i = l.nodeType === 9 ? l : l.ownerDocument, e === "http://www.w3.org/1999/xhtml" && (e = $s(n)), e === "http://www.w3.org/1999/xhtml" ? n === "script" ? (e = i.createElement("div"), e.innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild)) : typeof r.is == "string" ? e = i.createElement(n, {
                        is: r.is
                    }) : (e = i.createElement(n), n === "select" && (i = e, r.multiple ? i.multiple = !0 : r.size && (i.size = r.size))) : e = i.createElementNS(e, n), e[Ae] = t, e[Gn] = r, cc(e, t, !1, !1), t.stateNode = e;
                    e: {
                        switch (i = wo(n, r), n) {
                            case "dialog":
                                D("cancel", e), D("close", e), l = r;
                                break;
                            case "iframe":
                            case "object":
                            case "embed":
                                D("load", e), l = r;
                                break;
                            case "video":
                            case "audio":
                                for (l = 0; l < Pn.length; l++) D(Pn[l], e);
                                l = r;
                                break;
                            case "source":
                                D("error", e), l = r;
                                break;
                            case "img":
                            case "image":
                            case "link":
                                D("error", e), D("load", e), l = r;
                                break;
                            case "details":
                                D("toggle", e), l = r;
                                break;
                            case "input":
                                uu(e, r), l = ho(e, r), D("invalid", e);
                                break;
                            case "option":
                                l = r;
                                break;
                            case "select":
                                e._wrapperState = {
                                    wasMultiple: !!r.multiple
                                }, l = V({}, r, {
                                    value: void 0
                                }), D("invalid", e);
                                break;
                            case "textarea":
                                au(e, r), l = go(e, r), D("invalid", e);
                                break;
                            default:
                                l = r
                        }
                        xo(n, l),
                        u = l;
                        for (o in u)
                            if (u.hasOwnProperty(o)) {
                                var s = u[o];
                                o === "style" ? Hs(e, s) : o === "dangerouslySetInnerHTML" ? (s = s ? s.__html : void 0, s != null && Bs(e, s)) : o === "children" ? typeof s == "string" ? (n !== "textarea" || s !== "") && An(e, s) : typeof s == "number" && An(e, "" + s) : o !== "suppressContentEditableWarning" && o !== "suppressHydrationWarning" && o !== "autoFocus" && (Un.hasOwnProperty(o) ? s != null && o === "onScroll" && D("scroll", e) : s != null && ai(e, o, s, i))
                            }
                        switch (n) {
                            case "input":
                                pr(e), su(e, r, !1);
                                break;
                            case "textarea":
                                pr(e), cu(e);
                                break;
                            case "option":
                                r.value != null && e.setAttribute("value", "" + mt(r.value));
                                break;
                            case "select":
                                e.multiple = !!r.multiple, o = r.value, o != null ? Zt(e, !!r.multiple, o, !1) : r.defaultValue != null && Zt(e, !!r.multiple, r.defaultValue, !0);
                                break;
                            default:
                                typeof l.onClick == "function" && (e.onclick = Xr)
                        }
                        switch (n) {
                            case "button":
                            case "input":
                            case "select":
                            case "textarea":
                                r = !!r.autoFocus;
                                break e;
                            case "img":
                                r = !0;
                                break e;
                            default:
                                r = !1
                        }
                    }
                    r && (t.flags |= 4)
                }
                t.ref !== null && (t.flags |= 512, t.flags |= 2097152)
            }
            return oe(t), null;
        case 6:
            if (e && t.stateNode != null) fc(e, t, e.memoizedProps, r);
            else {
                if (typeof r != "string" && t.stateNode === null) throw Error(S(166));
                if (n = jt(Zn.current), jt(Be.current), kr(t)) {
                    if (r = t.stateNode, n = t.memoizedProps, r[Ae] = t, (o = r.nodeValue !== n) && (e = xe, e !== null)) switch (e.tag) {
                        case 3:
                            Sr(r.nodeValue, n, (e.mode & 1) !== 0);
                            break;
                        case 5:
                            e.memoizedProps.suppressHydrationWarning !== !0 && Sr(r.nodeValue, n, (e.mode & 1) !== 0)
                    }
                    o && (t.flags |= 4)
                } else r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r), r[Ae] = t, t.stateNode = r
            }
            return oe(t), null;
        case 13:
            if (U($), r = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
                if (A && ye !== null && t.mode & 1 && !(t.flags & 128)) Ra(), ln(), t.flags |= 98560, o = !1;
                else if (o = kr(t), r !== null && r.dehydrated !== null) {
                    if (e === null) {
                        if (!o) throw Error(S(318));
                        if (o = t.memoizedState, o = o !== null ? o.dehydrated : null, !o) throw Error(S(317));
                        o[Ae] = t
                    } else ln(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
                    oe(t), o = !1
                } else ze !== null && (ei(ze), ze = null), o = !0;
                if (!o) return t.flags & 65536 ? t : null
            }
            return t.flags & 128 ? (t.lanes = n, t) : (r = r !== null, r !== (e !== null && e.memoizedState !== null) && r && (t.child.flags |= 8192, t.mode & 1 && (e === null || $.current & 1 ? X === 0 && (X = 3) : Qi())), t.updateQueue !== null && (t.flags |= 4), oe(t), null);
        case 4:
            return un(), Ko(e, t), e === null && Kn(t.stateNode.containerInfo), oe(t), null;
        case 10:
            return Pi(t.type._context), oe(t), null;
        case 17:
            return me(t.type) && Zr(), oe(t), null;
        case 19:
            if (U($), o = t.memoizedState, o === null) return oe(t), null;
            if (r = (t.flags & 128) !== 0, i = o.rendering, i === null)
                if (r) En(o, !1);
                else {
                    if (X !== 0 || e !== null && e.flags & 128)
                        for (e = t.child; e !== null;) {
                            if (i = rl(e), i !== null) {
                                for (t.flags |= 128, En(o, !1), r = i.updateQueue, r !== null && (t.updateQueue = r, t.flags |= 4), t.subtreeFlags = 0, r = n, n = t.child; n !== null;) o = n, e = r, o.flags &= 14680066, i = o.alternate, i === null ? (o.childLanes = 0, o.lanes = e, o.child = null, o.subtreeFlags = 0, o.memoizedProps = null, o.memoizedState = null, o.updateQueue = null, o.dependencies = null, o.stateNode = null) : (o.childLanes = i.childLanes, o.lanes = i.lanes, o.child = i.child, o.subtreeFlags = 0, o.deletions = null, o.memoizedProps = i.memoizedProps, o.memoizedState = i.memoizedState, o.updateQueue = i.updateQueue, o.type = i.type, e = i.dependencies, o.dependencies = e === null ? null : {
                                    lanes: e.lanes,
                                    firstContext: e.firstContext
                                }), n = n.sibling;
                                return F($, $.current & 1 | 2), t.child
                            }
                            e = e.sibling
                        }
                    o.tail !== null && K() > an && (t.flags |= 128, r = !0, En(o, !1), t.lanes = 4194304)
                }
            else {
                if (!r)
                    if (e = rl(i), e !== null) {
                        if (t.flags |= 128, r = !0, n = e.updateQueue, n !== null && (t.updateQueue = n, t.flags |= 4), En(o, !0), o.tail === null && o.tailMode === "hidden" && !i.alternate && !A) return oe(t), null
                    } else 2 * K() - o.renderingStartTime > an && n !== 1073741824 && (t.flags |= 128, r = !0, En(o, !1), t.lanes = 4194304);
                o.isBackwards ? (i.sibling = t.child, t.child = i) : (n = o.last, n !== null ? n.sibling = i : t.child = i, o.last = i)
            }
            return o.tail !== null ? (t = o.tail, o.rendering = t, o.tail = t.sibling, o.renderingStartTime = K(), t.sibling = null, n = $.current, F($, r ? n & 1 | 2 : n & 1), t) : (oe(t), null);
        case 22:
        case 23:
            return Wi(), r = t.memoizedState !== null, e !== null && e.memoizedState !== null !== r && (t.flags |= 8192), r && t.mode & 1 ? ge & 1073741824 && (oe(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : oe(t), null;
        case 24:
            return null;
        case 25:
            return null
    }
    throw Error(S(156, t.tag))
}

function ap(e, t) {
    switch (Ni(t), t.tag) {
        case 1:
            return me(t.type) && Zr(), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 3:
            return un(), U(he), U(ue), zi(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
        case 5:
            return Oi(t), null;
        case 13:
            if (U($), e = t.memoizedState, e !== null && e.dehydrated !== null) {
                if (t.alternate === null) throw Error(S(340));
                ln()
            }
            return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 19:
            return U($), null;
        case 4:
            return un(), null;
        case 10:
            return Pi(t.type._context), null;
        case 22:
        case 23:
            return Wi(), null;
        case 24:
            return null;
        default:
            return null
    }
}
var Cr = !1,
    ie = !1,
    cp = typeof WeakSet == "function" ? WeakSet : Set,
    E = null;

function Gt(e, t) {
    var n = e.ref;
    if (n !== null)
        if (typeof n == "function") try {
            n(null)
        } catch (r) {
            H(e, t, r)
        } else n.current = null
}

function Yo(e, t, n) {
    try {
        n()
    } catch (r) {
        H(e, t, r)
    }
}
var bu = !1;

function dp(e, t) {
    if (Ro = Kr, e = ga(), ki(e)) {
        if ("selectionStart" in e) var n = {
            start: e.selectionStart,
            end: e.selectionEnd
        };
        else e: {
            n = (n = e.ownerDocument) && n.defaultView || window;
            var r = n.getSelection && n.getSelection();
            if (r && r.rangeCount !== 0) {
                n = r.anchorNode;
                var l = r.anchorOffset,
                    o = r.focusNode;
                r = r.focusOffset;
                try {
                    n.nodeType, o.nodeType
                } catch {
                    n = null;
                    break e
                }
                var i = 0,
                    u = -1,
                    s = -1,
                    a = 0,
                    v = 0,
                    p = e,
                    m = null;
                t: for (;;) {
                    for (var y; p !== n || l !== 0 && p.nodeType !== 3 || (u = i + l), p !== o || r !== 0 && p.nodeType !== 3 || (s = i + r), p.nodeType === 3 && (i += p.nodeValue.length), (y = p.firstChild) !== null;) m = p, p = y;
                    for (;;) {
                        if (p === e) break t;
                        if (m === n && ++a === l && (u = i), m === o && ++v === r && (s = i), (y = p.nextSibling) !== null) break;
                        p = m, m = p.parentNode
                    }
                    p = y
                }
                n = u === -1 || s === -1 ? null : {
                    start: u,
                    end: s
                }
            } else n = null
        }
        n = n || {
            start: 0,
            end: 0
        }
    } else n = null;
    for (Lo = {
            focusedElem: e,
            selectionRange: n
        }, Kr = !1, E = t; E !== null;)
        if (t = E, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null) e.return = t, E = e;
        else
            for (; E !== null;) {
                t = E;
                try {
                    var g = t.alternate;
                    if (t.flags & 1024) switch (t.tag) {
                        case 0:
                        case 11:
                        case 15:
                            break;
                        case 1:
                            if (g !== null) {
                                var w = g.memoizedProps,
                                    P = g.memoizedState,
                                    d = t.stateNode,
                                    c = d.getSnapshotBeforeUpdate(t.elementType === t.type ? w : Le(t.type, w), P);
                                d.__reactInternalSnapshotBeforeUpdate = c
                            }
                            break;
                        case 3:
                            var h = t.stateNode.containerInfo;
                            h.nodeType === 1 ? h.textContent = "" : h.nodeType === 9 && h.documentElement && h.removeChild(h.documentElement);
                            break;
                        case 5:
                        case 6:
                        case 4:
                        case 17:
                            break;
                        default:
                            throw Error(S(163))
                    }
                } catch (x) {
                    H(t, t.return, x)
                }
                if (e = t.sibling, e !== null) {
                    e.return = t.return, E = e;
                    break
                }
                E = t.return
            }
    return g = bu, bu = !1, g
}

function In(e, t, n) {
    var r = t.updateQueue;
    if (r = r !== null ? r.lastEffect : null, r !== null) {
        var l = r = r.next;
        do {
            if ((l.tag & e) === e) {
                var o = l.destroy;
                l.destroy = void 0, o !== void 0 && Yo(t, n, o)
            }
            l = l.next
        } while (l !== r)
    }
}

function Sl(e, t) {
    if (t = t.updateQueue, t = t !== null ? t.lastEffect : null, t !== null) {
        var n = t = t.next;
        do {
            if ((n.tag & e) === e) {
                var r = n.create;
                n.destroy = r()
            }
            n = n.next
        } while (n !== t)
    }
}

function Go(e) {
    var t = e.ref;
    if (t !== null) {
        var n = e.stateNode;
        switch (e.tag) {
            case 5:
                e = n;
                break;
            default:
                e = n
        }
        typeof t == "function" ? t(e) : t.current = e
    }
}

function pc(e) {
    var t = e.alternate;
    t !== null && (e.alternate = null, pc(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && (delete t[Ae], delete t[Gn], delete t[Mo], delete t[Yf], delete t[Gf])), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
}

function hc(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4
}

function es(e) {
    e: for (;;) {
        for (; e.sibling === null;) {
            if (e.return === null || hc(e.return)) return null;
            e = e.return
        }
        for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
            if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
            e.child.return = e, e = e.child
        }
        if (!(e.flags & 2)) return e.stateNode
    }
}

function Xo(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6) e = e.stateNode, t ? n.nodeType === 8 ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (n.nodeType === 8 ? (t = n.parentNode, t.insertBefore(e, n)) : (t = n, t.appendChild(e)), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = Xr));
    else if (r !== 4 && (e = e.child, e !== null))
        for (Xo(e, t, n), e = e.sibling; e !== null;) Xo(e, t, n), e = e.sibling
}

function Zo(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
    else if (r !== 4 && (e = e.child, e !== null))
        for (Zo(e, t, n), e = e.sibling; e !== null;) Zo(e, t, n), e = e.sibling
}
var ee = null,
    Oe = !1;

function be(e, t, n) {
    for (n = n.child; n !== null;) mc(e, t, n), n = n.sibling
}

function mc(e, t, n) {
    if ($e && typeof $e.onCommitFiberUnmount == "function") try {
        $e.onCommitFiberUnmount(pl, n)
    } catch {}
    switch (n.tag) {
        case 5:
            ie || Gt(n, t);
        case 6:
            var r = ee,
                l = Oe;
            ee = null, be(e, t, n), ee = r, Oe = l, ee !== null && (Oe ? (e = ee, n = n.stateNode, e.nodeType === 8 ? e.parentNode.removeChild(n) : e.removeChild(n)) : ee.removeChild(n.stateNode));
            break;
        case 18:
            ee !== null && (Oe ? (e = ee, n = n.stateNode, e.nodeType === 8 ? ql(e.parentNode, n) : e.nodeType === 1 && ql(e, n), Hn(e)) : ql(ee, n.stateNode));
            break;
        case 4:
            r = ee, l = Oe, ee = n.stateNode.containerInfo, Oe = !0, be(e, t, n), ee = r, Oe = l;
            break;
        case 0:
        case 11:
        case 14:
        case 15:
            if (!ie && (r = n.updateQueue, r !== null && (r = r.lastEffect, r !== null))) {
                l = r = r.next;
                do {
                    var o = l,
                        i = o.destroy;
                    o = o.tag, i !== void 0 && (o & 2 || o & 4) && Yo(n, t, i), l = l.next
                } while (l !== r)
            }
            be(e, t, n);
            break;
        case 1:
            if (!ie && (Gt(n, t), r = n.stateNode, typeof r.componentWillUnmount == "function")) try {
                r.props = n.memoizedProps, r.state = n.memoizedState, r.componentWillUnmount()
            } catch (u) {
                H(n, t, u)
            }
            be(e, t, n);
            break;
        case 21:
            be(e, t, n);
            break;
        case 22:
            n.mode & 1 ? (ie = (r = ie) || n.memoizedState !== null, be(e, t, n), ie = r) : be(e, t, n);
            break;
        default:
            be(e, t, n)
    }
}

function ts(e) {
    var t = e.updateQueue;
    if (t !== null) {
        e.updateQueue = null;
        var n = e.stateNode;
        n === null && (n = e.stateNode = new cp), t.forEach(function(r) {
            var l = wp.bind(null, e, r);
            n.has(r) || (n.add(r), r.then(l, l))
        })
    }
}

function Re(e, t) {
    var n = t.deletions;
    if (n !== null)
        for (var r = 0; r < n.length; r++) {
            var l = n[r];
            try {
                var o = e,
                    i = t,
                    u = i;
                e: for (; u !== null;) {
                    switch (u.tag) {
                        case 5:
                            ee = u.stateNode, Oe = !1;
                            break e;
                        case 3:
                            ee = u.stateNode.containerInfo, Oe = !0;
                            break e;
                        case 4:
                            ee = u.stateNode.containerInfo, Oe = !0;
                            break e
                    }
                    u = u.return
                }
                if (ee === null) throw Error(S(160));
                mc(o, i, l), ee = null, Oe = !1;
                var s = l.alternate;
                s !== null && (s.return = null), l.return = null
            } catch (a) {
                H(l, t, a)
            }
        }
    if (t.subtreeFlags & 12854)
        for (t = t.child; t !== null;) vc(t, e), t = t.sibling
}

function vc(e, t) {
    var n = e.alternate,
        r = e.flags;
    switch (e.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
            if (Re(t, e), De(e), r & 4) {
                try {
                    In(3, e, e.return), Sl(3, e)
                } catch (w) {
                    H(e, e.return, w)
                }
                try {
                    In(5, e, e.return)
                } catch (w) {
                    H(e, e.return, w)
                }
            }
            break;
        case 1:
            Re(t, e), De(e), r & 512 && n !== null && Gt(n, n.return);
            break;
        case 5:
            if (Re(t, e), De(e), r & 512 && n !== null && Gt(n, n.return), e.flags & 32) {
                var l = e.stateNode;
                try {
                    An(l, "")
                } catch (w) {
                    H(e, e.return, w)
                }
            }
            if (r & 4 && (l = e.stateNode, l != null)) {
                var o = e.memoizedProps,
                    i = n !== null ? n.memoizedProps : o,
                    u = e.type,
                    s = e.updateQueue;
                if (e.updateQueue = null, s !== null) try {
                    u === "input" && o.type === "radio" && o.name != null && Us(l, o), wo(u, i);
                    var a = wo(u, o);
                    for (i = 0; i < s.length; i += 2) {
                        var v = s[i],
                            p = s[i + 1];
                        v === "style" ? Hs(l, p) : v === "dangerouslySetInnerHTML" ? Bs(l, p) : v === "children" ? An(l, p) : ai(l, v, p, a)
                    }
                    switch (u) {
                        case "input":
                            mo(l, o);
                            break;
                        case "textarea":
                            As(l, o);
                            break;
                        case "select":
                            var m = l._wrapperState.wasMultiple;
                            l._wrapperState.wasMultiple = !!o.multiple;
                            var y = o.value;
                            y != null ? Zt(l, !!o.multiple, y, !1) : m !== !!o.multiple && (o.defaultValue != null ? Zt(l, !!o.multiple, o.defaultValue, !0) : Zt(l, !!o.multiple, o.multiple ? [] : "", !1))
                    }
                    l[Gn] = o
                } catch (w) {
                    H(e, e.return, w)
                }
            }
            break;
        case 6:
            if (Re(t, e), De(e), r & 4) {
                if (e.stateNode === null) throw Error(S(162));
                l = e.stateNode, o = e.memoizedProps;
                try {
                    l.nodeValue = o
                } catch (w) {
                    H(e, e.return, w)
                }
            }
            break;
        case 3:
            if (Re(t, e), De(e), r & 4 && n !== null && n.memoizedState.isDehydrated) try {
                Hn(t.containerInfo)
            } catch (w) {
                H(e, e.return, w)
            }
            break;
        case 4:
            Re(t, e), De(e);
            break;
        case 13:
            Re(t, e), De(e), l = e.child, l.flags & 8192 && (o = l.memoizedState !== null, l.stateNode.isHidden = o, !o || l.alternate !== null && l.alternate.memoizedState !== null || (Vi = K())), r & 4 && ts(e);
            break;
        case 22:
            if (v = n !== null && n.memoizedState !== null, e.mode & 1 ? (ie = (a = ie) || v, Re(t, e), ie = a) : Re(t, e), De(e), r & 8192) {
                if (a = e.memoizedState !== null, (e.stateNode.isHidden = a) && !v && e.mode & 1)
                    for (E = e, v = e.child; v !== null;) {
                        for (p = E = v; E !== null;) {
                            switch (m = E, y = m.child, m.tag) {
                                case 0:
                                case 11:
                                case 14:
                                case 15:
                                    In(4, m, m.return);
                                    break;
                                case 1:
                                    Gt(m, m.return);
                                    var g = m.stateNode;
                                    if (typeof g.componentWillUnmount == "function") {
                                        r = m, n = m.return;
                                        try {
                                            t = r, g.props = t.memoizedProps, g.state = t.memoizedState, g.componentWillUnmount()
                                        } catch (w) {
                                            H(r, n, w)
                                        }
                                    }
                                    break;
                                case 5:
                                    Gt(m, m.return);
                                    break;
                                case 22:
                                    if (m.memoizedState !== null) {
                                        rs(p);
                                        continue
                                    }
                            }
                            y !== null ? (y.return = m, E = y) : rs(p)
                        }
                        v = v.sibling
                    }
                e: for (v = null, p = e;;) {
                    if (p.tag === 5) {
                        if (v === null) {
                            v = p;
                            try {
                                l = p.stateNode, a ? (o = l.style, typeof o.setProperty == "function" ? o.setProperty("display", "none", "important") : o.display = "none") : (u = p.stateNode, s = p.memoizedProps.style, i = s != null && s.hasOwnProperty("display") ? s.display : null, u.style.display = Vs("display", i))
                            } catch (w) {
                                H(e, e.return, w)
                            }
                        }
                    } else if (p.tag === 6) {
                        if (v === null) try {
                            p.stateNode.nodeValue = a ? "" : p.memoizedProps
                        } catch (w) {
                            H(e, e.return, w)
                        }
                    } else if ((p.tag !== 22 && p.tag !== 23 || p.memoizedState === null || p === e) && p.child !== null) {
                        p.child.return = p, p = p.child;
                        continue
                    }
                    if (p === e) break e;
                    for (; p.sibling === null;) {
                        if (p.return === null || p.return === e) break e;
                        v === p && (v = null), p = p.return
                    }
                    v === p && (v = null), p.sibling.return = p.return, p = p.sibling
                }
            }
            break;
        case 19:
            Re(t, e), De(e), r & 4 && ts(e);
            break;
        case 21:
            break;
        default:
            Re(t, e), De(e)
    }
}

function De(e) {
    var t = e.flags;
    if (t & 2) {
        try {
            e: {
                for (var n = e.return; n !== null;) {
                    if (hc(n)) {
                        var r = n;
                        break e
                    }
                    n = n.return
                }
                throw Error(S(160))
            }
            switch (r.tag) {
                case 5:
                    var l = r.stateNode;
                    r.flags & 32 && (An(l, ""), r.flags &= -33);
                    var o = es(e);
                    Zo(e, o, l);
                    break;
                case 3:
                case 4:
                    var i = r.stateNode.containerInfo,
                        u = es(e);
                    Xo(e, u, i);
                    break;
                default:
                    throw Error(S(161))
            }
        }
        catch (s) {
            H(e, e.return, s)
        }
        e.flags &= -3
    }
    t & 4096 && (e.flags &= -4097)
}

function fp(e, t, n) {
    E = e, gc(e)
}

function gc(e, t, n) {
    for (var r = (e.mode & 1) !== 0; E !== null;) {
        var l = E,
            o = l.child;
        if (l.tag === 22 && r) {
            var i = l.memoizedState !== null || Cr;
            if (!i) {
                var u = l.alternate,
                    s = u !== null && u.memoizedState !== null || ie;
                u = Cr;
                var a = ie;
                if (Cr = i, (ie = s) && !a)
                    for (E = l; E !== null;) i = E, s = i.child, i.tag === 22 && i.memoizedState !== null ? ls(l) : s !== null ? (s.return = i, E = s) : ls(l);
                for (; o !== null;) E = o, gc(o), o = o.sibling;
                E = l, Cr = u, ie = a
            }
            ns(e)
        } else l.subtreeFlags & 8772 && o !== null ? (o.return = l, E = o) : ns(e)
    }
}

function ns(e) {
    for (; E !== null;) {
        var t = E;
        if (t.flags & 8772) {
            var n = t.alternate;
            try {
                if (t.flags & 8772) switch (t.tag) {
                    case 0:
                    case 11:
                    case 15:
                        ie || Sl(5, t);
                        break;
                    case 1:
                        var r = t.stateNode;
                        if (t.flags & 4 && !ie)
                            if (n === null) r.componentDidMount();
                            else {
                                var l = t.elementType === t.type ? n.memoizedProps : Le(t.type, n.memoizedProps);
                                r.componentDidUpdate(l, n.memoizedState, r.__reactInternalSnapshotBeforeUpdate)
                            }
                        var o = t.updateQueue;
                        o !== null && $u(t, o, r);
                        break;
                    case 3:
                        var i = t.updateQueue;
                        if (i !== null) {
                            if (n = null, t.child !== null) switch (t.child.tag) {
                                case 5:
                                    n = t.child.stateNode;
                                    break;
                                case 1:
                                    n = t.child.stateNode
                            }
                            $u(t, i, n)
                        }
                        break;
                    case 5:
                        var u = t.stateNode;
                        if (n === null && t.flags & 4) {
                            n = u;
                            var s = t.memoizedProps;
                            switch (t.type) {
                                case "button":
                                case "input":
                                case "select":
                                case "textarea":
                                    s.autoFocus && n.focus();
                                    break;
                                case "img":
                                    s.src && (n.src = s.src)
                            }
                        }
                        break;
                    case 6:
                        break;
                    case 4:
                        break;
                    case 12:
                        break;
                    case 13:
                        if (t.memoizedState === null) {
                            var a = t.alternate;
                            if (a !== null) {
                                var v = a.memoizedState;
                                if (v !== null) {
                                    var p = v.dehydrated;
                                    p !== null && Hn(p)
                                }
                            }
                        }
                        break;
                    case 19:
                    case 17:
                    case 21:
                    case 22:
                    case 23:
                    case 25:
                        break;
                    default:
                        throw Error(S(163))
                }
                ie || t.flags & 512 && Go(t)
            } catch (m) {
                H(t, t.return, m)
            }
        }
        if (t === e) {
            E = null;
            break
        }
        if (n = t.sibling, n !== null) {
            n.return = t.return, E = n;
            break
        }
        E = t.return
    }
}

function rs(e) {
    for (; E !== null;) {
        var t = E;
        if (t === e) {
            E = null;
            break
        }
        var n = t.sibling;
        if (n !== null) {
            n.return = t.return, E = n;
            break
        }
        E = t.return
    }
}

function ls(e) {
    for (; E !== null;) {
        var t = E;
        try {
            switch (t.tag) {
                case 0:
                case 11:
                case 15:
                    var n = t.return;
                    try {
                        Sl(4, t)
                    } catch (s) {
                        H(t, n, s)
                    }
                    break;
                case 1:
                    var r = t.stateNode;
                    if (typeof r.componentDidMount == "function") {
                        var l = t.return;
                        try {
                            r.componentDidMount()
                        } catch (s) {
                            H(t, l, s)
                        }
                    }
                    var o = t.return;
                    try {
                        Go(t)
                    } catch (s) {
                        H(t, o, s)
                    }
                    break;
                case 5:
                    var i = t.return;
                    try {
                        Go(t)
                    } catch (s) {
                        H(t, i, s)
                    }
            }
        } catch (s) {
            H(t, t.return, s)
        }
        if (t === e) {
            E = null;
            break
        }
        var u = t.sibling;
        if (u !== null) {
            u.return = t.return, E = u;
            break
        }
        E = t.return
    }
}
var pp = Math.ceil,
    il = qe.ReactCurrentDispatcher,
    $i = qe.ReactCurrentOwner,
    je = qe.ReactCurrentBatchConfig,
    M = 0,
    b = null,
    Y = null,
    ne = 0,
    ge = 0,
    Xt = yt(0),
    X = 0,
    er = null,
    zt = 0,
    kl = 0,
    Bi = 0,
    Fn = null,
    fe = null,
    Vi = 0,
    an = 1 / 0,
    Ve = null,
    ul = !1,
    qo = null,
    ft = null,
    jr = !1,
    ot = null,
    sl = 0,
    Dn = 0,
    Jo = null,
    Dr = -1,
    Ur = 0;

function ae() {
    return M & 6 ? K() : Dr !== -1 ? Dr : Dr = K()
}

function pt(e) {
    return e.mode & 1 ? M & 2 && ne !== 0 ? ne & -ne : Zf.transition !== null ? (Ur === 0 && (Ur = ta()), Ur) : (e = I, e !== 0 || (e = window.event, e = e === void 0 ? 16 : sa(e.type)), e) : 1
}

function Ie(e, t, n, r) {
    if (50 < Dn) throw Dn = 0, Jo = null, Error(S(185));
    lr(e, n, r), (!(M & 2) || e !== b) && (e === b && (!(M & 2) && (kl |= n), X === 4 && rt(e, ne)), ve(e, r), n === 1 && M === 0 && !(t.mode & 1) && (an = K() + 500, yl && xt()))
}

function ve(e, t) {
    var n = e.callbackNode;
    Xd(e, t);
    var r = Qr(e, e === b ? ne : 0);
    if (r === 0) n !== null && pu(n), e.callbackNode = null, e.callbackPriority = 0;
    else if (t = r & -r, e.callbackPriority !== t) {
        if (n != null && pu(n), t === 1) e.tag === 0 ? Xf(os.bind(null, e)) : _a(os.bind(null, e)), Qf(function() {
            !(M & 6) && xt()
        }), n = null;
        else {
            switch (na(r)) {
                case 1:
                    n = hi;
                    break;
                case 4:
                    n = bs;
                    break;
                case 16:
                    n = Wr;
                    break;
                case 536870912:
                    n = ea;
                    break;
                default:
                    n = Wr
            }
            n = Cc(n, yc.bind(null, e))
        }
        e.callbackPriority = t, e.callbackNode = n
    }
}

function yc(e, t) {
    if (Dr = -1, Ur = 0, M & 6) throw Error(S(327));
    var n = e.callbackNode;
    if (tn() && e.callbackNode !== n) return null;
    var r = Qr(e, e === b ? ne : 0);
    if (r === 0) return null;
    if (r & 30 || r & e.expiredLanes || t) t = al(e, r);
    else {
        t = r;
        var l = M;
        M |= 2;
        var o = wc();
        (b !== e || ne !== t) && (Ve = null, an = K() + 500, _t(e, t));
        do try {
            vp();
            break
        } catch (u) {
            xc(e, u)
        }
        while (!0);
        _i(), il.current = o, M = l, Y !== null ? t = 0 : (b = null, ne = 0, t = X)
    }
    if (t !== 0) {
        if (t === 2 && (l = Co(e), l !== 0 && (r = l, t = bo(e, l))), t === 1) throw n = er, _t(e, 0), rt(e, r), ve(e, K()), n;
        if (t === 6) rt(e, r);
        else {
            if (l = e.current.alternate, !(r & 30) && !hp(l) && (t = al(e, r), t === 2 && (o = Co(e), o !== 0 && (r = o, t = bo(e, o))), t === 1)) throw n = er, _t(e, 0), rt(e, r), ve(e, K()), n;
            switch (e.finishedWork = l, e.finishedLanes = r, t) {
                case 0:
                case 1:
                    throw Error(S(345));
                case 2:
                    Et(e, fe, Ve);
                    break;
                case 3:
                    if (rt(e, r), (r & 130023424) === r && (t = Vi + 500 - K(), 10 < t)) {
                        if (Qr(e, 0) !== 0) break;
                        if (l = e.suspendedLanes, (l & r) !== r) {
                            ae(), e.pingedLanes |= e.suspendedLanes & l;
                            break
                        }
                        e.timeoutHandle = zo(Et.bind(null, e, fe, Ve), t);
                        break
                    }
                    Et(e, fe, Ve);
                    break;
                case 4:
                    if (rt(e, r), (r & 4194240) === r) break;
                    for (t = e.eventTimes, l = -1; 0 < r;) {
                        var i = 31 - Me(r);
                        o = 1 << i, i = t[i], i > l && (l = i), r &= ~o
                    }
                    if (r = l, r = K() - r, r = (120 > r ? 120 : 480 > r ? 480 : 1080 > r ? 1080 : 1920 > r ? 1920 : 3e3 > r ? 3e3 : 4320 > r ? 4320 : 1960 * pp(r / 1960)) - r, 10 < r) {
                        e.timeoutHandle = zo(Et.bind(null, e, fe, Ve), r);
                        break
                    }
                    Et(e, fe, Ve);
                    break;
                case 5:
                    Et(e, fe, Ve);
                    break;
                default:
                    throw Error(S(329))
            }
        }
    }
    return ve(e, K()), e.callbackNode === n ? yc.bind(null, e) : null
}

function bo(e, t) {
    var n = Fn;
    return e.current.memoizedState.isDehydrated && (_t(e, t).flags |= 256), e = al(e, t), e !== 2 && (t = fe, fe = n, t !== null && ei(t)), e
}

function ei(e) {
    fe === null ? fe = e : fe.push.apply(fe, e)
}

function hp(e) {
    for (var t = e;;) {
        if (t.flags & 16384) {
            var n = t.updateQueue;
            if (n !== null && (n = n.stores, n !== null))
                for (var r = 0; r < n.length; r++) {
                    var l = n[r],
                        o = l.getSnapshot;
                    l = l.value;
                    try {
                        if (!Fe(o(), l)) return !1
                    } catch {
                        return !1
                    }
                }
        }
        if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
        else {
            if (t === e) break;
            for (; t.sibling === null;) {
                if (t.return === null || t.return === e) return !0;
                t = t.return
            }
            t.sibling.return = t.return, t = t.sibling
        }
    }
    return !0
}

function rt(e, t) {
    for (t &= ~Bi, t &= ~kl, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t;) {
        var n = 31 - Me(t),
            r = 1 << n;
        e[n] = -1, t &= ~r
    }
}

function os(e) {
    if (M & 6) throw Error(S(327));
    tn();
    var t = Qr(e, 0);
    if (!(t & 1)) return ve(e, K()), null;
    var n = al(e, t);
    if (e.tag !== 0 && n === 2) {
        var r = Co(e);
        r !== 0 && (t = r, n = bo(e, r))
    }
    if (n === 1) throw n = er, _t(e, 0), rt(e, t), ve(e, K()), n;
    if (n === 6) throw Error(S(345));
    return e.finishedWork = e.current.alternate, e.finishedLanes = t, Et(e, fe, Ve), ve(e, K()), null
}

function Hi(e, t) {
    var n = M;
    M |= 1;
    try {
        return e(t)
    } finally {
        M = n, M === 0 && (an = K() + 500, yl && xt())
    }
}

function Mt(e) {
    ot !== null && ot.tag === 0 && !(M & 6) && tn();
    var t = M;
    M |= 1;
    var n = je.transition,
        r = I;
    try {
        if (je.transition = null, I = 1, e) return e()
    } finally {
        I = r, je.transition = n, M = t, !(M & 6) && xt()
    }
}

function Wi() {
    ge = Xt.current, U(Xt)
}

function _t(e, t) {
    e.finishedWork = null, e.finishedLanes = 0;
    var n = e.timeoutHandle;
    if (n !== -1 && (e.timeoutHandle = -1, Wf(n)), Y !== null)
        for (n = Y.return; n !== null;) {
            var r = n;
            switch (Ni(r), r.tag) {
                case 1:
                    r = r.type.childContextTypes, r != null && Zr();
                    break;
                case 3:
                    un(), U(he), U(ue), zi();
                    break;
                case 5:
                    Oi(r);
                    break;
                case 4:
                    un();
                    break;
                case 13:
                    U($);
                    break;
                case 19:
                    U($);
                    break;
                case 10:
                    Pi(r.type._context);
                    break;
                case 22:
                case 23:
                    Wi()
            }
            n = n.return
        }
    if (b = e, Y = e = ht(e.current, null), ne = ge = t, X = 0, er = null, Bi = kl = zt = 0, fe = Fn = null, Ct !== null) {
        for (t = 0; t < Ct.length; t++)
            if (n = Ct[t], r = n.interleaved, r !== null) {
                n.interleaved = null;
                var l = r.next,
                    o = n.pending;
                if (o !== null) {
                    var i = o.next;
                    o.next = l, r.next = i
                }
                n.pending = r
            }
        Ct = null
    }
    return e
}

function xc(e, t) {
    do {
        var n = Y;
        try {
            if (_i(), Mr.current = ol, ll) {
                for (var r = B.memoizedState; r !== null;) {
                    var l = r.queue;
                    l !== null && (l.pending = null), r = r.next
                }
                ll = !1
            }
            if (Ot = 0, J = G = B = null, Mn = !1, qn = 0, $i.current = null, n === null || n.return === null) {
                X = 1, er = t, Y = null;
                break
            }
            e: {
                var o = e,
                    i = n.return,
                    u = n,
                    s = t;
                if (t = ne, u.flags |= 32768, s !== null && typeof s == "object" && typeof s.then == "function") {
                    var a = s,
                        v = u,
                        p = v.tag;
                    if (!(v.mode & 1) && (p === 0 || p === 11 || p === 15)) {
                        var m = v.alternate;
                        m ? (v.updateQueue = m.updateQueue, v.memoizedState = m.memoizedState, v.lanes = m.lanes) : (v.updateQueue = null, v.memoizedState = null)
                    }
                    var y = Ku(i);
                    if (y !== null) {
                        y.flags &= -257, Yu(y, i, u, o, t), y.mode & 1 && Qu(o, a, t), t = y, s = a;
                        var g = t.updateQueue;
                        if (g === null) {
                            var w = new Set;
                            w.add(s), t.updateQueue = w
                        } else g.add(s);
                        break e
                    } else {
                        if (!(t & 1)) {
                            Qu(o, a, t), Qi();
                            break e
                        }
                        s = Error(S(426))
                    }
                } else if (A && u.mode & 1) {
                    var P = Ku(i);
                    if (P !== null) {
                        !(P.flags & 65536) && (P.flags |= 256), Yu(P, i, u, o, t), Ci(sn(s, u));
                        break e
                    }
                }
                o = s = sn(s, u),
                X !== 4 && (X = 2),
                Fn === null ? Fn = [o] : Fn.push(o),
                o = i;do {
                    switch (o.tag) {
                        case 3:
                            o.flags |= 65536, t &= -t, o.lanes |= t;
                            var d = nc(o, s, t);
                            Au(o, d);
                            break e;
                        case 1:
                            u = s;
                            var c = o.type,
                                h = o.stateNode;
                            if (!(o.flags & 128) && (typeof c.getDerivedStateFromError == "function" || h !== null && typeof h.componentDidCatch == "function" && (ft === null || !ft.has(h)))) {
                                o.flags |= 65536, t &= -t, o.lanes |= t;
                                var x = rc(o, u, t);
                                Au(o, x);
                                break e
                            }
                    }
                    o = o.return
                } while (o !== null)
            }
            kc(n)
        } catch (k) {
            t = k, Y === n && n !== null && (Y = n = n.return);
            continue
        }
        break
    } while (!0)
}

function wc() {
    var e = il.current;
    return il.current = ol, e === null ? ol : e
}

function Qi() {
    (X === 0 || X === 3 || X === 2) && (X = 4), b === null || !(zt & 268435455) && !(kl & 268435455) || rt(b, ne)
}

function al(e, t) {
    var n = M;
    M |= 2;
    var r = wc();
    (b !== e || ne !== t) && (Ve = null, _t(e, t));
    do try {
        mp();
        break
    } catch (l) {
        xc(e, l)
    }
    while (!0);
    if (_i(), M = n, il.current = r, Y !== null) throw Error(S(261));
    return b = null, ne = 0, X
}

function mp() {
    for (; Y !== null;) Sc(Y)
}

function vp() {
    for (; Y !== null && !$d();) Sc(Y)
}

function Sc(e) {
    var t = Nc(e.alternate, e, ge);
    e.memoizedProps = e.pendingProps, t === null ? kc(e) : Y = t, $i.current = null
}

function kc(e) {
    var t = e;
    do {
        var n = t.alternate;
        if (e = t.return, t.flags & 32768) {
            if (n = ap(n, t), n !== null) {
                n.flags &= 32767, Y = n;
                return
            }
            if (e !== null) e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null;
            else {
                X = 6, Y = null;
                return
            }
        } else if (n = sp(n, t, ge), n !== null) {
            Y = n;
            return
        }
        if (t = t.sibling, t !== null) {
            Y = t;
            return
        }
        Y = t = e
    } while (t !== null);
    X === 0 && (X = 5)
}

function Et(e, t, n) {
    var r = I,
        l = je.transition;
    try {
        je.transition = null, I = 1, gp(e, t, n, r)
    } finally {
        je.transition = l, I = r
    }
    return null
}

function gp(e, t, n, r) {
    do tn(); while (ot !== null);
    if (M & 6) throw Error(S(327));
    n = e.finishedWork;
    var l = e.finishedLanes;
    if (n === null) return null;
    if (e.finishedWork = null, e.finishedLanes = 0, n === e.current) throw Error(S(177));
    e.callbackNode = null, e.callbackPriority = 0;
    var o = n.lanes | n.childLanes;
    if (Zd(e, o), e === b && (Y = b = null, ne = 0), !(n.subtreeFlags & 2064) && !(n.flags & 2064) || jr || (jr = !0, Cc(Wr, function() {
            return tn(), null
        })), o = (n.flags & 15990) !== 0, n.subtreeFlags & 15990 || o) {
        o = je.transition, je.transition = null;
        var i = I;
        I = 1;
        var u = M;
        M |= 4, $i.current = null, dp(e, n), vc(n, e), Df(Lo), Kr = !!Ro, Lo = Ro = null, e.current = n, fp(n), Bd(), M = u, I = i, je.transition = o
    } else e.current = n;
    if (jr && (jr = !1, ot = e, sl = l), o = e.pendingLanes, o === 0 && (ft = null), Wd(n.stateNode), ve(e, K()), t !== null)
        for (r = e.onRecoverableError, n = 0; n < t.length; n++) l = t[n], r(l.value, {
            componentStack: l.stack,
            digest: l.digest
        });
    if (ul) throw ul = !1, e = qo, qo = null, e;
    return sl & 1 && e.tag !== 0 && tn(), o = e.pendingLanes, o & 1 ? e === Jo ? Dn++ : (Dn = 0, Jo = e) : Dn = 0, xt(), null
}

function tn() {
    if (ot !== null) {
        var e = na(sl),
            t = je.transition,
            n = I;
        try {
            if (je.transition = null, I = 16 > e ? 16 : e, ot === null) var r = !1;
            else {
                if (e = ot, ot = null, sl = 0, M & 6) throw Error(S(331));
                var l = M;
                for (M |= 4, E = e.current; E !== null;) {
                    var o = E,
                        i = o.child;
                    if (E.flags & 16) {
                        var u = o.deletions;
                        if (u !== null) {
                            for (var s = 0; s < u.length; s++) {
                                var a = u[s];
                                for (E = a; E !== null;) {
                                    var v = E;
                                    switch (v.tag) {
                                        case 0:
                                        case 11:
                                        case 15:
                                            In(8, v, o)
                                    }
                                    var p = v.child;
                                    if (p !== null) p.return = v, E = p;
                                    else
                                        for (; E !== null;) {
                                            v = E;
                                            var m = v.sibling,
                                                y = v.return;
                                            if (pc(v), v === a) {
                                                E = null;
                                                break
                                            }
                                            if (m !== null) {
                                                m.return = y, E = m;
                                                break
                                            }
                                            E = y
                                        }
                                }
                            }
                            var g = o.alternate;
                            if (g !== null) {
                                var w = g.child;
                                if (w !== null) {
                                    g.child = null;
                                    do {
                                        var P = w.sibling;
                                        w.sibling = null, w = P
                                    } while (w !== null)
                                }
                            }
                            E = o
                        }
                    }
                    if (o.subtreeFlags & 2064 && i !== null) i.return = o, E = i;
                    else e: for (; E !== null;) {
                        if (o = E, o.flags & 2048) switch (o.tag) {
                            case 0:
                            case 11:
                            case 15:
                                In(9, o, o.return)
                        }
                        var d = o.sibling;
                        if (d !== null) {
                            d.return = o.return, E = d;
                            break e
                        }
                        E = o.return
                    }
                }
                var c = e.current;
                for (E = c; E !== null;) {
                    i = E;
                    var h = i.child;
                    if (i.subtreeFlags & 2064 && h !== null) h.return = i, E = h;
                    else e: for (i = c; E !== null;) {
                        if (u = E, u.flags & 2048) try {
                            switch (u.tag) {
                                case 0:
                                case 11:
                                case 15:
                                    Sl(9, u)
                            }
                        } catch (k) {
                            H(u, u.return, k)
                        }
                        if (u === i) {
                            E = null;
                            break e
                        }
                        var x = u.sibling;
                        if (x !== null) {
                            x.return = u.return, E = x;
                            break e
                        }
                        E = u.return
                    }
                }
                if (M = l, xt(), $e && typeof $e.onPostCommitFiberRoot == "function") try {
                    $e.onPostCommitFiberRoot(pl, e)
                } catch {}
                r = !0
            }
            return r
        } finally {
            I = n, je.transition = t
        }
    }
    return !1
}

function is(e, t, n) {
    t = sn(n, t), t = nc(e, t, 1), e = dt(e, t, 1), t = ae(), e !== null && (lr(e, 1, t), ve(e, t))
}

function H(e, t, n) {
    if (e.tag === 3) is(e, e, n);
    else
        for (; t !== null;) {
            if (t.tag === 3) {
                is(t, e, n);
                break
            } else if (t.tag === 1) {
                var r = t.stateNode;
                if (typeof t.type.getDerivedStateFromError == "function" || typeof r.componentDidCatch == "function" && (ft === null || !ft.has(r))) {
                    e = sn(n, e), e = rc(t, e, 1), t = dt(t, e, 1), e = ae(), t !== null && (lr(t, 1, e), ve(t, e));
                    break
                }
            }
            t = t.return
        }
}

function yp(e, t, n) {
    var r = e.pingCache;
    r !== null && r.delete(t), t = ae(), e.pingedLanes |= e.suspendedLanes & n, b === e && (ne & n) === n && (X === 4 || X === 3 && (ne & 130023424) === ne && 500 > K() - Vi ? _t(e, 0) : Bi |= n), ve(e, t)
}

function Ec(e, t) {
    t === 0 && (e.mode & 1 ? (t = vr, vr <<= 1, !(vr & 130023424) && (vr = 4194304)) : t = 1);
    var n = ae();
    e = Xe(e, t), e !== null && (lr(e, t, n), ve(e, n))
}

function xp(e) {
    var t = e.memoizedState,
        n = 0;
    t !== null && (n = t.retryLane), Ec(e, n)
}

function wp(e, t) {
    var n = 0;
    switch (e.tag) {
        case 13:
            var r = e.stateNode,
                l = e.memoizedState;
            l !== null && (n = l.retryLane);
            break;
        case 19:
            r = e.stateNode;
            break;
        default:
            throw Error(S(314))
    }
    r !== null && r.delete(t), Ec(e, n)
}
var Nc;
Nc = function(e, t, n) {
    if (e !== null)
        if (e.memoizedProps !== t.pendingProps || he.current) pe = !0;
        else {
            if (!(e.lanes & n) && !(t.flags & 128)) return pe = !1, up(e, t, n);
            pe = !!(e.flags & 131072)
        }
    else pe = !1, A && t.flags & 1048576 && Pa(t, br, t.index);
    switch (t.lanes = 0, t.tag) {
        case 2:
            var r = t.type;
            Fr(e, t), e = t.pendingProps;
            var l = rn(t, ue.current);
            en(t, n), l = Ii(null, t, r, e, l, n);
            var o = Fi();
            return t.flags |= 1, typeof l == "object" && l !== null && typeof l.render == "function" && l.$$typeof === void 0 ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, me(r) ? (o = !0, qr(t)) : o = !1, t.memoizedState = l.state !== null && l.state !== void 0 ? l.state : null, Ri(t), l.updater = wl, t.stateNode = l, l._reactInternals = t, $o(t, r, e, n), t = Ho(null, t, r, !0, o, n)) : (t.tag = 0, A && o && Ei(t), se(null, t, l, n), t = t.child), t;
        case 16:
            r = t.elementType;
            e: {
                switch (Fr(e, t), e = t.pendingProps, l = r._init, r = l(r._payload), t.type = r, l = t.tag = kp(r), e = Le(r, e), l) {
                    case 0:
                        t = Vo(null, t, r, e, n);
                        break e;
                    case 1:
                        t = Zu(null, t, r, e, n);
                        break e;
                    case 11:
                        t = Gu(null, t, r, e, n);
                        break e;
                    case 14:
                        t = Xu(null, t, r, Le(r.type, e), n);
                        break e
                }
                throw Error(S(306, r, ""))
            }
            return t;
        case 0:
            return r = t.type, l = t.pendingProps, l = t.elementType === r ? l : Le(r, l), Vo(e, t, r, l, n);
        case 1:
            return r = t.type, l = t.pendingProps, l = t.elementType === r ? l : Le(r, l), Zu(e, t, r, l, n);
        case 3:
            e: {
                if (uc(t), e === null) throw Error(S(387));r = t.pendingProps,
                o = t.memoizedState,
                l = o.element,
                Ma(e, t),
                nl(t, r, null, n);
                var i = t.memoizedState;
                if (r = i.element, o.isDehydrated)
                    if (o = {
                            element: r,
                            isDehydrated: !1,
                            cache: i.cache,
                            pendingSuspenseBoundaries: i.pendingSuspenseBoundaries,
                            transitions: i.transitions
                        }, t.updateQueue.baseState = o, t.memoizedState = o, t.flags & 256) {
                        l = sn(Error(S(423)), t), t = qu(e, t, r, n, l);
                        break e
                    } else if (r !== l) {
                    l = sn(Error(S(424)), t), t = qu(e, t, r, n, l);
                    break e
                } else
                    for (ye = ct(t.stateNode.containerInfo.firstChild), xe = t, A = !0, ze = null, n = Oa(t, null, r, n), t.child = n; n;) n.flags = n.flags & -3 | 4096, n = n.sibling;
                else {
                    if (ln(), r === l) {
                        t = Ze(e, t, n);
                        break e
                    }
                    se(e, t, r, n)
                }
                t = t.child
            }
            return t;
        case 5:
            return Ia(t), e === null && Do(t), r = t.type, l = t.pendingProps, o = e !== null ? e.memoizedProps : null, i = l.children, Oo(r, l) ? i = null : o !== null && Oo(r, o) && (t.flags |= 32), ic(e, t), se(e, t, i, n), t.child;
        case 6:
            return e === null && Do(t), null;
        case 13:
            return sc(e, t, n);
        case 4:
            return Li(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = on(t, null, r, n) : se(e, t, r, n), t.child;
        case 11:
            return r = t.type, l = t.pendingProps, l = t.elementType === r ? l : Le(r, l), Gu(e, t, r, l, n);
        case 7:
            return se(e, t, t.pendingProps, n), t.child;
        case 8:
            return se(e, t, t.pendingProps.children, n), t.child;
        case 12:
            return se(e, t, t.pendingProps.children, n), t.child;
        case 10:
            e: {
                if (r = t.type._context, l = t.pendingProps, o = t.memoizedProps, i = l.value, F(el, r._currentValue), r._currentValue = i, o !== null)
                    if (Fe(o.value, i)) {
                        if (o.children === l.children && !he.current) {
                            t = Ze(e, t, n);
                            break e
                        }
                    } else
                        for (o = t.child, o !== null && (o.return = t); o !== null;) {
                            var u = o.dependencies;
                            if (u !== null) {
                                i = o.child;
                                for (var s = u.firstContext; s !== null;) {
                                    if (s.context === r) {
                                        if (o.tag === 1) {
                                            s = Ke(-1, n & -n), s.tag = 2;
                                            var a = o.updateQueue;
                                            if (a !== null) {
                                                a = a.shared;
                                                var v = a.pending;
                                                v === null ? s.next = s : (s.next = v.next, v.next = s), a.pending = s
                                            }
                                        }
                                        o.lanes |= n, s = o.alternate, s !== null && (s.lanes |= n), Uo(o.return, n, t), u.lanes |= n;
                                        break
                                    }
                                    s = s.next
                                }
                            } else if (o.tag === 10) i = o.type === t.type ? null : o.child;
                            else if (o.tag === 18) {
                                if (i = o.return, i === null) throw Error(S(341));
                                i.lanes |= n, u = i.alternate, u !== null && (u.lanes |= n), Uo(i, n, t), i = o.sibling
                            } else i = o.child;
                            if (i !== null) i.return = o;
                            else
                                for (i = o; i !== null;) {
                                    if (i === t) {
                                        i = null;
                                        break
                                    }
                                    if (o = i.sibling, o !== null) {
                                        o.return = i.return, i = o;
                                        break
                                    }
                                    i = i.return
                                }
                            o = i
                        }
                se(e, t, l.children, n),
                t = t.child
            }
            return t;
        case 9:
            return l = t.type, r = t.pendingProps.children, en(t, n), l = _e(l), r = r(l), t.flags |= 1, se(e, t, r, n), t.child;
        case 14:
            return r = t.type, l = Le(r, t.pendingProps), l = Le(r.type, l), Xu(e, t, r, l, n);
        case 15:
            return lc(e, t, t.type, t.pendingProps, n);
        case 17:
            return r = t.type, l = t.pendingProps, l = t.elementType === r ? l : Le(r, l), Fr(e, t), t.tag = 1, me(r) ? (e = !0, qr(t)) : e = !1, en(t, n), tc(t, r, l), $o(t, r, l, n), Ho(null, t, r, !0, e, n);
        case 19:
            return ac(e, t, n);
        case 22:
            return oc(e, t, n)
    }
    throw Error(S(156, t.tag))
};

function Cc(e, t) {
    return Js(e, t)
}

function Sp(e, t, n, r) {
    this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
}

function Ce(e, t, n, r) {
    return new Sp(e, t, n, r)
}

function Ki(e) {
    return e = e.prototype, !(!e || !e.isReactComponent)
}

function kp(e) {
    if (typeof e == "function") return Ki(e) ? 1 : 0;
    if (e != null) {
        if (e = e.$$typeof, e === di) return 11;
        if (e === fi) return 14
    }
    return 2
}

function ht(e, t) {
    var n = e.alternate;
    return n === null ? (n = Ce(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 14680064, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : {
        lanes: t.lanes,
        firstContext: t.firstContext
    }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n
}

function Ar(e, t, n, r, l, o) {
    var i = 2;
    if (r = e, typeof e == "function") Ki(e) && (i = 1);
    else if (typeof e == "string") i = 5;
    else e: switch (e) {
        case At:
            return Pt(n.children, l, o, t);
        case ci:
            i = 8, l |= 8;
            break;
        case ao:
            return e = Ce(12, n, t, l | 2), e.elementType = ao, e.lanes = o, e;
        case co:
            return e = Ce(13, n, t, l), e.elementType = co, e.lanes = o, e;
        case fo:
            return e = Ce(19, n, t, l), e.elementType = fo, e.lanes = o, e;
        case Is:
            return El(n, l, o, t);
        default:
            if (typeof e == "object" && e !== null) switch (e.$$typeof) {
                case zs:
                    i = 10;
                    break e;
                case Ms:
                    i = 9;
                    break e;
                case di:
                    i = 11;
                    break e;
                case fi:
                    i = 14;
                    break e;
                case et:
                    i = 16, r = null;
                    break e
            }
            throw Error(S(130, e == null ? e : typeof e, ""))
    }
    return t = Ce(i, n, t, l), t.elementType = e, t.type = r, t.lanes = o, t
}

function Pt(e, t, n, r) {
    return e = Ce(7, e, r, t), e.lanes = n, e
}

function El(e, t, n, r) {
    return e = Ce(22, e, r, t), e.elementType = Is, e.lanes = n, e.stateNode = {
        isHidden: !1
    }, e
}

function oo(e, t, n) {
    return e = Ce(6, e, null, t), e.lanes = n, e
}

function io(e, t, n) {
    return t = Ce(4, e.children !== null ? e.children : [], e.key, t), t.lanes = n, t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation
    }, t
}

function Ep(e, t, n, r, l) {
    this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = $l(0), this.expirationTimes = $l(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = $l(0), this.identifierPrefix = r, this.onRecoverableError = l, this.mutableSourceEagerHydrationData = null
}

function Yi(e, t, n, r, l, o, i, u, s) {
    return e = new Ep(e, t, n, u, s), t === 1 ? (t = 1, o === !0 && (t |= 8)) : t = 0, o = Ce(3, null, null, t), e.current = o, o.stateNode = e, o.memoizedState = {
        element: r,
        isDehydrated: n,
        cache: null,
        transitions: null,
        pendingSuspenseBoundaries: null
    }, Ri(o), e
}

function Np(e, t, n) {
    var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
        $$typeof: Ut,
        key: r == null ? null : "" + r,
        children: e,
        containerInfo: t,
        implementation: n
    }
}

function jc(e) {
    if (!e) return vt;
    e = e._reactInternals;
    e: {
        if (Ft(e) !== e || e.tag !== 1) throw Error(S(170));
        var t = e;do {
            switch (t.tag) {
                case 3:
                    t = t.stateNode.context;
                    break e;
                case 1:
                    if (me(t.type)) {
                        t = t.stateNode.__reactInternalMemoizedMergedChildContext;
                        break e
                    }
            }
            t = t.return
        } while (t !== null);
        throw Error(S(171))
    }
    if (e.tag === 1) {
        var n = e.type;
        if (me(n)) return ja(e, n, t)
    }
    return t
}

function _c(e, t, n, r, l, o, i, u, s) {
    return e = Yi(n, r, !0, e, l, o, i, u, s), e.context = jc(null), n = e.current, r = ae(), l = pt(n), o = Ke(r, l), o.callback = t ? ? null, dt(n, o, l), e.current.lanes = l, lr(e, l, r), ve(e, r), e
}

function Nl(e, t, n, r) {
    var l = t.current,
        o = ae(),
        i = pt(l);
    return n = jc(n), t.context === null ? t.context = n : t.pendingContext = n, t = Ke(o, i), t.payload = {
        element: e
    }, r = r === void 0 ? null : r, r !== null && (t.callback = r), e = dt(l, t, i), e !== null && (Ie(e, l, i, o), zr(e, l, i)), i
}

function cl(e) {
    if (e = e.current, !e.child) return null;
    switch (e.child.tag) {
        case 5:
            return e.child.stateNode;
        default:
            return e.child.stateNode
    }
}

function us(e, t) {
    if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
        var n = e.retryLane;
        e.retryLane = n !== 0 && n < t ? n : t
    }
}

function Gi(e, t) {
    us(e, t), (e = e.alternate) && us(e, t)
}

function Cp() {
    return null
}
var Pc = typeof reportError == "function" ? reportError : function(e) {
    console.error(e)
};

function Xi(e) {
    this._internalRoot = e
}
Cl.prototype.render = Xi.prototype.render = function(e) {
    var t = this._internalRoot;
    if (t === null) throw Error(S(409));
    Nl(e, t, null, null)
};
Cl.prototype.unmount = Xi.prototype.unmount = function() {
    var e = this._internalRoot;
    if (e !== null) {
        this._internalRoot = null;
        var t = e.containerInfo;
        Mt(function() {
            Nl(null, e, null, null)
        }), t[Ge] = null
    }
};

function Cl(e) {
    this._internalRoot = e
}
Cl.prototype.unstable_scheduleHydration = function(e) {
    if (e) {
        var t = oa();
        e = {
            blockedOn: null,
            target: e,
            priority: t
        };
        for (var n = 0; n < nt.length && t !== 0 && t < nt[n].priority; n++);
        nt.splice(n, 0, e), n === 0 && ua(e)
    }
};

function Zi(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11)
}

function jl(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11 && (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
}

function ss() {}

function jp(e, t, n, r, l) {
    if (l) {
        if (typeof r == "function") {
            var o = r;
            r = function() {
                var a = cl(i);
                o.call(a)
            }
        }
        var i = _c(t, r, e, 0, null, !1, !1, "", ss);
        return e._reactRootContainer = i, e[Ge] = i.current, Kn(e.nodeType === 8 ? e.parentNode : e), Mt(), i
    }
    for (; l = e.lastChild;) e.removeChild(l);
    if (typeof r == "function") {
        var u = r;
        r = function() {
            var a = cl(s);
            u.call(a)
        }
    }
    var s = Yi(e, 0, !1, null, null, !1, !1, "", ss);
    return e._reactRootContainer = s, e[Ge] = s.current, Kn(e.nodeType === 8 ? e.parentNode : e), Mt(function() {
        Nl(t, s, n, r)
    }), s
}

function _l(e, t, n, r, l) {
    var o = n._reactRootContainer;
    if (o) {
        var i = o;
        if (typeof l == "function") {
            var u = l;
            l = function() {
                var s = cl(i);
                u.call(s)
            }
        }
        Nl(t, i, e, l)
    } else i = jp(n, t, e, l, r);
    return cl(i)
}
ra = function(e) {
    switch (e.tag) {
        case 3:
            var t = e.stateNode;
            if (t.current.memoizedState.isDehydrated) {
                var n = _n(t.pendingLanes);
                n !== 0 && (mi(t, n | 1), ve(t, K()), !(M & 6) && (an = K() + 500, xt()))
            }
            break;
        case 13:
            Mt(function() {
                var r = Xe(e, 1);
                if (r !== null) {
                    var l = ae();
                    Ie(r, e, 1, l)
                }
            }), Gi(e, 1)
    }
};
vi = function(e) {
    if (e.tag === 13) {
        var t = Xe(e, 134217728);
        if (t !== null) {
            var n = ae();
            Ie(t, e, 134217728, n)
        }
        Gi(e, 134217728)
    }
};
la = function(e) {
    if (e.tag === 13) {
        var t = pt(e),
            n = Xe(e, t);
        if (n !== null) {
            var r = ae();
            Ie(n, e, t, r)
        }
        Gi(e, t)
    }
};
oa = function() {
    return I
};
ia = function(e, t) {
    var n = I;
    try {
        return I = e, t()
    } finally {
        I = n
    }
};
ko = function(e, t, n) {
    switch (t) {
        case "input":
            if (mo(e, n), t = n.name, n.type === "radio" && t != null) {
                for (n = e; n.parentNode;) n = n.parentNode;
                for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < n.length; t++) {
                    var r = n[t];
                    if (r !== e && r.form === e.form) {
                        var l = gl(r);
                        if (!l) throw Error(S(90));
                        Ds(r), mo(r, l)
                    }
                }
            }
            break;
        case "textarea":
            As(e, n);
            break;
        case "select":
            t = n.value, t != null && Zt(e, !!n.multiple, t, !1)
    }
};
Ks = Hi;
Ys = Mt;
var _p = {
        usingClientEntryPoint: !1,
        Events: [ir, Ht, gl, Ws, Qs, Hi]
    },
    Nn = {
        findFiberByHostInstance: Nt,
        bundleType: 0,
        version: "18.3.1",
        rendererPackageName: "react-dom"
    },
    Pp = {
        bundleType: Nn.bundleType,
        version: Nn.version,
        rendererPackageName: Nn.rendererPackageName,
        rendererConfig: Nn.rendererConfig,
        overrideHookState: null,
        overrideHookStateDeletePath: null,
        overrideHookStateRenamePath: null,
        overrideProps: null,
        overridePropsDeletePath: null,
        overridePropsRenamePath: null,
        setErrorHandler: null,
        setSuspenseHandler: null,
        scheduleUpdate: null,
        currentDispatcherRef: qe.ReactCurrentDispatcher,
        findHostInstanceByFiber: function(e) {
            return e = Zs(e), e === null ? null : e.stateNode
        },
        findFiberByHostInstance: Nn.findFiberByHostInstance || Cp,
        findHostInstancesForRefresh: null,
        scheduleRefresh: null,
        scheduleRoot: null,
        setRefreshHandler: null,
        getCurrentFiber: null,
        reconcilerVersion: "18.3.1-next-f1338f8080-20240426"
    };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var _r = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!_r.isDisabled && _r.supportsFiber) try {
        pl = _r.inject(Pp), $e = _r
    } catch {}
}
Se.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = _p;
Se.createPortal = function(e, t) {
    var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!Zi(t)) throw Error(S(200));
    return Np(e, t, null, n)
};
Se.createRoot = function(e, t) {
    if (!Zi(e)) throw Error(S(299));
    var n = !1,
        r = "",
        l = Pc;
    return t != null && (t.unstable_strictMode === !0 && (n = !0), t.identifierPrefix !== void 0 && (r = t.identifierPrefix), t.onRecoverableError !== void 0 && (l = t.onRecoverableError)), t = Yi(e, 1, !1, null, null, n, !1, r, l), e[Ge] = t.current, Kn(e.nodeType === 8 ? e.parentNode : e), new Xi(t)
};
Se.findDOMNode = function(e) {
    if (e == null) return null;
    if (e.nodeType === 1) return e;
    var t = e._reactInternals;
    if (t === void 0) throw typeof e.render == "function" ? Error(S(188)) : (e = Object.keys(e).join(","), Error(S(268, e)));
    return e = Zs(t), e = e === null ? null : e.stateNode, e
};
Se.flushSync = function(e) {
    return Mt(e)
};
Se.hydrate = function(e, t, n) {
    if (!jl(t)) throw Error(S(200));
    return _l(null, e, t, !0, n)
};
Se.hydrateRoot = function(e, t, n) {
    if (!Zi(e)) throw Error(S(405));
    var r = n != null && n.hydratedSources || null,
        l = !1,
        o = "",
        i = Pc;
    if (n != null && (n.unstable_strictMode === !0 && (l = !0), n.identifierPrefix !== void 0 && (o = n.identifierPrefix), n.onRecoverableError !== void 0 && (i = n.onRecoverableError)), t = _c(t, null, e, 1, n ? ? null, l, !1, o, i), e[Ge] = t.current, Kn(e), r)
        for (e = 0; e < r.length; e++) n = r[e], l = n._getVersion, l = l(n._source), t.mutableSourceEagerHydrationData == null ? t.mutableSourceEagerHydrationData = [n, l] : t.mutableSourceEagerHydrationData.push(n, l);
    return new Cl(t)
};
Se.render = function(e, t, n) {
    if (!jl(t)) throw Error(S(200));
    return _l(null, e, t, !1, n)
};
Se.unmountComponentAtNode = function(e) {
    if (!jl(e)) throw Error(S(40));
    return e._reactRootContainer ? (Mt(function() {
        _l(null, null, e, !1, function() {
            e._reactRootContainer = null, e[Ge] = null
        })
    }), !0) : !1
};
Se.unstable_batchedUpdates = Hi;
Se.unstable_renderSubtreeIntoContainer = function(e, t, n, r) {
    if (!jl(n)) throw Error(S(200));
    if (e == null || e._reactInternals === void 0) throw Error(S(38));
    return _l(e, t, n, !1, r)
};
Se.version = "18.3.1-next-f1338f8080-20240426";

function Tc() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Tc)
    } catch (e) {
        console.error(e)
    }
}
Tc(), Ts.exports = Se;
var Tp = Ts.exports,
    Rc, as = Tp;
Rc = as.createRoot, as.hydrateRoot;
/**
 * @remix-run/router v1.23.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function tr() {
    return tr = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, tr.apply(this, arguments)
}
var it;
(function(e) {
    e.Pop = "POP", e.Push = "PUSH", e.Replace = "REPLACE"
})(it || (it = {}));
const cs = "popstate";

function Rp(e) {
    e === void 0 && (e = {});

    function t(r, l) {
        let {
            pathname: o,
            search: i,
            hash: u
        } = r.location;
        return ti("", {
            pathname: o,
            search: i,
            hash: u
        }, l.state && l.state.usr || null, l.state && l.state.key || "default")
    }

    function n(r, l) {
        return typeof l == "string" ? l : Oc(l)
    }
    return Op(t, n, null, e)
}

function Z(e, t) {
    if (e === !1 || e === null || typeof e > "u") throw new Error(t)
}

function Lc(e, t) {
    if (!e) {
        typeof console < "u" && console.warn(t);
        try {
            throw new Error(t)
        } catch {}
    }
}

function Lp() {
    return Math.random().toString(36).substr(2, 8)
}

function ds(e, t) {
    return {
        usr: e.state,
        key: e.key,
        idx: t
    }
}

function ti(e, t, n, r) {
    return n === void 0 && (n = null), tr({
        pathname: typeof e == "string" ? e : e.pathname,
        search: "",
        hash: ""
    }, typeof t == "string" ? pn(t) : t, {
        state: n,
        key: t && t.key || r || Lp()
    })
}

function Oc(e) {
    let {
        pathname: t = "/",
        search: n = "",
        hash: r = ""
    } = e;
    return n && n !== "?" && (t += n.charAt(0) === "?" ? n : "?" + n), r && r !== "#" && (t += r.charAt(0) === "#" ? r : "#" + r), t
}

function pn(e) {
    let t = {};
    if (e) {
        let n = e.indexOf("#");
        n >= 0 && (t.hash = e.substr(n), e = e.substr(0, n));
        let r = e.indexOf("?");
        r >= 0 && (t.search = e.substr(r), e = e.substr(0, r)), e && (t.pathname = e)
    }
    return t
}

function Op(e, t, n, r) {
    r === void 0 && (r = {});
    let {
        window: l = document.defaultView,
        v5Compat: o = !1
    } = r, i = l.history, u = it.Pop, s = null, a = v();
    a == null && (a = 0, i.replaceState(tr({}, i.state, {
        idx: a
    }), ""));

    function v() {
        return (i.state || {
            idx: null
        }).idx
    }

    function p() {
        u = it.Pop;
        let P = v(),
            d = P == null ? null : P - a;
        a = P, s && s({
            action: u,
            location: w.location,
            delta: d
        })
    }

    function m(P, d) {
        u = it.Push;
        let c = ti(w.location, P, d);
        a = v() + 1;
        let h = ds(c, a),
            x = w.createHref(c);
        try {
            i.pushState(h, "", x)
        } catch (k) {
            if (k instanceof DOMException && k.name === "DataCloneError") throw k;
            l.location.assign(x)
        }
        o && s && s({
            action: u,
            location: w.location,
            delta: 1
        })
    }

    function y(P, d) {
        u = it.Replace;
        let c = ti(w.location, P, d);
        a = v();
        let h = ds(c, a),
            x = w.createHref(c);
        i.replaceState(h, "", x), o && s && s({
            action: u,
            location: w.location,
            delta: 0
        })
    }

    function g(P) {
        let d = l.location.origin !== "null" ? l.location.origin : l.location.href,
            c = typeof P == "string" ? P : Oc(P);
        return c = c.replace(/ $/, "%20"), Z(d, "No window.location.(origin|href) available to create URL for href: " + c), new URL(c, d)
    }
    let w = {
        get action() {
            return u
        },
        get location() {
            return e(l, i)
        },
        listen(P) {
            if (s) throw new Error("A history only accepts one active listener");
            return l.addEventListener(cs, p), s = P, () => {
                l.removeEventListener(cs, p), s = null
            }
        },
        createHref(P) {
            return t(l, P)
        },
        createURL: g,
        encodeLocation(P) {
            let d = g(P);
            return {
                pathname: d.pathname,
                search: d.search,
                hash: d.hash
            }
        },
        push: m,
        replace: y,
        go(P) {
            return i.go(P)
        }
    };
    return w
}
var fs;
(function(e) {
    e.data = "data", e.deferred = "deferred", e.redirect = "redirect", e.error = "error"
})(fs || (fs = {}));

function zp(e, t, n) {
    return n === void 0 && (n = "/"), Mp(e, t, n, !1)
}

function Mp(e, t, n, r) {
    let l = typeof t == "string" ? pn(t) : t,
        o = Ic(l.pathname || "/", n);
    if (o == null) return null;
    let i = zc(e);
    Ip(i);
    let u = null;
    for (let s = 0; u == null && s < i.length; ++s) {
        let a = Kp(o);
        u = Wp(i[s], a, r)
    }
    return u
}

function zc(e, t, n, r) {
    t === void 0 && (t = []), n === void 0 && (n = []), r === void 0 && (r = "");
    let l = (o, i, u) => {
        let s = {
            relativePath: u === void 0 ? o.path || "" : u,
            caseSensitive: o.caseSensitive === !0,
            childrenIndex: i,
            route: o
        };
        s.relativePath.startsWith("/") && (Z(s.relativePath.startsWith(r), 'Absolute route path "' + s.relativePath + '" nested under path ' + ('"' + r + '" is not valid. An absolute child route path ') + "must start with the combined path of all its parent routes."), s.relativePath = s.relativePath.slice(r.length));
        let a = Tt([r, s.relativePath]),
            v = n.concat(s);
        o.children && o.children.length > 0 && (Z(o.index !== !0, "Index routes must not have child routes. Please remove " + ('all child routes from route path "' + a + '".')), zc(o.children, t, v, a)), !(o.path == null && !o.index) && t.push({
            path: a,
            score: Vp(a, o.index),
            routesMeta: v
        })
    };
    return e.forEach((o, i) => {
        var u;
        if (o.path === "" || !((u = o.path) != null && u.includes("?"))) l(o, i);
        else
            for (let s of Mc(o.path)) l(o, i, s)
    }), t
}

function Mc(e) {
    let t = e.split("/");
    if (t.length === 0) return [];
    let [n, ...r] = t, l = n.endsWith("?"), o = n.replace(/\?$/, "");
    if (r.length === 0) return l ? [o, ""] : [o];
    let i = Mc(r.join("/")),
        u = [];
    return u.push(...i.map(s => s === "" ? o : [o, s].join("/"))), l && u.push(...i), u.map(s => e.startsWith("/") && s === "" ? "/" : s)
}

function Ip(e) {
    e.sort((t, n) => t.score !== n.score ? n.score - t.score : Hp(t.routesMeta.map(r => r.childrenIndex), n.routesMeta.map(r => r.childrenIndex)))
}
const Fp = /^:[\w-]+$/,
    Dp = 3,
    Up = 2,
    Ap = 1,
    $p = 10,
    Bp = -2,
    ps = e => e === "*";

function Vp(e, t) {
    let n = e.split("/"),
        r = n.length;
    return n.some(ps) && (r += Bp), t && (r += Up), n.filter(l => !ps(l)).reduce((l, o) => l + (Fp.test(o) ? Dp : o === "" ? Ap : $p), r)
}

function Hp(e, t) {
    return e.length === t.length && e.slice(0, -1).every((r, l) => r === t[l]) ? e[e.length - 1] - t[t.length - 1] : 0
}

function Wp(e, t, n) {
    let {
        routesMeta: r
    } = e, l = {}, o = "/", i = [];
    for (let u = 0; u < r.length; ++u) {
        let s = r[u],
            a = u === r.length - 1,
            v = o === "/" ? t : t.slice(o.length) || "/",
            p = hs({
                path: s.relativePath,
                caseSensitive: s.caseSensitive,
                end: a
            }, v),
            m = s.route;
        if (!p && a && n && !r[r.length - 1].route.index && (p = hs({
                path: s.relativePath,
                caseSensitive: s.caseSensitive,
                end: !1
            }, v)), !p) return null;
        Object.assign(l, p.params), i.push({
            params: l,
            pathname: Tt([o, p.pathname]),
            pathnameBase: Jp(Tt([o, p.pathnameBase])),
            route: m
        }), p.pathnameBase !== "/" && (o = Tt([o, p.pathnameBase]))
    }
    return i
}

function hs(e, t) {
    typeof e == "string" && (e = {
        path: e,
        caseSensitive: !1,
        end: !0
    });
    let [n, r] = Qp(e.path, e.caseSensitive, e.end), l = t.match(n);
    if (!l) return null;
    let o = l[0],
        i = o.replace(/(.)\/+$/, "$1"),
        u = l.slice(1);
    return {
        params: r.reduce((a, v, p) => {
            let {
                paramName: m,
                isOptional: y
            } = v;
            if (m === "*") {
                let w = u[p] || "";
                i = o.slice(0, o.length - w.length).replace(/(.)\/+$/, "$1")
            }
            const g = u[p];
            return y && !g ? a[m] = void 0 : a[m] = (g || "").replace(/%2F/g, "/"), a
        }, {}),
        pathname: o,
        pathnameBase: i,
        pattern: e
    }
}

function Qp(e, t, n) {
    t === void 0 && (t = !1), n === void 0 && (n = !0), Lc(e === "*" || !e.endsWith("*") || e.endsWith("/*"), 'Route path "' + e + '" will be treated as if it were ' + ('"' + e.replace(/\*$/, "/*") + '" because the `*` character must ') + "always follow a `/` in the pattern. To get rid of this warning, " + ('please change the route path to "' + e.replace(/\*$/, "/*") + '".'));
    let r = [],
        l = "^" + e.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(/\/:([\w-]+)(\?)?/g, (i, u, s) => (r.push({
            paramName: u,
            isOptional: s != null
        }), s ? "/?([^\\/]+)?" : "/([^\\/]+)"));
    return e.endsWith("*") ? (r.push({
        paramName: "*"
    }), l += e === "*" || e === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$") : n ? l += "\\/*$" : e !== "" && e !== "/" && (l += "(?:(?=\\/|$))"), [new RegExp(l, t ? void 0 : "i"), r]
}

function Kp(e) {
    try {
        return e.split("/").map(t => decodeURIComponent(t).replace(/\//g, "%2F")).join("/")
    } catch (t) {
        return Lc(!1, 'The URL path "' + e + '" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent ' + ("encoding (" + t + ").")), e
    }
}

function Ic(e, t) {
    if (t === "/") return e;
    if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
    let n = t.endsWith("/") ? t.length - 1 : t.length,
        r = e.charAt(n);
    return r && r !== "/" ? null : e.slice(n) || "/"
}

function Yp(e, t) {
    t === void 0 && (t = "/");
    let {
        pathname: n,
        search: r = "",
        hash: l = ""
    } = typeof e == "string" ? pn(e) : e;
    return {
        pathname: n ? n.startsWith("/") ? n : Gp(n, t) : t,
        search: bp(r),
        hash: eh(l)
    }
}

function Gp(e, t) {
    let n = t.replace(/\/+$/, "").split("/");
    return e.split("/").forEach(l => {
        l === ".." ? n.length > 1 && n.pop() : l !== "." && n.push(l)
    }), n.length > 1 ? n.join("/") : "/"
}

function uo(e, t, n, r) {
    return "Cannot include a '" + e + "' character in a manually specified " + ("`to." + t + "` field [" + JSON.stringify(r) + "].  Please separate it out to the ") + ("`to." + n + "` field. Alternatively you may provide the full path as ") + 'a string in <Link to="..."> and the router will parse it for you.'
}

function Xp(e) {
    return e.filter((t, n) => n === 0 || t.route.path && t.route.path.length > 0)
}

function Zp(e, t) {
    let n = Xp(e);
    return t ? n.map((r, l) => l === n.length - 1 ? r.pathname : r.pathnameBase) : n.map(r => r.pathnameBase)
}

function qp(e, t, n, r) {
    r === void 0 && (r = !1);
    let l;
    typeof e == "string" ? l = pn(e) : (l = tr({}, e), Z(!l.pathname || !l.pathname.includes("?"), uo("?", "pathname", "search", l)), Z(!l.pathname || !l.pathname.includes("#"), uo("#", "pathname", "hash", l)), Z(!l.search || !l.search.includes("#"), uo("#", "search", "hash", l)));
    let o = e === "" || l.pathname === "",
        i = o ? "/" : l.pathname,
        u;
    if (i == null) u = n;
    else {
        let p = t.length - 1;
        if (!r && i.startsWith("..")) {
            let m = i.split("/");
            for (; m[0] === "..";) m.shift(), p -= 1;
            l.pathname = m.join("/")
        }
        u = p >= 0 ? t[p] : "/"
    }
    let s = Yp(l, u),
        a = i && i !== "/" && i.endsWith("/"),
        v = (o || i === ".") && n.endsWith("/");
    return !s.pathname.endsWith("/") && (a || v) && (s.pathname += "/"), s
}
const Tt = e => e.join("/").replace(/\/\/+/g, "/"),
    Jp = e => e.replace(/\/+$/, "").replace(/^\/*/, "/"),
    bp = e => !e || e === "?" ? "" : e.startsWith("?") ? e : "?" + e,
    eh = e => !e || e === "#" ? "" : e.startsWith("#") ? e : "#" + e;

function th(e) {
    return e != null && typeof e.status == "number" && typeof e.statusText == "string" && typeof e.internal == "boolean" && "data" in e
}
const Fc = ["post", "put", "patch", "delete"];
new Set(Fc);
const nh = ["get", ...Fc];
new Set(nh);
/**
 * React Router v6.30.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function nr() {
    return nr = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, nr.apply(this, arguments)
}
const qi = N.createContext(null),
    rh = N.createContext(null),
    Pl = N.createContext(null),
    Tl = N.createContext(null),
    hn = N.createContext({
        outlet: null,
        matches: [],
        isDataRoute: !1
    }),
    Dc = N.createContext(null);

function Rl() {
    return N.useContext(Tl) != null
}

function Ji() {
    return Rl() || Z(!1), N.useContext(Tl).location
}

function Uc(e) {
    N.useContext(Pl).static || N.useLayoutEffect(e)
}

function Ll() {
    let {
        isDataRoute: e
    } = N.useContext(hn);
    return e ? vh() : lh()
}

function lh() {
    Rl() || Z(!1);
    let e = N.useContext(qi),
        {
            basename: t,
            future: n,
            navigator: r
        } = N.useContext(Pl),
        {
            matches: l
        } = N.useContext(hn),
        {
            pathname: o
        } = Ji(),
        i = JSON.stringify(Zp(l, n.v7_relativeSplatPath)),
        u = N.useRef(!1);
    return Uc(() => {
        u.current = !0
    }), N.useCallback(function(a, v) {
        if (v === void 0 && (v = {}), !u.current) return;
        if (typeof a == "number") {
            r.go(a);
            return
        }
        let p = qp(a, JSON.parse(i), o, v.relative === "path");
        e == null && t !== "/" && (p.pathname = p.pathname === "/" ? t : Tt([t, p.pathname])), (v.replace ? r.replace : r.push)(p, v.state, v)
    }, [t, r, i, o, e])
}

function oh(e, t) {
    return ih(e, t)
}

function ih(e, t, n, r) {
    Rl() || Z(!1);
    let {
        navigator: l,
        static: o
    } = N.useContext(Pl), {
        matches: i
    } = N.useContext(hn), u = i[i.length - 1], s = u ? u.params : {};
    u && u.pathname;
    let a = u ? u.pathnameBase : "/";
    u && u.route;
    let v = Ji(),
        p;
    if (t) {
        var m;
        let d = typeof t == "string" ? pn(t) : t;
        a === "/" || (m = d.pathname) != null && m.startsWith(a) || Z(!1), p = d
    } else p = v;
    let y = p.pathname || "/",
        g = y;
    if (a !== "/") {
        let d = a.replace(/^\//, "").split("/");
        g = "/" + y.replace(/^\//, "").split("/").slice(d.length).join("/")
    }
    let w = !o && n && n.matches && n.matches.length > 0 ? n.matches : zp(e, {
            pathname: g
        }),
        P = dh(w && w.map(d => Object.assign({}, d, {
            params: Object.assign({}, s, d.params),
            pathname: Tt([a, l.encodeLocation ? l.encodeLocation(d.pathname).pathname : d.pathname]),
            pathnameBase: d.pathnameBase === "/" ? a : Tt([a, l.encodeLocation ? l.encodeLocation(d.pathnameBase).pathname : d.pathnameBase])
        })), i, n, r);
    return t && P ? N.createElement(Tl.Provider, {
        value: {
            location: nr({
                pathname: "/",
                search: "",
                hash: "",
                state: null,
                key: "default"
            }, p),
            navigationType: it.Pop
        }
    }, P) : P
}

function uh() {
    let e = mh(),
        t = th(e) ? e.status + " " + e.statusText : e instanceof Error ? e.message : JSON.stringify(e),
        n = e instanceof Error ? e.stack : null,
        l = {
            padding: "0.5rem",
            backgroundColor: "rgba(200,200,200, 0.5)"
        };
    return N.createElement(N.Fragment, null, N.createElement("h2", null, "Unexpected Application Error!"), N.createElement("h3", {
        style: {
            fontStyle: "italic"
        }
    }, t), n ? N.createElement("pre", {
        style: l
    }, n) : null, null)
}
const sh = N.createElement(uh, null);
class ah extends N.Component {
    constructor(t) {
        super(t), this.state = {
            location: t.location,
            revalidation: t.revalidation,
            error: t.error
        }
    }
    static getDerivedStateFromError(t) {
        return {
            error: t
        }
    }
    static getDerivedStateFromProps(t, n) {
        return n.location !== t.location || n.revalidation !== "idle" && t.revalidation === "idle" ? {
            error: t.error,
            location: t.location,
            revalidation: t.revalidation
        } : {
            error: t.error !== void 0 ? t.error : n.error,
            location: n.location,
            revalidation: t.revalidation || n.revalidation
        }
    }
    componentDidCatch(t, n) {
        console.error("React Router caught the following error during render", t, n)
    }
    render() {
        return this.state.error !== void 0 ? N.createElement(hn.Provider, {
            value: this.props.routeContext
        }, N.createElement(Dc.Provider, {
            value: this.state.error,
            children: this.props.component
        })) : this.props.children
    }
}

function ch(e) {
    let {
        routeContext: t,
        match: n,
        children: r
    } = e, l = N.useContext(qi);
    return l && l.static && l.staticContext && (n.route.errorElement || n.route.ErrorBoundary) && (l.staticContext._deepestRenderedBoundaryId = n.route.id), N.createElement(hn.Provider, {
        value: t
    }, r)
}

function dh(e, t, n, r) {
    var l;
    if (t === void 0 && (t = []), n === void 0 && (n = null), r === void 0 && (r = null), e == null) {
        var o;
        if (!n) return null;
        if (n.errors) e = n.matches;
        else if ((o = r) != null && o.v7_partialHydration && t.length === 0 && !n.initialized && n.matches.length > 0) e = n.matches;
        else return null
    }
    let i = e,
        u = (l = n) == null ? void 0 : l.errors;
    if (u != null) {
        let v = i.findIndex(p => p.route.id && (u == null ? void 0 : u[p.route.id]) !== void 0);
        v >= 0 || Z(!1), i = i.slice(0, Math.min(i.length, v + 1))
    }
    let s = !1,
        a = -1;
    if (n && r && r.v7_partialHydration)
        for (let v = 0; v < i.length; v++) {
            let p = i[v];
            if ((p.route.HydrateFallback || p.route.hydrateFallbackElement) && (a = v), p.route.id) {
                let {
                    loaderData: m,
                    errors: y
                } = n, g = p.route.loader && m[p.route.id] === void 0 && (!y || y[p.route.id] === void 0);
                if (p.route.lazy || g) {
                    s = !0, a >= 0 ? i = i.slice(0, a + 1) : i = [i[0]];
                    break
                }
            }
        }
    return i.reduceRight((v, p, m) => {
        let y, g = !1,
            w = null,
            P = null;
        n && (y = u && p.route.id ? u[p.route.id] : void 0, w = p.route.errorElement || sh, s && (a < 0 && m === 0 ? (g = !0, P = null) : a === m && (g = !0, P = p.route.hydrateFallbackElement || null)));
        let d = t.concat(i.slice(0, m + 1)),
            c = () => {
                let h;
                return y ? h = w : g ? h = P : p.route.Component ? h = N.createElement(p.route.Component, null) : p.route.element ? h = p.route.element : h = v, N.createElement(ch, {
                    match: p,
                    routeContext: {
                        outlet: v,
                        matches: d,
                        isDataRoute: n != null
                    },
                    children: h
                })
            };
        return n && (p.route.ErrorBoundary || p.route.errorElement || m === 0) ? N.createElement(ah, {
            location: n.location,
            revalidation: n.revalidation,
            component: w,
            error: y,
            children: c(),
            routeContext: {
                outlet: null,
                matches: d,
                isDataRoute: !0
            }
        }) : c()
    }, null)
}
var Ac = function(e) {
        return e.UseBlocker = "useBlocker", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e
    }(Ac || {}),
    dl = function(e) {
        return e.UseBlocker = "useBlocker", e.UseLoaderData = "useLoaderData", e.UseActionData = "useActionData", e.UseRouteError = "useRouteError", e.UseNavigation = "useNavigation", e.UseRouteLoaderData = "useRouteLoaderData", e.UseMatches = "useMatches", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e.UseRouteId = "useRouteId", e
    }(dl || {});

function fh(e) {
    let t = N.useContext(qi);
    return t || Z(!1), t
}

function ph(e) {
    let t = N.useContext(rh);
    return t || Z(!1), t
}

function hh(e) {
    let t = N.useContext(hn);
    return t || Z(!1), t
}

function $c(e) {
    let t = hh(),
        n = t.matches[t.matches.length - 1];
    return n.route.id || Z(!1), n.route.id
}

function mh() {
    var e;
    let t = N.useContext(Dc),
        n = ph(dl.UseRouteError),
        r = $c(dl.UseRouteError);
    return t !== void 0 ? t : (e = n.errors) == null ? void 0 : e[r]
}

function vh() {
    let {
        router: e
    } = fh(Ac.UseNavigateStable), t = $c(dl.UseNavigateStable), n = N.useRef(!1);
    return Uc(() => {
        n.current = !0
    }), N.useCallback(function(l, o) {
        o === void 0 && (o = {}), n.current && (typeof l == "number" ? e.navigate(l) : e.navigate(l, nr({
            fromRouteId: t
        }, o)))
    }, [e, t])
}

function gh(e, t) {
    e == null || e.v7_startTransition, e == null || e.v7_relativeSplatPath
}

function $r(e) {
    Z(!1)
}

function yh(e) {
    let {
        basename: t = "/",
        children: n = null,
        location: r,
        navigationType: l = it.Pop,
        navigator: o,
        static: i = !1,
        future: u
    } = e;
    Rl() && Z(!1);
    let s = t.replace(/^\/*/, "/"),
        a = N.useMemo(() => ({
            basename: s,
            navigator: o,
            static: i,
            future: nr({
                v7_relativeSplatPath: !1
            }, u)
        }), [s, u, o, i]);
    typeof r == "string" && (r = pn(r));
    let {
        pathname: v = "/",
        search: p = "",
        hash: m = "",
        state: y = null,
        key: g = "default"
    } = r, w = N.useMemo(() => {
        let P = Ic(v, s);
        return P == null ? null : {
            location: {
                pathname: P,
                search: p,
                hash: m,
                state: y,
                key: g
            },
            navigationType: l
        }
    }, [s, v, p, m, y, g, l]);
    return w == null ? null : N.createElement(Pl.Provider, {
        value: a
    }, N.createElement(Tl.Provider, {
        children: n,
        value: w
    }))
}

function xh(e) {
    let {
        children: t,
        location: n
    } = e;
    return oh(ni(t), n)
}
new Promise(() => {});

function ni(e, t) {
    t === void 0 && (t = []);
    let n = [];
    return N.Children.forEach(e, (r, l) => {
        if (!N.isValidElement(r)) return;
        let o = [...t, l];
        if (r.type === N.Fragment) {
            n.push.apply(n, ni(r.props.children, o));
            return
        }
        r.type !== $r && Z(!1), !r.props.index || !r.props.children || Z(!1);
        let i = {
            id: r.props.id || o.join("-"),
            caseSensitive: r.props.caseSensitive,
            element: r.props.element,
            Component: r.props.Component,
            index: r.props.index,
            path: r.props.path,
            loader: r.props.loader,
            action: r.props.action,
            errorElement: r.props.errorElement,
            ErrorBoundary: r.props.ErrorBoundary,
            hasErrorBoundary: r.props.ErrorBoundary != null || r.props.errorElement != null,
            shouldRevalidate: r.props.shouldRevalidate,
            handle: r.props.handle,
            lazy: r.props.lazy
        };
        r.props.children && (i.children = ni(r.props.children, o)), n.push(i)
    }), n
}
/**
 * React Router DOM v6.30.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
const wh = "6";
try {
    window.__reactRouterVersion = wh
} catch {}
const Sh = "startTransition",
    ms = gd[Sh];

function kh(e) {
    let {
        basename: t,
        children: n,
        future: r,
        window: l
    } = e, o = N.useRef();
    o.current == null && (o.current = Rp({
        window: l,
        v5Compat: !0
    }));
    let i = o.current,
        [u, s] = N.useState({
            action: i.action,
            location: i.location
        }),
        {
            v7_startTransition: a
        } = r || {},
        v = N.useCallback(p => {
            a && ms ? ms(() => s(p)) : s(p)
        }, [s, a]);
    return N.useLayoutEffect(() => i.listen(v), [i, v]), N.useEffect(() => gh(r), [r]), N.createElement(yh, {
        basename: t,
        children: n,
        location: u.location,
        navigationType: u.action,
        navigator: i,
        future: r
    })
}
var vs;
(function(e) {
    e.UseScrollRestoration = "useScrollRestoration", e.UseSubmit = "useSubmit", e.UseSubmitFetcher = "useSubmitFetcher", e.UseFetcher = "useFetcher", e.useViewTransitionState = "useViewTransitionState"
})(vs || (vs = {}));
var gs;
(function(e) {
    e.UseFetcher = "useFetcher", e.UseFetchers = "useFetchers", e.UseScrollRestoration = "useScrollRestoration"
})(gs || (gs = {}));
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
var Eh = {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
};
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Nh = e => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase().trim(),
    Je = (e, t) => {
        const n = N.forwardRef(({
            color: r = "currentColor",
            size: l = 24,
            strokeWidth: o = 2,
            absoluteStrokeWidth: i,
            className: u = "",
            children: s,
            ...a
        }, v) => N.createElement("svg", {
            ref: v,
            ...Eh,
            width: l,
            height: l,
            stroke: r,
            strokeWidth: i ? Number(o) * 24 / Number(l) : o,
            className: ["lucide", `lucide-${Nh(e)}`, u].join(" "),
            ...a
        }, [...t.map(([p, m]) => N.createElement(p, m)), ...Array.isArray(s) ? s : [s]]));
        return n.displayName = `${e}`, n
    };
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ch = Je("Building2", [
    ["path", {
        d: "M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z",
        key: "1b4qmf"
    }],
    ["path", {
        d: "M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2",
        key: "i71pzd"
    }],
    ["path", {
        d: "M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2",
        key: "10jefs"
    }],
    ["path", {
        d: "M10 6h4",
        key: "1itunk"
    }],
    ["path", {
        d: "M10 10h4",
        key: "tcdvrf"
    }],
    ["path", {
        d: "M10 14h4",
        key: "kelpxr"
    }],
    ["path", {
        d: "M10 18h4",
        key: "1ulq68"
    }]
]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Bc = Je("ChevronDown", [
    ["path", {
        d: "m6 9 6 6 6-6",
        key: "qrunsl"
    }]
]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const jh = Je("CircleUser", [
    ["circle", {
        cx: "12",
        cy: "12",
        r: "10",
        key: "1mglay"
    }],
    ["circle", {
        cx: "12",
        cy: "10",
        r: "3",
        key: "ilqhr7"
    }],
    ["path", {
        d: "M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662",
        key: "154egf"
    }]
]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const _h = Je("Facebook", [
    ["path", {
        d: "M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z",
        key: "1jg4f8"
    }]
]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ph = Je("Home", [
    ["path", {
        d: "m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
        key: "y5dka4"
    }],
    ["polyline", {
        points: "9 22 9 12 15 12 15 22",
        key: "e2us08"
    }]
]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Th = Je("Instagram", [
    ["rect", {
        width: "20",
        height: "20",
        x: "2",
        y: "2",
        rx: "5",
        ry: "5",
        key: "2e1cvw"
    }],
    ["path", {
        d: "M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z",
        key: "9exkf1"
    }],
    ["line", {
        x1: "17.5",
        x2: "17.51",
        y1: "6.5",
        y2: "6.5",
        key: "r4j83e"
    }]
]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Rh = Je("Search", [
    ["circle", {
        cx: "11",
        cy: "11",
        r: "8",
        key: "4ej97u"
    }],
    ["path", {
        d: "m21 21-4.3-4.3",
        key: "1qie3q"
    }]
]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Lh = Je("Wind", [
    ["path", {
        d: "M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2",
        key: "1k4u03"
    }],
    ["path", {
        d: "M9.6 4.6A2 2 0 1 1 11 8H2",
        key: "b7d0fd"
    }],
    ["path", {
        d: "M12.6 19.4A2 2 0 1 0 14 16H2",
        key: "1p5cb3"
    }]
]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Oh = Je("Zap", [
    ["polygon", {
        points: "13 2 3 14 12 14 11 22 21 10 12 10 13 2",
        key: "45s27k"
    }]
]);

function zh() {
    const e = () => {
        window.scrollBy({
            top: window.innerHeight * .8,
            behavior: "smooth"
        })
    };
    return f.jsx("div", {
        className: "relative",
        children: f.jsxs("div", {
            className: "relative min-h-screen flex items-center",
            style: {
                backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url("https://th.bing.com/th/id/OIP.1UBoZ81or7aOst1c6TFHwAHaE7?w=240&h=180&c=7&r=0&o=5&dpr=1.1&pid=1.7")',
                backgroundSize: "cover",
                backgroundPosition: "center"
            },
            children: [f.jsx("div", {
                className: "max-w-7xl mx-auto px-6 py-24",
                children: f.jsxs("div", {
                    className: "max-w-3xl",
                    children: [f.jsxs("h1", {
                        className: "text-6xl font-bold mb-6",
                        children: ["YOUR HOME IS", f.jsx("div", {
                            className: "text-orange-500 mt-2",
                            children: "A SILENT POLLUTER"
                        })]
                    }), f.jsxs("div", {
                        className: "mb-8",
                        children: [f.jsxs("p", {
                            className: "text-xl text-orange-500 font-semibold mb-4",
                            children: ["Did you know? In 2020, buildings accounted for 39% of global CO", f.jsx("sub", {
                                children: "2"
                            }), " emissions, making homes a major contributor to pollution."]
                        }), f.jsx("p", {
                            className: "text-lg text-gray-300 mb-6",
                            children: "For years, traditional homes have consumed excessive energy, allowed pollution inside, and struggled to stay cool naturally. The result? Rising electricity bills, poor indoor air quality, and increased environmental harm."
                        }), f.jsxs("button", {
                            onClick: e,
                            className: "flex items-center space-x-3 bg-white text-black px-8 py-4 rounded-full hover:bg-orange-500 hover:text-white transition-all transform hover:scale-105",
                            children: [f.jsx(Bc, {
                                className: "h-6 w-6 animate-bounce"
                            }), f.jsx("span", {
                                className: "font-bold text-lg",
                                children: "SEE THE SOLUTION"
                            })]
                        })]
                    })]
                })
            }), f.jsx("div", {
                className: "absolute bottom-0 w-full py-6 bg-black/50 backdrop-blur-sm",
                children: f.jsx("p", {
                    className: "text-center text-lg",
                    children: "With HOMIE, small changes at your home create a big impact on our planet."
                })
            })]
        })
    })
}

function Mh() {
    const e = N.useRef(null),
        t = () => {
            e.current && e.current.scrollIntoView({
                behavior: "smooth"
            })
        },
        n = [{
            title: "Sandstone Eco-Home",
            image: "https://res.cloudinary.com/dphudihil/image/upload/v1743672036/Sandstone_ae473m.jpg",
            why: "Traditional materials often trap heat, raising cooling costs and energy consumption.",
            how: "Sandstone acts as a natural insulator, reducing energy consumption. Our design integrates floor cooling to convert footsteps into energy, enhancing sustainability."
        }, {
            title: "Green Roof Insulation",
            image: "https://res.cloudinary.com/dphudihil/image/upload/v1743671993/WhatsApp_Image_2025-03-29_at_01.33.13_ae1e5da3_tl4c0l.jpg",
            why: "Natural roof gardens help reduce heat absorption, lowering air conditioning costs, and improving air quality.",
            how: "Combines solar panels & vegetation for energy efficiency, with a sloped design for better rainwater drainage and durability."
        }, {
            title: "Smart Ventilation System",
            image: "https://res.cloudinary.com/dphudihil/image/upload/v1743672071/Smart_ventilation_system_zqkrcy.jpg",
            why: "Poor ventilation leads to indoor pollution and energy waste.",
            how: "Our system includes automated airflow purifier and balances temperature while enhancing air circulation efficiently."
        }];
    return f.jsxs("div", {
        className: "min-h-screen bg-white",
        children: [f.jsx("div", {
            className: "pt-24 pb-16 bg-black text-white",
            children: f.jsx("div", {
                className: "max-w-7xl mx-auto px-6",
                children: f.jsxs("div", {
                    className: "max-w-3xl",
                    children: [f.jsxs("div", {
                        className: "flex items-center space-x-4 mb-6",
                        children: [f.jsx("div", {
                            className: "w-1 h-16 bg-orange-500"
                        }), f.jsxs("h1", {
                            className: "text-5xl font-bold",
                            children: ["EXPLORE OUR SMART", f.jsx("br", {}), "HOME SOLUTIONS", f.jsx("br", {}), f.jsx("span", {
                                className: "text-orange-500",
                                children: "THAT WE OFFER!"
                            })]
                        })]
                    }), f.jsxs("p", {
                        className: "text-xl mb-8",
                        children: ["At Homie, we integrate ", f.jsx("span", {
                            className: "text-orange-500",
                            children: "Eco-Friendly Solutions and Technologies"
                        }), " into ", f.jsx("span", {
                            className: "text-orange-500",
                            children: "Modern Smart Home"
                        }), " designs. Our innovations focus on:"]
                    }), f.jsxs("div", {
                        className: "grid gap-6 mb-8",
                        children: [f.jsxs("div", {
                            className: "flex items-center space-x-4",
                            children: [f.jsx(Oh, {
                                className: "h-8 w-8 text-orange-500"
                            }), f.jsx("span", {
                                className: "text-lg",
                                children: "Renewable energy for efficient power use."
                            })]
                        }), f.jsxs("div", {
                            className: "flex items-center space-x-4",
                            children: [f.jsx(Lh, {
                                className: "h-8 w-8 text-orange-500"
                            }), f.jsx("span", {
                                className: "text-lg",
                                children: "Air purification to improve indoor air quality."
                            })]
                        }), f.jsxs("div", {
                            className: "flex items-center space-x-4",
                            children: [f.jsx(Ch, {
                                className: "h-8 w-8 text-orange-500"
                            }), f.jsx("span", {
                                className: "text-lg",
                                children: "Sustainable building materials like sandstone for insulation and carbon-free construction."
                            })]
                        })]
                    }), f.jsx("p", {
                        className: "text-xl font-semibold mb-8",
                        children: "Sustainability Starts from your Home: Transform Your Home, Transform the Planet!"
                    })]
                })
            })
        }), f.jsxs("div", {
            className: "max-w-7xl mx-auto px-6 py-16",
            children: [f.jsx("div", {
                className: "grid md:grid-cols-3 gap-8",
                children: n.map((r, l) => f.jsxs("div", {
                    className: "bg-white rounded-xl shadow-xl overflow-hidden transform hover:scale-105 transition-transform duration-300",
                    children: [f.jsx("img", {
                        src: r.image,
                        alt: r.title,
                        className: "w-full h-48 object-cover"
                    }), f.jsxs("div", {
                        className: "p-6",
                        children: [f.jsx("h3", {
                            className: "text-2xl font-bold mb-4",
                            children: r.title
                        }), f.jsxs("div", {
                            className: "mb-4",
                            children: [f.jsx("p", {
                                className: "font-semibold text-orange-500",
                                children: "Why?"
                            }), f.jsx("p", {
                                className: "text-gray-600",
                                children: r.why
                            })]
                        }), f.jsxs("div", {
                            children: [f.jsx("p", {
                                className: "font-semibold text-orange-500",
                                children: "How?"
                            }), f.jsx("p", {
                                className: "text-gray-600",
                                children: r.how
                            })]
                        })]
                    })]
                }, l))
            }), f.jsx("div", {
                className: "mt-12 text-center",
                children: f.jsxs("button", {
                    onClick: t,
                    className: "inline-flex items-center space-x-3 bg-orange-500 text-white px-8 py-4 rounded-full hover:bg-orange-600 transition-all transform hover:scale-105",
                    children: [f.jsx(Bc, {
                        className: "h-6 w-6 animate-bounce"
                    }), f.jsx("span", {
                        className: "font-bold text-lg",
                        children: "SEE THE PRODUCTS"
                    })]
                })
            })]
        }), f.jsx("div", {
            ref: e
        })]
    })
}

function Ih() {
    const e = Ll(),
        t = [{
            title: "SMART SOLAR PANEL SYSTEM",
            image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?auto=format&fit=crop&q=80",
            description: "Our solar panel automatically adjusts its position to follow the sun's movement, maximizing energy absorption and improving power efficiency for sustainable homes, overcoming the inefficiency of fixed panels as sunlight angles change throughout the day.",
            price: "60000 EGP"
        }, {
            title: "SMART AIR PURIFYING SYSTEM",
            image: "https://res.cloudinary.com/dphudihil/image/upload/v1743672180/Smart_air_purifying_sytem_mof84p.jpg",
            description: "Our air purifier automatically adjusts airflow based on real-time conditions, improving air quality and balancing temperature for a healthier indoor place, overcoming the inefficiency of traditional ventilation systems that fail to adapt to changing air conditions.",
            price: "20000 EGP"
        }, {
            title: "SMART TRIBOELECTRIC GENERATOR FLOOR",
            image: "https://res.cloudinary.com/dphudihil/image/upload/v1743672267/Smart_tiles_luc4yr.jpg",
            description: "Our flooring tiles convert footsteps into electricity based on triboelectric effect, harnessing movement energy to power homes, overcoming the inefficiency of traditional floors that waste potential energy from daily activity.",
            price: "10000 EGP"
        }];
    return f.jsx("div", {
        className: "min-h-screen bg-white pt-32",
        children: f.jsxs("div", {
            className: "max-w-7xl mx-auto px-6 pb-16",
            children: [f.jsx("h1", {
                className: "text-6xl font-bold text-black mb-12",
                children: "OUR PRODUCTS"
            }), f.jsx("div", {
                className: "grid md:grid-cols-3 gap-8",
                children: t.map((n, r) => f.jsxs("div", {
                    className: "flex flex-col border-2 border-orange-500",
                    children: [f.jsx("div", {
                        className: "h-64 relative",
                        children: f.jsx("img", {
                            src: n.image,
                            alt: n.title,
                            className: "w-full h-full object-cover"
                        })
                    }), f.jsxs("div", {
                        className: "flex-1 p-6 bg-white",
                        children: [f.jsx("h3", {
                            className: "text-2xl font-bold text-blue-900 mb-4 text-center",
                            children: n.title
                        }), f.jsx("p", {
                            className: "text-gray-600 mb-6 text-center",
                            children: n.description
                        }), f.jsx("div", {
                            className: "mt-auto",
                            children: f.jsx("button", {
                                onClick: () => e("/contact"),
                                className: "w-full text-3xl font-bold text-center bg-orange-500 text-white py-4 hover:bg-orange-600 transition-all",
                                children: n.price
                            })
                        })]
                    })]
                }, r))
            })]
        })
    })
}

function Fh() {
    const e = [{
        name: "Mohamed Alaa",
        role: "CEO",
        image: "https://res.cloudinary.com/dphudihil/image/upload/v1743671726/Eldeesinger_beta3na_rng5ou.jpg"
    }, {
        name: "Ahmed Nasr",
        role: "CEO",
        image: "https://res.cloudinary.com/dphudihil/image/upload/v1743671428/Ahmed_Ashraf_jjtpx5.jpg"
    }, {
        name: "Ali Eldeen Sameh",
        role: "CEO",
        image: "https://res.cloudinary.com/dphudihil/image/upload/v1743671428/Ali_Eldien_jrkgsr.jpg"
    }, {
        name: "Ali Yousef",
        role: "CTO",
        image: "https://res.cloudinary.com/dphudihil/image/upload/v1743671772/Me_fnyif6.jpg"
    }, {
        name: "Ziad Samir",
        role: "CTO",
        image: "https://res.cloudinary.com/dphudihil/image/upload/v1743671857/Ziad_samir_hr4tee.jpg"
    }, {
        name: "Ahmed Ashraf",
        role: "CMO",
        image: "https://res.cloudinary.com/dphudihil/image/upload/v1743671429/Ahmed_Asherf_gr7fz0.jpg"
    }, {
        name: "Omar Azab",
        role: "CMO",
        image: "https://res.cloudinary.com/dphudihil/image/upload/v1743671810/Omar_azab_ghhcyu.jpg"
    }, {
        name: "Abdullah Aboalam",
        role: "CFO",
        image: "https://res.cloudinary.com/dphudihil/image/upload/v1743671683/Abdallah_aboalam_wh01xn.jpg"
    }, {
        name: "Omar Gaballah",
        role: "CFO",
        image: "https://images.unsplash.com/photo-1595152452543-e5fc28ebc2b8?auto=format&fit=crop&q=80"
    }, {
        name: "Ahmed Barakat",
        role: "COO",
        image: "https://images.unsplash.com/photo-1608681299041-cc19878f79f1?auto=format&fit=crop&q=80"
    }, {
        name: "Ahmed Dawod",
        role: "COO",
        image: "https://res.cloudinary.com/dphudihil/image/upload/v1743671428/Ahmed_Dawood_hn1hk1.jpg"
    }];
    return f.jsx("div", {
        className: "min-h-screen bg-white pt-24",
        children: f.jsxs("div", {
            className: "max-w-7xl mx-auto px-6 py-16",
            children: [f.jsxs("div", {
                className: "text-center mb-16",
                children: [f.jsx("h1", {
                    className: "text-6xl font-bold text-black mb-6",
                    children: "Meet The Team!"
                }), f.jsx("p", {
                    className: "text-xl text-gray-600 max-w-4xl mx-auto",
                    children: "We are 11 students from El-Sadat STEM School in Egypt, passionate about innovation and sustainability. Our mission is to design eco-friendly solutions that redefine smart living."
                })]
            }), f.jsx("div", {
                className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8",
                children: e.map((t, n) => f.jsxs("div", {
                    className: `${n<6,"lg:col-span-1"} flex flex-col items-center`,
                    children: [f.jsx("div", {
                        className: "w-40 h-40 rounded-full overflow-hidden mb-4 transform hover:scale-105 transition-transform duration-300",
                        children: f.jsx("img", {
                            src: t.image,
                            alt: t.name,
                            className: "w-full h-full object-cover"
                        })
                    }), f.jsx("h3", {
                        className: "text-lg font-semibold text-gray-900 text-center",
                        children: t.name
                    }), f.jsxs("p", {
                        className: "text-orange-500 font-medium text-center",
                        children: ["(", t.role, ")"]
                    })]
                }, n))
            })]
        })
    })
}

function Vc() {
    const e = Ll(),
        [t, n] = N.useState({
            name: "",
            address: "",
            phone: "",
            email: ""
        }),
        r = o => {
            o.preventDefault(), e("/order", {
                state: {
                    userInfo: t
                }
            })
        },
        l = o => {
            n({ ...t,
                [o.target.name]: o.target.value
            })
        };
    return f.jsx("div", {
        className: "min-h-screen bg-white pt-24",
        children: f.jsx("div", {
            className: "max-w-7xl mx-auto px-6 py-16",
            children: f.jsxs("div", {
                className: "grid md:grid-cols-2 gap-8",
                children: [f.jsxs("div", {
                    className: "space-y-8",
                    children: [f.jsxs("div", {
                        children: [f.jsxs("h1", {
                            className: "text-7xl font-bold text-black",
                            children: ["CONTACT ", f.jsx("span", {
                                className: "text-orange-500",
                                children: "US"
                            })]
                        }), f.jsx("h2", {
                            className: "text-4xl font-light mt-4 text-black",
                            children: "Get in Touch!"
                        })]
                    }), f.jsx("p", {
                        className: "text-xl text-black",
                        children: "Interested in our project or have any questions? Feel free to reach out!"
                    }), f.jsxs("div", {
                        className: "space-y-6",
                        children: [f.jsxs("div", {
                            children: [f.jsx("h3", {
                                className: "text-2xl font-bold text-black",
                                children: "Email:"
                            }), f.jsx("p", {
                                className: "text-xl text-black",
                                children: "mohamed.2523062@stemelsadat.moe.edu.eg"
                            })]
                        }), f.jsxs("div", {
                            children: [f.jsx("h3", {
                                className: "text-2xl font-bold text-black",
                                children: "Phone:"
                            }), f.jsx("p", {
                                className: "text-xl text-black",
                                children: "+20 127 355 9241"
                            })]
                        }), f.jsxs("div", {
                            children: [f.jsx("h3", {
                                className: "text-2xl font-bold text-black",
                                children: "Location:"
                            }), f.jsx("p", {
                                className: "text-xl text-black",
                                children: "El-Sadat STEM School, Egypt"
                            })]
                        }), f.jsxs("div", {
                            children: [f.jsx("h3", {
                                className: "text-2xl font-bold text-black",
                                children: "Store hours:"
                            }), f.jsxs("p", {
                                className: "text-xl text-black",
                                children: ["10:00 AM to 9:00 PM daily", f.jsx("br", {}), "(except on public holidays)"]
                            })]
                        })]
                    }), f.jsxs("div", {
                        className: "pt-4 border-t border-gray-200",
                        children: [f.jsx("h3", {
                            className: "text-3xl font-bold mb-4 text-black",
                            children: "Get social"
                        }), f.jsxs("div", {
                            className: "flex space-x-4",
                            children: [f.jsx("a", {
                                href: "#",
                                className: "bg-black text-white p-3 rounded-full hover:bg-orange-500 transition-colors",
                                "aria-label": "Facebook",
                                children: f.jsx(_h, {
                                    className: "h-6 w-6"
                                })
                            }), f.jsx("a", {
                                href: "#",
                                className: "bg-black text-white p-3 rounded-full hover:bg-orange-500 transition-colors",
                                "aria-label": "Instagram",
                                children: f.jsx(Th, {
                                    className: "h-6 w-6"
                                })
                            })]
                        })]
                    })]
                }), f.jsxs("div", {
                    className: "bg-gray-900 rounded-none p-12",
                    children: [f.jsx("h2", {
                        className: "text-4xl font-bold text-white mb-8",
                        children: "Sign in to get the products"
                    }), f.jsxs("form", {
                        onSubmit: r,
                        className: "space-y-6",
                        children: [f.jsx("input", {
                            type: "text",
                            name: "name",
                            placeholder: "name",
                            value: t.name,
                            onChange: l,
                            required: !0,
                            className: "w-full px-6 py-4 rounded-none bg-white text-gray-900 placeholder-gray-500 text-lg"
                        }), f.jsx("input", {
                            type: "text",
                            name: "address",
                            placeholder: "address",
                            value: t.address,
                            onChange: l,
                            required: !0,
                            className: "w-full px-6 py-4 rounded-none bg-white text-gray-900 placeholder-gray-500 text-lg"
                        }), f.jsx("input", {
                            type: "tel",
                            name: "phone",
                            placeholder: "phone number",
                            value: t.phone,
                            onChange: l,
                            required: !0,
                            className: "w-full px-6 py-4 rounded-none bg-white text-gray-900 placeholder-gray-500 text-lg"
                        }), f.jsx("input", {
                            type: "email",
                            name: "email",
                            placeholder: "E-mail",
                            value: t.email,
                            onChange: l,
                            required: !0,
                            className: "w-full px-6 py-4 rounded-none bg-white text-gray-900 placeholder-gray-500 text-lg"
                        }), f.jsx("button", {
                            type: "submit",
                            className: "w-full bg-orange-500 text-white py-4 text-xl font-semibold hover:bg-orange-600 transition-colors",
                            children: "Register"
                        })]
                    })]
                })]
            })
        })
    })
}
class sr {
    constructor(t = 0, n = "Network Error") {
        this.status = t, this.text = n
    }
}
const Dh = () => {
        if (!(typeof localStorage > "u")) return {
            get: e => Promise.resolve(localStorage.getItem(e)),
            set: (e, t) => Promise.resolve(localStorage.setItem(e, t)),
            remove: e => Promise.resolve(localStorage.removeItem(e))
        }
    },
    te = {
        origin: "https://api.emailjs.com",
        blockHeadless: !1,
        storageProvider: Dh()
    },
    bi = e => e ? typeof e == "string" ? {
        publicKey: e
    } : e.toString() === "[object Object]" ? e : {} : {},
    Uh = (e, t = "https://api.emailjs.com") => {
        if (!e) return;
        const n = bi(e);
        te.publicKey = n.publicKey, te.blockHeadless = n.blockHeadless, te.storageProvider = n.storageProvider, te.blockList = n.blockList, te.limitRate = n.limitRate, te.origin = n.origin || t
    },
    Hc = async (e, t, n = {}) => {
        const r = await fetch(te.origin + e, {
                method: "POST",
                headers: n,
                body: t
            }),
            l = await r.text(),
            o = new sr(r.status, l);
        if (r.ok) return o;
        throw o
    },
    Wc = (e, t, n) => {
        if (!e || typeof e != "string") throw "The public key is required. Visit https://dashboard.emailjs.com/admin/account";
        if (!t || typeof t != "string") throw "The service ID is required. Visit https://dashboard.emailjs.com/admin";
        if (!n || typeof n != "string") throw "The template ID is required. Visit https://dashboard.emailjs.com/admin/templates"
    },
    Ah = e => {
        if (e && e.toString() !== "[object Object]") throw "The template params have to be the object. Visit https://www.emailjs.com/docs/sdk/send/"
    },
    Qc = e => e.webdriver || !e.languages || e.languages.length === 0,
    Kc = () => new sr(451, "Unavailable For Headless Browser"),
    $h = (e, t) => {
        if (!Array.isArray(e)) throw "The BlockList list has to be an array";
        if (typeof t != "string") throw "The BlockList watchVariable has to be a string"
    },
    Bh = e => {
        var t;
        return !((t = e.list) != null && t.length) || !e.watchVariable
    },
    Vh = (e, t) => e instanceof FormData ? e.get(t) : e[t],
    Yc = (e, t) => {
        if (Bh(e)) return !1;
        $h(e.list, e.watchVariable);
        const n = Vh(t, e.watchVariable);
        return typeof n != "string" ? !1 : e.list.includes(n)
    },
    Gc = () => new sr(403, "Forbidden"),
    Hh = (e, t) => {
        if (typeof e != "number" || e < 0) throw "The LimitRate throttle has to be a positive number";
        if (t && typeof t != "string") throw "The LimitRate ID has to be a non-empty string"
    },
    Wh = async (e, t, n) => {
        const r = Number(await n.get(e) || 0);
        return t - Date.now() + r
    },
    Xc = async (e, t, n) => {
        if (!t.throttle || !n) return !1;
        Hh(t.throttle, t.id);
        const r = t.id || e;
        return await Wh(r, t.throttle, n) > 0 ? !0 : (await n.set(r, Date.now().toString()), !1)
    },
    Zc = () => new sr(429, "Too Many Requests"),
    Qh = async (e, t, n, r) => {
        const l = bi(r),
            o = l.publicKey || te.publicKey,
            i = l.blockHeadless || te.blockHeadless,
            u = l.storageProvider || te.storageProvider,
            s = { ...te.blockList,
                ...l.blockList
            },
            a = { ...te.limitRate,
                ...l.limitRate
            };
        return i && Qc(navigator) ? Promise.reject(Kc()) : (Wc(o, e, t), Ah(n), n && Yc(s, n) ? Promise.reject(Gc()) : await Xc(location.pathname, a, u) ? Promise.reject(Zc()) : Hc("/api/v1.0/email/send", JSON.stringify({
            lib_version: "4.4.1",
            user_id: o,
            service_id: e,
            template_id: t,
            template_params: n
        }), {
            "Content-type": "application/json"
        }))
    },
    Kh = e => {
        if (!e || e.nodeName !== "FORM") throw "The 3rd parameter is expected to be the HTML form element or the style selector of the form"
    },
    Yh = e => typeof e == "string" ? document.querySelector(e) : e,
    Gh = async (e, t, n, r) => {
        const l = bi(r),
            o = l.publicKey || te.publicKey,
            i = l.blockHeadless || te.blockHeadless,
            u = te.storageProvider || l.storageProvider,
            s = { ...te.blockList,
                ...l.blockList
            },
            a = { ...te.limitRate,
                ...l.limitRate
            };
        if (i && Qc(navigator)) return Promise.reject(Kc());
        const v = Yh(n);
        Wc(o, e, t), Kh(v);
        const p = new FormData(v);
        return Yc(s, p) ? Promise.reject(Gc()) : await Xc(location.pathname, a, u) ? Promise.reject(Zc()) : (p.append("lib_version", "4.4.1"), p.append("service_id", e), p.append("template_id", t), p.append("user_id", o), Hc("/api/v1.0/email/send-form", p))
    },
    Xh = {
        init: Uh,
        send: Qh,
        sendForm: Gh,
        EmailJSResponseStatus: sr
    };

function Zh() {
    const e = Ji(),
        t = Ll(),
        n = N.useRef(null),
        {
            userInfo: r
        } = e.state || {
            userInfo: null
        },
        [l, o] = N.useState({
            name: (r == null ? void 0 : r.name) || "",
            email: (r == null ? void 0 : r.email) || "",
            phone: (r == null ? void 0 : r.phone) || "",
            address: (r == null ? void 0 : r.address) || "",
            detailedAddress: "",
            selectedProducts: {}
        }),
        i = ["SMART SOLAR PANEL SYSTEM", "SMART AIR PURIFYING SYSTEM", "SMART TRIBOELECTRIC GENERATOR FLOOR"],
        u = m => {
            const {
                name: y,
                value: g
            } = m.target;
            o(w => ({ ...w,
                [y]: g
            }))
        },
        s = m => {
            o(y => {
                const g = { ...y.selectedProducts
                };
                return g[m] !== void 0 ? delete g[m] : g[m] = 1, { ...y,
                    selectedProducts: g
                }
            })
        },
        a = (m, y) => {
            o(g => ({ ...g,
                selectedProducts: { ...g.selectedProducts,
                    [m]: y
                }
            }))
        },
        v = async m => {
            m.preventDefault();
            const y = Object.entries(l.selectedProducts).map(([g, w]) => `${g} (Quantity: ${w})`).join(", ");
            try {
                const g = {
                    to_email: "09a.youssef@gmail.com",
                    from_name: l.name,
                    from_email: l.email,
                    phone: l.phone,
                    address: l.address,
                    detailed_address: l.detailedAddress,
                    selected_products: y,
                    message: `New order from ${l.name}:

Products: ${y}

Address: ${l.detailedAddress}

Phone: ${l.phone}

Email: ${l.email}`
                };
                await Xh.send("service_32ubhnr", "template_d6lfazm", g, "1d1AogCesFp1u8FUP"), alert("Order submitted successfully!"), t("/")
            } catch (g) {
                console.error("Error sending email:", g), alert("Failed to submit order. Please try again.")
            }
        },
        p = Object.keys(l.selectedProducts).length > 0;
    return f.jsx("div", {
        className: "min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8",
        children: f.jsxs("div", {
            className: "max-w-3xl mx-auto bg-white rounded-lg shadow-xl overflow-hidden",
            children: [f.jsxs("div", {
                className: "px-8 py-6 bg-orange-500 text-white",
                children: [f.jsx("h2", {
                    className: "text-3xl font-bold",
                    children: "Complete Your Order"
                }), f.jsx("p", {
                    className: "mt-2",
                    children: "Please select your products, adjust quantities, and provide delivery details"
                })]
            }), f.jsxs("form", {
                ref: n,
                onSubmit: v,
                className: "p-8 space-y-6",
                children: [f.jsxs("div", {
                    className: "space-y-4",
                    children: [f.jsx("h3", {
                        className: "text-xl font-semibold text-gray-900",
                        children: "Personal Information"
                    }), f.jsxs("div", {
                        className: "grid grid-cols-2 gap-4",
                        children: [f.jsx("input", {
                            type: "text",
                            name: "name",
                            value: l.name,
                            onChange: u,
                            placeholder: "Full Name",
                            required: !0,
                            className: "px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                        }), f.jsx("input", {
                            type: "email",
                            name: "email",
                            value: l.email,
                            onChange: u,
                            placeholder: "Email Address",
                            required: !0,
                            className: "px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                        }), f.jsx("input", {
                            type: "tel",
                            name: "phone",
                            value: l.phone,
                            onChange: u,
                            placeholder: "Phone Number",
                            required: !0,
                            className: "px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                        }), f.jsx("input", {
                            type: "text",
                            name: "address",
                            value: l.address,
                            onChange: u,
                            placeholder: "City/Region",
                            required: !0,
                            className: "px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                        })]
                    }), f.jsx("textarea", {
                        name: "detailedAddress",
                        value: l.detailedAddress,
                        onChange: u,
                        placeholder: "Detailed Address (Street, Building, Apartment, etc.)",
                        required: !0,
                        rows: 3,
                        className: "w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                    })]
                }), f.jsxs("div", {
                    className: "space-y-4",
                    children: [f.jsx("h3", {
                        className: "text-xl font-semibold text-gray-900",
                        children: "Select Products"
                    }), f.jsx("div", {
                        className: "space-y-2",
                        children: i.map(m => {
                            const y = l.selectedProducts[m] !== void 0;
                            return f.jsxs("div", {
                                className: "flex flex-col",
                                children: [f.jsxs("label", {
                                    className: "flex items-center space-x-3",
                                    children: [f.jsx("input", {
                                        type: "checkbox",
                                        checked: y,
                                        onChange: () => s(m),
                                        className: "h-5 w-5 text-orange-500 rounded focus:ring-orange-500"
                                    }), f.jsx("span", {
                                        className: "text-gray-700",
                                        children: m
                                    })]
                                }), y && f.jsx("input", {
                                    type: "number",
                                    min: 1,
                                    value: l.selectedProducts[m],
                                    onChange: g => a(m, Number(g.target.value)),
                                    className: "mt-1 w-24 px-2 py-1 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                                })]
                            }, m)
                        })
                    })]
                }), f.jsx("div", {
                    className: "pt-6 border-t border-gray-200",
                    children: f.jsx("button", {
                        type: "submit",
                        disabled: !p,
                        className: "w-full bg-orange-500 text-white py-3 px-4 rounded-md hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed",
                        children: "Submit Order"
                    })
                })]
            })]
        })
    })
}
const qh = () => {
        const e = Ll(),
            t = () => {
                e("/contact")
            };
        return N.useEffect(() => {
            const n = l => {
                    l.preventDefault();
                    const o = l.currentTarget.getAttribute("href");
                    if (!(o != null && o.startsWith("#"))) return;
                    const i = document.querySelector(o);
                    i && i.scrollIntoView({
                        behavior: "smooth"
                    })
                },
                r = document.querySelectorAll('a[href^="#"]');
            return r.forEach(l => l.addEventListener("click", n)), () => {
                r.forEach(l => l.removeEventListener("click", n))
            }
        }, []), f.jsxs("div", {
            className: "min-h-screen bg-black text-white",
            children: [f.jsx("nav", {
                className: "fixed top-0 w-full z-50 px-6 py-4 bg-black/80 backdrop-blur-sm",
                children: f.jsxs("div", {
                    className: "max-w-7xl mx-auto flex items-center justify-between",
                    children: [f.jsxs("a", {
                        href: "#home",
                        className: "flex items-center",
                        children: [f.jsx(Ph, {
                            className: "h-8 w-8 text-orange-500"
                        }), f.jsx("span", {
                            className: "ml-2 text-2xl font-bold",
                            children: "HOMIE"
                        })]
                    }), f.jsxs("div", {
                        className: "hidden md:flex items-center space-x-8",
                        children: [f.jsx("a", {
                            href: "#home",
                            className: "hover:text-orange-500 transition-colors",
                            children: "Home"
                        }), f.jsx("a", {
                            href: "#solutions",
                            className: "hover:text-orange-500 transition-colors",
                            children: "Solutions"
                        }), f.jsx("a", {
                            href: "#products",
                            className: "hover:text-orange-500 transition-colors",
                            children: "Products"
                        }), f.jsx("a", {
                            href: "#team",
                            className: "hover:text-orange-500 transition-colors",
                            children: "Team"
                        }), f.jsx("a", {
                            href: "#contact",
                            className: "hover:text-orange-500 transition-colors",
                            children: "Contact"
                        })]
                    }), f.jsxs("div", {
                        className: "flex items-center space-x-4",
                        children: [f.jsxs("div", {
                            className: "relative",
                            children: [f.jsx(Rh, {
                                className: "absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400"
                            }), f.jsx("input", {
                                type: "text",
                                placeholder: "Search...",
                                className: "pl-10 pr-4 py-2 rounded-full bg-white/10 focus:outline-none focus:ring-2 focus:ring-orange-500"
                            })]
                        }), f.jsxs("button", {
                            onClick: t,
                            className: "flex items-center space-x-2 bg-orange-500 px-4 py-2 rounded-full hover:bg-orange-600 transition-colors",
                            children: [f.jsx(jh, {
                                className: "h-5 w-5"
                            }), f.jsx("span", {
                                children: "Log In"
                            })]
                        })]
                    })]
                })
            }), f.jsx("section", {
                id: "home",
                children: f.jsx(zh, {})
            }), f.jsx("section", {
                id: "solutions",
                children: f.jsx(Mh, {})
            }), f.jsx("section", {
                id: "products",
                children: f.jsx(Ih, {})
            }), f.jsx("section", {
                id: "team",
                children: f.jsx(Fh, {})
            }), f.jsx("section", {
                id: "contact",
                children: f.jsx(Vc, {})
            })]
        })
    },
    Jh = () => f.jsx(kh, {
        children: f.jsxs(xh, {
            children: [f.jsx($r, {
                path: "/",
                element: f.jsx(qh, {})
            }), f.jsx($r, {
                path: "/order",
                element: f.jsx(Zh, {})
            }), f.jsx($r, {
                path: "/contact",
                element: f.jsx(Vc, {})
            })]
        })
    }),
    qc = document.getElementById("root");
if (!qc) throw new Error("Root element not found");
Rc(qc).render(f.jsx(N.StrictMode, {
    children: f.jsx(Jh, {})
}));